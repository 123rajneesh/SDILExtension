﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChannelFactorySample
{
    public class Config
    {
        public static string httpEndpoint = "http://localhost:6588/Design_Time_Addresses/TWcfServiceLibrary/ServiceB/";
        public static string netTcpEndpoint = "net.tcp://sez3crosscode.india.rsystems.com:505/Service1.svc";
    }
}
