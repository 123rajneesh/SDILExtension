using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ChannelFactorySample
{
    [ServiceContract()]
    interface IService
    {
        [OperationContract()]
        string Message();
    }
    [ServiceContract()]
    interface ICalculater
    {
        [OperationContract()]
        int Add(int x, int y);
    }

    class Program
    {
        int count = 2;

        static void Main(string[] args)
        {
            //GenericInitializeFactory();

            InitializeFactory();
        }

        public static void GenericInitializeFactory()
        {

            // This code is written by an application developer.
            // Create a channel factory.

            BasicHttpBinding myBinding = new BasicHttpBinding();

            EndpointAddress myEndpoint = new EndpointAddress(Config.httpEndpoint);

            ChannelFactory<IService> myChannelFactory = new ChannelFactory<IService>(myBinding, myEndpoint);

            // Create a channel.
            var wcfClient1 = myChannelFactory.CreateChannel();
            var s = wcfClient1.Message();
            Console.WriteLine(s.ToString());
            ((IClientChannel)wcfClient1).Close();

            // Create another channel.
            IService wcfClient2 = myChannelFactory.CreateChannel();
            s = wcfClient2.Message();
            Console.WriteLine(s.ToString());
            ((IClientChannel)wcfClient2).Close();
            myChannelFactory.Close();
        }

        private static void InitializeFactory()
        {
            var binding = new NetTcpBinding();
            var endpoint = new EndpointAddress(new Uri(Config.netTcpEndpoint));
            var channelFactory = new ChannelFactory<ICalculater>(binding, endpoint);
            var serviceClient = channelFactory.CreateChannel();
            var result = serviceClient.Add(1, 2);
            channelFactory.Close();
        }
        public void donothing()
        {
            count = 6;
            Config.httpEndpoint = "nothing else matters";
        }
    }
}
