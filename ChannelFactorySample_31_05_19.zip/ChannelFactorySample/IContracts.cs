﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Contracts
{
    [ServiceContract()]
    public interface IService
    {
        [OperationContract()]
        string GoodBye(string arg);       
        [OperationContract]
        string Message(string msg);
    }
    [ServiceContract()]
    public interface ICalculater
    {
        [OperationContract()]
        int Add(int x, int y);
        [OperationContract()]
        int Subtract(int x, int y);
    }
    [ServiceContract()]
    public interface proxySampleService
    {
        [OperationContract()]
        string SampleMethod(String MSG);

    }
    [ServiceContract()]
    public interface IWCFAddition
    {
        [OperationContract()]
        int SumOfTwoNumber(int num1, int num2);

    }
}
