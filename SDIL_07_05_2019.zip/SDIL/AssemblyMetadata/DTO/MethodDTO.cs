﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public class MethodDTO : IMethodDTO
    {
        public MethodDTO()
        {
            this.AssemblyDTO = new AssemblyDTO();
            this.TypeDTO = new TypeDTO();
        }
        public AssemblyDTO AssemblyDTO { get; set; }
        public TypeDTO TypeDTO { get; set; }
        public string Signature { get; set; }
        public string[] Parameters { get; set; }
        public string ReturnType { get; set; }
        public int Count { get; set; }
        public string Name { get; set; }
        public string FullName { get; set; }
        public bool IsPublic { get ; set ; }
        public bool IsPrivate { get ; set ; }
    }
}
