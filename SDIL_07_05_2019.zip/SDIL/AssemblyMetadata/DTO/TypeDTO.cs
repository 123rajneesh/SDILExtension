﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public class TypeDTO : ITypeDTO
    {
        public TypeDTO()
        {
            this.AssemblyDTO = new AssemblyDTO();
        }
        public string Namespace { get; set; }
        public AssemblyDTO AssemblyDTO { get; set; }
        public int Count { get; set; }
        public string Name { get; set; }
        public string FullName { get; set; }
        public Type Type { get; set; }
        public bool IsPublic { get ; set ; }
        public bool IsPrivate { get ; set ; }
    }
}
