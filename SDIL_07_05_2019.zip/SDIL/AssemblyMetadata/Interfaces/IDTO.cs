﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public interface IDTO
    {
        int Count { get; set; }
        string Name { get; set; }
        string FullName { get; set; }

        bool IsPublic { get; set; }
        bool IsPrivate { get; set; }

    }
}
