﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public class MethodMetadata : IMethodMetadata
    {
        public List<MethodDTO> GetMethodInfo(Assembly assembly)
        {
            try
            {
                var collection = Info.GetTypeInfo(assembly);

                return ItreateMethod(collection);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static List<MethodDTO> ItreateMethod(List<TypeDTO> collection)
        {
            List<MethodDTO> list = new List<MethodDTO>();

            try
            {
                foreach (TypeDTO typeDTO in collection)
                {
                    MethodInfo[] methodInfo = typeDTO.Type.GetMethods(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly);
                
                    foreach (var minfo in methodInfo)
                    {
                        MethodDTO mdto = new MethodDTO();

                        mdto.IsPrivate = minfo.IsPrivate;

                        mdto.IsPublic = minfo.IsPublic;

                        mdto.TypeDTO = typeDTO;

                        mdto.AssemblyDTO = typeDTO.AssemblyDTO;

                        mdto.Parameters = minfo.GetParameters().Select(p => String.Format("{0} {1}", p.ParameterType.Name, p.Name)).ToArray();

                        mdto.Signature = String.Format("{0} {1}({2})", string.IsNullOrEmpty(minfo.ReturnType.Name) ? "void" : minfo.ReturnType.Name, minfo.Name, String.Join(",", mdto.Parameters));

                        mdto.FullName = String.Format("{0}.{1}({2})", typeDTO.Type.FullName, minfo.Name, String.Join(",", mdto.Parameters));

                        list.Add(mdto);

                    }
                }

                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
