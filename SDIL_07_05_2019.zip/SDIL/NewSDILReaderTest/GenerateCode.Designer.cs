﻿namespace NewSDILReaderTest
{
    partial class GenerateCode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOpenAssembly = new System.Windows.Forms.Button();
            this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.lbl_fleName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnOpenAssembly
            // 
            this.btnOpenAssembly.Location = new System.Drawing.Point(356, 12);
            this.btnOpenAssembly.Name = "btnOpenAssembly";
            this.btnOpenAssembly.Size = new System.Drawing.Size(129, 23);
            this.btnOpenAssembly.TabIndex = 6;
            this.btnOpenAssembly.Text = "Select Code File (.cs)";
            this.btnOpenAssembly.UseVisualStyleBackColor = true;
            this.btnOpenAssembly.Click += new System.EventHandler(this.btnOpenAssembly_Click);
            // 
            // dlgOpenFile
            // 
            this.dlgOpenFile.FileName = "*.*";
            // 
            // lbl_fleName
            // 
            this.lbl_fleName.AutoSize = true;
            this.lbl_fleName.Location = new System.Drawing.Point(13, 407);
            this.lbl_fleName.Name = "lbl_fleName";
            this.lbl_fleName.Size = new System.Drawing.Size(0, 13);
            this.lbl_fleName.TabIndex = 7;
            // 
            // GenerateCode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_fleName);
            this.Controls.Add(this.btnOpenAssembly);
            this.Name = "GenerateCode";
            this.Text = "GenerateCode";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOpenAssembly;
        private System.Windows.Forms.OpenFileDialog dlgOpenFile;
        private System.Windows.Forms.Label lbl_fleName;
    }
}