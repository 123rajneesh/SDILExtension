using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhoIsCaller
{
    class Program
    {
        static int sum = 0;

        static void Main()
        {
            sum = AddTwoNumbers(2, 2);
            //System.IO.File.WriteAllText(@"C:\Users\rajneesh.kumar\source\repos\SDIL\WhoIsCaller\Code\result.txt", "S Y S T E M G E N E R A T E D");
            //System.IO.File.WriteAllText("C:\\Users\\rajneesh.kumar\\source\\repos\\SDIL\\WhoIsCaller\\Code\\result.txt", "IL I N J E C T E D L I N E S");
            //System.IO.File.WriteAllText("C:\\Users\\rajneesh.kumar\\source\\reposSDIL\\WhoIsCaller\\Code\\result.txt", "IL I N J E C T E D L I N E S");
        }
        public static int AddTwoNumbers(int a, int b)
        {
            if (a > b)
                return a + b;
            else
                return a - b;
        }
        public static string WriteMessage()
        {
            string str= "Hello World";

            return str;
        }
    }
}
