﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NewSDILReaderTest
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {          
            string startupPath = Environment.CommandLine;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new AssemblyInfo());
            Application.Run(new Main());

        }
    }

    public class Config
    {
        public static string[] AssemblyExclude { get { return ConfigurationManager.AppSettings["Exclude:Assembly"].Split(','); } }

        public static string[] TypeExclude { get { return ConfigurationManager.AppSettings["Exclude:Type"].Split(','); } }

        public static bool PrivateExclude { get { return Convert.ToBoolean(ConfigurationManager.AppSettings["Exclude:Private"]); } }

        public static string ProjectDirectory { get { return Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory())); } }

        public static string Ildasm { get { return ConfigurationManager.AppSettings["Path:ildasm"]; } }
    }
}
