﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace NewSDILReaderTest
{
    public class ReferenceAssemblyInfo
    {
        public static void Run(Type type)
        {
            // This variable holds the amount of indenting that 
            // should be used when displaying each line of information.
          
            Assembly a = type.Assembly;

            Console.WriteLine("Assembly identity={0}", a.FullName);

            Console.WriteLine("Codebase={0}", a.CodeBase);

            // Display the set of assemblies our assemblies reference.
            AssemblyName refAsmbly = a.GetReferencedAssemblies().Single(x => x.Name == "System.ServiceModel");

            Assembly serviceModelASM = Assembly.Load(refAsmbly);

            var svcMdlType = serviceModelASM.GetTypes();

            Console.WriteLine("Referenced assemblies:");

            foreach (Type smtyp in svcMdlType)
            {

                Console.WriteLine("Name={0}, Namespace={1}, Assembly Name={2}", smtyp.Name, smtyp.Namespace, smtyp.Assembly.GetName());
            }
            Console.WriteLine("");


        }

    }
}
