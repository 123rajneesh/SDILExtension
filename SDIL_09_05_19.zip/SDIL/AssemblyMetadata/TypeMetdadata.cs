﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    class TypeMetdadata : ITypeMetdadata
    {
        public List<TypeDTO> GetTypeInfo(Assembly assembly)
        {
            List<TypeDTO> list = new List<TypeDTO>();
            try
            {
                Module[] moduls = assembly.GetModules();

                foreach (Module module in moduls)
                {
                    Type[] types = module.GetTypes();

                    var dtos = GetTypesFromModule(types);

                    list.AddRange(dtos);
                }
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static List<TypeDTO> GetTypesFromModule(Type[] types)
        {
            List<TypeDTO> typeDTOs = new List<TypeDTO>();

            foreach (Type type in types)
            {
                typeDTOs.Add(new TypeDTO
                {
                    Name = type.Name,
                    FullName = type.FullName,
                    AssemblyDTO = Info.GetAssemblyInfo(type.Assembly),
                    Namespace = type.Namespace,
                    IsPrivate = type.IsNotPublic,
                    IsPublic = type.IsPublic,
                    Type = type
                });
            }
            return typeDTOs;
        }

    }
}
