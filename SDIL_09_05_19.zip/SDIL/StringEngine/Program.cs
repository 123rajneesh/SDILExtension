using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputILFile = @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\bin\Debug\ChannelFactorySample.il";

            string outputILFile = @"C:\Users\rajneesh.kumar\source\repos\SDIL\StringEngine\bin\Debug\ChannelFactorySample.il";

            string hookedContext = @"C:\Users\rajneesh.kumar\source\repos\SDIL\StringEngine\StaticILInstruction.json";

            Inject.File(inputILFile, hookedContext, outputILFile);

            Console.ReadLine();
        }
    }
}
