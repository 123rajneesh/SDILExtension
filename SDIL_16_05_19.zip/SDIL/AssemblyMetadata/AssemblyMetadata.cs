﻿using System;
using System.Linq;
using System.Reflection;

namespace Metadata
{
    public class AssemblyMetadata : IAssemblyMetdata
    {
        public AssemblyDTO GetAssemblyInfo(Assembly assembly)
        {
            AssemblyDTO assemblyDTO = null;

            try
            {
                assemblyDTO = new AssemblyDTO();

                assemblyDTO.FullName = assembly.FullName;

                assemblyDTO.DefinedTypeDTO.Count = assembly.DefinedTypes.Count();

                assemblyDTO.DefinedTypeDTO.FullName = assembly.DefinedTypes.Select(x => x.FullName).ToArray();

                assemblyDTO.ExportedTypeDTO.Count = assembly.ExportedTypes.Count();

                assemblyDTO.ExportedTypeDTO.FullName = assembly.ExportedTypes.Select(x => x.FullName).ToArray();

                assemblyDTO.CodeBase = assembly.CodeBase;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return assemblyDTO;
        }       
    }
}
