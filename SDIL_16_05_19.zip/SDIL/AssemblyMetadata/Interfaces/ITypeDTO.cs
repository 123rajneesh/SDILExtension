﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public interface ITypeDTO : IDTO
    {
        string Namespace { get; set; }
        Type Type { get; set; }
    }
}
