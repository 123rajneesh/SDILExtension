﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumerServiceMapper.DTO
{
    public class ServiceConfigDTO
    {
        public ServiceConfigDTO()
        {
            this.Endpoints = new List<Endpoint>();
        }
        public List<Endpoint> Endpoints { get; set; }
    }
    public class Endpoint
    {
        public string Address { get; set; }
        public string BindingName { get; set; }
        public string Contract { get; set; }
        public string ListenUri { get; set; }
    }

}
