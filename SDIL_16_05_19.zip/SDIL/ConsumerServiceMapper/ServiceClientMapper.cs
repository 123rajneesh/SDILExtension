﻿using ConsumerServiceMapper.DTO;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumerServiceMapper
{
    public class ServiceClientMapper
    {

        public static ServiceClientDTO ReadMock()
        {
            string location = @"C:\Users\rajneesh.kumar\Downloads\sdilreader\SDIL\ConsumerServiceMapper\Mock\ServiceClientDTO.json";

            var json = File.ReadAllText(location);

            ServiceClientDTO clientDTO = JsonConvert.DeserializeObject<ServiceClientDTO>(json);

            return clientDTO;
        }
    }
}
