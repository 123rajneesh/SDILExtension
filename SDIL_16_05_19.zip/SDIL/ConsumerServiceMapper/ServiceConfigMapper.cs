﻿using ConsumerServiceMapper.DTO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.ServiceModel.Configuration;
using System.Text;
using System.Threading.Tasks;

namespace ConsumerServiceMapper
{
    public class ServiceConfigMapper
    {
        public static ServiceConfigDTO ExtractWCFConfiguration(string assemblyPath)
        {            
               //AppLog.Info($"ExtractWCFConfiguration  : Running for assemblyPath   :{assemblyPath}.");

               ServiceConfigDTO configDTO = null;

            try
            {
                configDTO = new ServiceConfigDTO();

                ExeConfigurationFileMap configMap = new ExeConfigurationFileMap();

                configMap.ExeConfigFilename = assemblyPath;

                System.Configuration.Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configMap, ConfigurationUserLevel.None);

                ServiceModelSectionGroup configurationSectionGroup = config.GetSectionGroup("system.serviceModel") as ServiceModelSectionGroup;

                var client = configurationSectionGroup.Client;

                configDTO.Endpoints = GetServiceEndpointInfo(client.Endpoints);

            }
            catch (Exception ex)
            {
                //AppLog.Debug("ExtractWCFConfiguration  : Following error occured -", ex.Message);
            }

            //AppLog.Info("ExtractWCFConfiguration  : Completed.");

            return configDTO;
        }

        private static List<Endpoint> GetServiceEndpointInfo(ChannelEndpointElementCollection endpoints)
        {
            //AppLog.Info("GetServiceEndpointInfo  : Running.");

            List<Endpoint> endPointList = null;

            try
            {
                endPointList = new List<Endpoint>();

                //AppLog.Info($"GetServiceEndpointInfo  : started foreach loop for endpoints,     endpoints    :{endpoints.Count}.");

                foreach (ChannelEndpointElement ep in endpoints)
                {
                    Endpoint endpoint = new Endpoint();

                    endpoint.Address = ep.Address.OriginalString;

                    endpoint.BindingName = ep.Binding;

                    endpoint.Contract = ep.Contract;

                    endPointList.Add(endpoint);
                }
            }
            catch (Exception ex)
            {
                //AppLog.Debug("GetServiceEndpointInfo  : Following error occured -", ex.Message);
            }

            //AppLog.Info("GetServiceEndpointInfo  : Completed.");

            return endPointList;
        }

    }

}
