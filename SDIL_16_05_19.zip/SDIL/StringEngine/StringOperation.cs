﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace StringEngine
{
    public class StringOperation
    {
        public static int ILCodeLineCount = 2;

        private static string HookedContext { get; set; }

        public static string ReadILFile(string ILFILE, string hook)
        {
            string ilText = string.Empty;

            HookedContext = hook;

            try
            {   // Open the text file using a stream reader.
                using (StreamReader sr = new StreamReader(ILFILE))
                {
                    // Read the stream to a string, and write the string to the console.
                    ilText = sr.ReadToEnd();
                }
            }
            catch (IOException e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }

            return ilText;
        }

        public static string ReadILClass(string nonespecialclass)
        {
            var ilText = nonespecialclass;

            //find .class in IL
            var classIdx = ilText.IndexOf(".class");

            var classText = ilText.Substring(classIdx);

            var firstIdxOfMethod = classText.IndexOf(".method");

            string[] allmethod = classText.Split(new[] { ".method" }, StringSplitOptions.RemoveEmptyEntries).Where(t => !t.Contains(".class")).Select(m => string.Format(".method{0}", m)).ToArray();


            //filter contructor and none constructor methods by first line

            List<string> list_ConstructorMethods = new List<string>();

            List<string> list_noneConstructorMethods = new List<string>();

            foreach (var method in allmethod)
            {
                var firstBracIndex = method.IndexOf('{');

                var methodSignature = method.Substring(0, firstBracIndex);

                if (methodSignature != null)
                {
                    if (methodSignature.Contains(".ctor()") | methodSignature.Contains(".cctor()"))
                    {
                        list_ConstructorMethods.Add(method);
                    }
                    else
                    {
                        list_noneConstructorMethods.Add(method);
                    }
                }

            }

            var newClassTemplate = classText.Substring(classIdx, firstIdxOfMethod);

            StringBuilder sbnewTemplate = new StringBuilder();

            sbnewTemplate.AppendLine(newClassTemplate);

            foreach (var method in list_noneConstructorMethods)
            {
                var customMethod = MethodInjection(method, out string injectedMethodSig);

                sbnewTemplate.AppendLine(customMethod);
            }
            foreach (var method in list_ConstructorMethods)
            {
                sbnewTemplate.AppendLine(method);
            }
            //sbnewTemplate.AppendLine("}");

            char[] trim_cahracters = { '*', ' ' };

            var result = sbnewTemplate.ToString().TrimEnd(trim_cahracters);

            var template = ilText.Replace(classText, result);

            return template;
        }



        private static string MethodInjection(string methodContent, out string injectedMethodSig)
        {
            GetSourceCodeLinesFromIL(methodContent);

            var localflds = GetMethodLocalFileds(methodContent);

            StringReader strReader = new StringReader(methodContent);

            StringBuilder sb = new StringBuilder();

            List<string> HexCodes = new List<string>();

            List<ILInstruction> ilInstructionCollection = new List<ILInstruction>();

            List<ILInstruction> staticInstruction = null;

            var methodSignature = GetMethodSignature(methodContent);

            injectedMethodSig = methodSignature;

            while (true)
            {
                string line = strReader.ReadLine();

                if (line == null)
                { break; }


                //Extract each line w.r.t ILInstruction DTO
                if (line.Contains("IL_"))
                {
                    ILInstruction ilinstruction = new ILInstruction();

                    string[] col = line.Split(new[] { "  ", "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);

                    ilinstruction.IsAdded = false;

                    ilinstruction.OldILHexCode = col[0];

                    ilinstruction.OpCode = col[1];

                    switch (col.Length)
                    {
                        //If Instruction is not available
                        case 1:
                        case 2:
                            break;
                        case 3:
                            ilinstruction.Instruction = col[2];
                            break;
                    }
                    ilInstructionCollection.Add(ilinstruction);
                }

                if (line.Contains("ret"))
                {
                    var reverslist = ilInstructionCollection.AsEnumerable().Reverse().Take(ILCodeLineCount).Reverse().ToList();

                    using (StreamReader reader = new StreamReader(HookedContext))
                    {
                        string json = reader.ReadToEnd();

                        staticInstruction = JsonConvert.DeserializeObject<List<ILInstruction>>(json);

                        staticInstruction.ForEach(x => x.MethodName = methodSignature);
                    }
                    var ldlocLine = reverslist.Where(x => x.OpCode.Contains("ldloc")).FirstOrDefault();

                    if (ldlocLine != null && !ldlocLine.IsAdded)
                    {
                        staticInstruction.AddRange(reverslist);

                        //sb.Replace(ldlocLine.FullStatement, string.Empty);

                        ReArrangeILInstruction(staticInstruction);

                        for (int counter = 0; counter < staticInstruction.Count(); counter++)
                        {
                            string statment = string.Format("    {0} {1}        {2}", staticInstruction[counter].NewILHexCode, staticInstruction[counter].OpCode, staticInstruction[counter].Instruction);
                            sb.AppendLine(statment);
                        }
                    }
                    else
                    {
                        staticInstruction.Add(reverslist.LastOrDefault());
                        ReArrangeILInstruction(staticInstruction);

                        for (int counter = 0; counter < staticInstruction.Count(); counter++)
                        {
                            string statment = string.Format("    {0} {1}        {2}", staticInstruction[counter].NewILHexCode, staticInstruction[counter].OpCode, staticInstruction[counter].Instruction);
                            sb.AppendLine(statment);
                        }
                    }
                }
                else
                {
                    sb.AppendLine(line);
                }
            }

            var methodTemplate = UpdateOldILInstructionReferences(staticInstruction, sb.ToString());



            return methodTemplate;
        }

        private static string MethodInjection(string methodContent, out string injectedMethodSig, int num = 0)
        {
            GetSourceCodeLinesFromIL(methodContent);

            var localflds = GetMethodLocalFileds(methodContent);

            StringReader strReader = new StringReader(methodContent);

            StringBuilder sb = new StringBuilder();

            List<string> HexCodes = new List<string>();

            List<ILInstruction> ilInstructionCollection = new List<ILInstruction>();

            List<ILInstruction> staticInstruction = null;

            var methodSignature = GetMethodSignature(methodContent);

            string methodTemplate = string.Empty;

            injectedMethodSig = methodSignature;
            if (localflds.Count() > 0)
            {
                while (true)
                {
                    string line = strReader.ReadLine();

                    if (line == null)
                    { break; }


                    //Extract each line w.r.t ILInstruction DTO to get oldhexcode of method
                    if (line.Contains("IL_"))
                    {
                        ILInstruction ilinstruction = new ILInstruction();

                        string[] col = line.Split(new[] { "  ", "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);

                        ilinstruction.IsAdded = false;

                        ilinstruction.OldILHexCode = col[0];

                        ilinstruction.OpCode = col[1];

                        switch (col.Length)
                        {
                            //If Instruction is not available
                            case 1:
                            case 2:
                                break;
                            case 3:
                                ilinstruction.Instruction = col[2];
                                break;
                        }
                        ilInstructionCollection.Add(ilinstruction);
                    }

                    if (line.Contains("ret"))
                    {
                        var reverslist = ilInstructionCollection.AsEnumerable().Reverse().Take(ILCodeLineCount).Reverse().ToList();


                        using (StreamReader reader = new StreamReader(HookedContext))
                        {
                            string json = reader.ReadToEnd();

                            staticInstruction = JsonConvert.DeserializeObject<List<ILInstruction>>(json);

                            staticInstruction.ForEach(x => x.MethodName = methodSignature);
                        }


                        var ldlocLine = reverslist.Where(x => x.OpCode.Contains("ldloc")).FirstOrDefault();

                        if (ldlocLine != null && !ldlocLine.IsAdded)
                        {
                            staticInstruction.AddRange(reverslist);

                            //sb.Replace(ldlocLine.FullStatement, string.Empty);

                            ReArrangeILInstruction(staticInstruction);

                            for (int counter = 0; counter < staticInstruction.Count(); counter++)
                            {
                                string statment = string.Format("    {0} {1}        {2}", staticInstruction[counter].NewILHexCode, staticInstruction[counter].OpCode, staticInstruction[counter].Instruction);
                                sb.AppendLine(statment);
                            }
                        }
                        else
                        {
                            staticInstruction.Add(reverslist.LastOrDefault());
                            ReArrangeILInstruction(staticInstruction);

                            for (int counter = 0; counter < staticInstruction.Count(); counter++)
                            {
                                string statment = string.Format("    {0} {1}        {2}", staticInstruction[counter].NewILHexCode, staticInstruction[counter].OpCode, staticInstruction[counter].Instruction);
                                sb.AppendLine(statment);
                            }
                        }
                    }
                    else
                    {
                        sb.AppendLine(line);
                    }
                }

                methodTemplate = UpdateOldILInstructionReferences(staticInstruction, sb.ToString());
            }
            else
            {
                methodTemplate = methodContent;
            }

            return methodTemplate;
        }

        private static string UpdateOldILInstructionReferences(List<ILInstruction> staticInstruction, string methodString)
        {
            string template = string.Empty;

            var opcode = staticInstruction.Where(x => x.OpCode.Contains("ldloc")).FirstOrDefault();

            if (opcode != null && !opcode.IsAdded)
            {

                template = methodString.Replace(opcode.OldILHexCode.TrimEnd(':'), opcode.NewILHexCode.TrimEnd(':'));
            }
            else
            {
                template = methodString;
            }

            return template;
        }

        private static void ReArrangeILInstruction(List<ILInstruction> staticInstruction)
        {
            GenerateNewILCodeForInstructions(staticInstruction, "ret");
        }

        private static void GenerateNewILCodeForInstructions(List<ILInstruction> ILInstructions, string startFrom = null)
        {
            var lastInstruction = ILInstructions.Single(x => x.OpCode.ToLower() == startFrom.ToLower());

            string tempHexCode = lastInstruction.OldILHexCode;

            foreach (var iLInstruction in ILInstructions)
            {

                iLInstruction.NewILHexCode = tempHexCode;

                var hexcode = ExtractHexCode(tempHexCode);

                int intFromHex = int.Parse(hexcode, System.Globalization.NumberStyles.HexNumber) + 1;

                string hexValue = intFromHex.ToString("X");

                switch (hexValue.Length)
                {
                    case 3:
                        tempHexCode = "IL_0" + hexValue + ":";
                        break;
                    case 2:
                        tempHexCode = "IL_00" + hexValue + ":";
                        break;
                    case 1:
                        tempHexCode = "IL_000" + hexValue + ":";
                        break;
                }
            }
        }

        private static string ExtractHexCode(string ilhexcode)
        {
            string hexCode = string.Empty;

            var colonIdx = ilhexcode.IndexOf(':');

            if (colonIdx > -1)
            {
                var leftString = ilhexcode.Substring(0, colonIdx).Trim();

                var underScoreIdx = leftString.IndexOf('_') + 1;

                hexCode = leftString.Substring(underScoreIdx);
            }

            return hexCode;
        }

        public static string RemoveCommentedLines(string classText)
        {
            var blockComments = @"/\*(.*?)\*/";
            var lineComments = @"//(.*?)\r?\n";
            var strings = @"""((\\[^\n]|[^""\n])*)""";
            var verbatimStrings = @"@(""[^""]*"")+";


            string noComments = Regex.Replace(classText,
                                                blockComments + "|" + lineComments + "|" + strings + "|" + verbatimStrings,
                                                me =>
                                                {
                                                    if (me.Value.StartsWith("/*") || me.Value.StartsWith("//"))
                                                        return me.Value.StartsWith("//") ? Environment.NewLine : "";
                                                    // Keep the literal strings
                                                    return me.Value;
                                                },
                                                RegexOptions.Singleline);

            return noComments;
        }

        private static string GetMethodSignature(string methodText)
        {
            var firstBracIndex = methodText.IndexOf('{');

            var methodAssemblySig = methodText.Substring(0, firstBracIndex);

            var hidebysig = "hidebysig";

            var sigArray = methodAssemblySig.Split(new[] { hidebysig }, StringSplitOptions.None);

            var lastString = sigArray.LastOrDefault();

            var lastIndexofBrack = lastString.LastIndexOf(')') + 1;

            var signature = lastString.Substring(0, lastIndexofBrack).TrimStart();

            return signature;
        }

        internal static void GetServiceContractInfo(Dictionary<Guid, string> allClass)
        {
            throw new NotImplementedException();
        }

        private static void GetSourceCodeLinesFromIL(string methodText)
        {
            StringBuilder sb_sample = new StringBuilder();

            sb_sample.AppendLine("    .method private hidebysig static void  Main(string[] args) cil managed");
            sb_sample.AppendLine("  {");
            sb_sample.AppendLine("    .entrypoint");
            sb_sample.AppendLine("    // Code size       19 (0x13)");
            sb_sample.AppendLine("    .maxstack  8");
            sb_sample.AppendLine(@"// Source File 'C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\Program.cs'");
            sb_sample.AppendLine("//000033:         {");
            sb_sample.AppendLine("    IL_0000:  nop");
            sb_sample.AppendLine("//000034:             //GenericInitializeFactory();");
            sb_sample.AppendLine("//000035:             InitializeFactory();");
            sb_sample.AppendLine("    IL_0001:  call       int32 ChannelFactorySample.Program::InitializeFactory()");
            sb_sample.AppendLine("    IL_0006:  pop");
            sb_sample.AppendLine("//000036:             Console.WriteLine(\"Executed\");");
            sb_sample.AppendLine("    IL_0007:  ldstr      \"Executed\"");
            sb_sample.AppendLine("    IL_000c:  call       void [mscorlib]System.Console::WriteLine(string)");
            sb_sample.AppendLine("    IL_0011:  nop ");
            sb_sample.AppendLine("//000037:             //Console.ReadLine();");
            sb_sample.AppendLine("//000038:         } ");
            sb_sample.AppendLine("    IL_0012:  ret");
            sb_sample.AppendLine("}");


            StringBuilder sb = new StringBuilder();
            using (StringReader reader = new StringReader(methodText))
            {
                while (true)
                {
                    string line = reader.ReadLine();

                    if (line == null)
                    { break; }

                    if (line.StartsWith("//"))
                        sb.AppendLine(line);

                }
                File.WriteAllLines(Environment.CurrentDirectory + "\\SoucreMethod,txt", new[] { sb.ToString() });
            }
        }
        /// <summary>
        /// Get methods local fields
        /// </summary>
        /// <param name="methodString"></param>
        /// <returns></returns>
        public static List<ILLocalField> GetMethodLocalFileds(string methodString = null)
        {
            List<ILLocalField> ilLocalField = new List<ILLocalField>();

            StringBuilder sb_lcfld = new StringBuilder();
            sb_lcfld.Append("   .locals init([0] class [System.ServiceModel] System.ServiceModel.ChannelFactory`1<class ChannelFactorySample.ICalculater> channelFactoryAtmethodLevel,");
            sb_lcfld.Append("[1] class ChannelFactorySample.ICalculater inst,");
            sb_lcfld.Append("[2] int32 output,");
            sb_lcfld.Append("[3] int32 V_3)");


            var str = sb_lcfld.ToString();

            var lcfldIdx = str.IndexOf(".locals");

            if (lcfldIdx > -1)
            {
                var openingParanthisBracktIdx = str.IndexOf("(") + 1;
                var closingParanthisBracktIdx = str.IndexOf(")");

                var arrayStr = str.Substring(openingParanthisBracktIdx, closingParanthisBracktIdx - openingParanthisBracktIdx);
                var splitstr = arrayStr.Split(',');

                //var isChannelFactoryExists = Array.IndexOf(splitstr, "[0] class [System.ServiceModel] System.ServiceModel.ChannelFactory`1<class ChannelFactorySample.ICalculater> channelFactoryAtmethodLevel");

                var isChannelFactoryExists = Array.Exists(splitstr, elm => elm.Contains("System.ServiceModel.ChannelFactory"));

                if (isChannelFactoryExists)
                {
                    var bracsplit = str.Split('(', ')')[1];
                    var commasplitstr = bracsplit.Split(',');

                    foreach (var line in commasplitstr)
                    {
                        ILLocalField ilLocalFieldObj = new ILLocalField();

                        var openingBracketIdx = line.IndexOf('[') + 1;
                        var closingBracketIdx = line.IndexOf(']');

                        ilLocalFieldObj.FieldIndex = line.Substring(openingBracketIdx, closingBracketIdx - openingBracketIdx);
                        ilLocalFieldObj.LocalField = line.Substring(closingBracketIdx + 1);
                        ilLocalField.Add(ilLocalFieldObj);
                    }
                }

            }
            return ilLocalField;

        }
    }
}