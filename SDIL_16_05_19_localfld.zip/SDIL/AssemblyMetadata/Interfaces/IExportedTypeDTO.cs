﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public interface IExportedTypeDTO
    {
        int Count { get; set; }
        string[] FullName { get; set; }
    }
}
