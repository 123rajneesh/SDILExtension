﻿namespace ILMaker
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.tbx_File = new System.Windows.Forms.TextBox();
            this.btn_selectFile = new System.Windows.Forms.Button();
            this.Btn_Generate = new System.Windows.Forms.Button();
            this.btn_Outputpath = new System.Windows.Forms.Button();
            this.tbx_OutPath = new System.Windows.Forms.TextBox();
            this.lbl_inputFile = new System.Windows.Forms.Label();
            this.lbl_outputILFile = new System.Windows.Forms.Label();
            this.lbl_sts = new System.Windows.Forms.Label();
            this.gb_radio_btn = new System.Windows.Forms.GroupBox();
            this.rdb_EXEtoIL = new System.Windows.Forms.RadioButton();
            this.rdb_ILtoEXE = new System.Windows.Forms.RadioButton();
            this.panel_converter = new System.Windows.Forms.Panel();
            this.btn_injectCode = new System.Windows.Forms.Button();
            this.gb_radio_btn.SuspendLayout();
            this.panel_converter.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbx_File
            // 
            this.tbx_File.Location = new System.Drawing.Point(10, 20);
            this.tbx_File.Name = "tbx_File";
            this.tbx_File.Size = new System.Drawing.Size(538, 20);
            this.tbx_File.TabIndex = 0;
            // 
            // btn_selectFile
            // 
            this.btn_selectFile.Location = new System.Drawing.Point(553, 18);
            this.btn_selectFile.Name = "btn_selectFile";
            this.btn_selectFile.Size = new System.Drawing.Size(128, 23);
            this.btn_selectFile.TabIndex = 1;
            this.btn_selectFile.Text = "Select File";
            this.btn_selectFile.UseVisualStyleBackColor = true;
            this.btn_selectFile.Click += new System.EventHandler(this.btn_selectFile_Click);
            // 
            // Btn_Generate
            // 
            this.Btn_Generate.Location = new System.Drawing.Point(13, 86);
            this.Btn_Generate.Name = "Btn_Generate";
            this.Btn_Generate.Size = new System.Drawing.Size(128, 31);
            this.Btn_Generate.TabIndex = 2;
            this.Btn_Generate.Text = "Generate";
            this.Btn_Generate.UseVisualStyleBackColor = true;
            this.Btn_Generate.Click += new System.EventHandler(this.Btn_Generate_Click);
            // 
            // btn_Outputpath
            // 
            this.btn_Outputpath.Location = new System.Drawing.Point(553, 60);
            this.btn_Outputpath.Name = "btn_Outputpath";
            this.btn_Outputpath.Size = new System.Drawing.Size(128, 20);
            this.btn_Outputpath.TabIndex = 4;
            this.btn_Outputpath.Text = "Select Output File Path";
            this.btn_Outputpath.UseVisualStyleBackColor = true;
            this.btn_Outputpath.Click += new System.EventHandler(this.btn_Outputpath_Click);
            // 
            // tbx_OutPath
            // 
            this.tbx_OutPath.Location = new System.Drawing.Point(10, 60);
            this.tbx_OutPath.Name = "tbx_OutPath";
            this.tbx_OutPath.ReadOnly = true;
            this.tbx_OutPath.Size = new System.Drawing.Size(538, 20);
            this.tbx_OutPath.TabIndex = 3;
            // 
            // lbl_inputFile
            // 
            this.lbl_inputFile.AutoSize = true;
            this.lbl_inputFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_inputFile.Location = new System.Drawing.Point(10, 7);
            this.lbl_inputFile.Name = "lbl_inputFile";
            this.lbl_inputFile.Size = new System.Drawing.Size(124, 13);
            this.lbl_inputFile.TabIndex = 5;
            this.lbl_inputFile.Text = "Input File (exe | dll) :";
            // 
            // lbl_outputILFile
            // 
            this.lbl_outputILFile.AutoSize = true;
            this.lbl_outputILFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_outputILFile.Location = new System.Drawing.Point(10, 44);
            this.lbl_outputILFile.Name = "lbl_outputILFile";
            this.lbl_outputILFile.Size = new System.Drawing.Size(100, 13);
            this.lbl_outputILFile.TabIndex = 6;
            this.lbl_outputILFile.Text = "Output File (IL) :";
            // 
            // lbl_sts
            // 
            this.lbl_sts.AutoSize = true;
            this.lbl_sts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sts.Location = new System.Drawing.Point(42, 134);
            this.lbl_sts.Name = "lbl_sts";
            this.lbl_sts.Size = new System.Drawing.Size(43, 13);
            this.lbl_sts.TabIndex = 7;
            this.lbl_sts.Text = "Status";
            // 
            // gb_radio_btn
            // 
            this.gb_radio_btn.Controls.Add(this.rdb_EXEtoIL);
            this.gb_radio_btn.Controls.Add(this.rdb_ILtoEXE);
            this.gb_radio_btn.Location = new System.Drawing.Point(12, 12);
            this.gb_radio_btn.Name = "gb_radio_btn";
            this.gb_radio_btn.Size = new System.Drawing.Size(348, 46);
            this.gb_radio_btn.TabIndex = 11;
            this.gb_radio_btn.TabStop = false;
            this.gb_radio_btn.Text = "groupBox_radio";
            // 
            // rdb_EXEtoIL
            // 
            this.rdb_EXEtoIL.AutoSize = true;
            this.rdb_EXEtoIL.Location = new System.Drawing.Point(177, 17);
            this.rdb_EXEtoIL.Name = "rdb_EXEtoIL";
            this.rdb_EXEtoIL.Size = new System.Drawing.Size(110, 17);
            this.rdb_EXEtoIL.TabIndex = 1;
            this.rdb_EXEtoIL.TabStop = true;
            this.rdb_EXEtoIL.Text = "Convert EXE to IL";
            this.rdb_EXEtoIL.UseVisualStyleBackColor = true;
            this.rdb_EXEtoIL.CheckedChanged += new System.EventHandler(this.rdb_EXEtoIL_CheckedChanged);
            // 
            // rdb_ILtoEXE
            // 
            this.rdb_ILtoEXE.AutoSize = true;
            this.rdb_ILtoEXE.Location = new System.Drawing.Point(31, 17);
            this.rdb_ILtoEXE.Name = "rdb_ILtoEXE";
            this.rdb_ILtoEXE.Size = new System.Drawing.Size(110, 17);
            this.rdb_ILtoEXE.TabIndex = 0;
            this.rdb_ILtoEXE.TabStop = true;
            this.rdb_ILtoEXE.Text = "Convert IL to EXE";
            this.rdb_ILtoEXE.UseVisualStyleBackColor = true;
            this.rdb_ILtoEXE.CheckedChanged += new System.EventHandler(this.rdb_ILtoEXE_CheckedChanged);
            // 
            // panel_converter
            // 
            this.panel_converter.Controls.Add(this.tbx_File);
            this.panel_converter.Controls.Add(this.btn_selectFile);
            this.panel_converter.Controls.Add(this.lbl_sts);
            this.panel_converter.Controls.Add(this.Btn_Generate);
            this.panel_converter.Controls.Add(this.lbl_outputILFile);
            this.panel_converter.Controls.Add(this.tbx_OutPath);
            this.panel_converter.Controls.Add(this.lbl_inputFile);
            this.panel_converter.Controls.Add(this.btn_Outputpath);
            this.panel_converter.Enabled = false;
            this.panel_converter.Location = new System.Drawing.Point(12, 78);
            this.panel_converter.Name = "panel_converter";
            this.panel_converter.Size = new System.Drawing.Size(776, 163);
            this.panel_converter.TabIndex = 12;
            // 
            // btn_injectCode
            // 
            this.btn_injectCode.Location = new System.Drawing.Point(309, 278);
            this.btn_injectCode.Name = "btn_injectCode";
            this.btn_injectCode.Size = new System.Drawing.Size(128, 31);
            this.btn_injectCode.TabIndex = 13;
            this.btn_injectCode.Text = "Inject code to IL";
            this.btn_injectCode.UseVisualStyleBackColor = true;
            this.btn_injectCode.Click += new System.EventHandler(this.btn_injectCode_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_injectCode);
            this.Controls.Add(this.panel_converter);
            this.Controls.Add(this.gb_radio_btn);
            this.Name = "Main";
            this.Text = "Main";
            this.gb_radio_btn.ResumeLayout(false);
            this.gb_radio_btn.PerformLayout();
            this.panel_converter.ResumeLayout(false);
            this.panel_converter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog dlgOpenFile;
        private System.Windows.Forms.TextBox tbx_File;
        private System.Windows.Forms.Button btn_selectFile;
        private System.Windows.Forms.Button Btn_Generate;
        private System.Windows.Forms.Button btn_Outputpath;
        private System.Windows.Forms.TextBox tbx_OutPath;
        private System.Windows.Forms.Label lbl_inputFile;
        private System.Windows.Forms.Label lbl_outputILFile;
        private System.Windows.Forms.Label lbl_sts;
        private System.Windows.Forms.GroupBox gb_radio_btn;
        private System.Windows.Forms.RadioButton rdb_EXEtoIL;
        private System.Windows.Forms.RadioButton rdb_ILtoEXE;
        private System.Windows.Forms.Panel panel_converter;
        private System.Windows.Forms.Button btn_injectCode;
    }
}