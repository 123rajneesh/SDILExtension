using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhoIsCaller
{
    class Program
    {
        private static int sum = 0;

        static string msg = "Hello";
        private static void Main(string[] arg)
        {
            GetMethodLocalFileds(null);
            //WriteMessage();
            //sum = Program.AddTwoNumbers(4, 2);
            Console.WriteLine(Program.sum);
            //Console.ReadLine();
            //File.AppendAllText(@"C:\Users\rajneesh.kumar\source\repos\SDIL\WhoIsCaller\code\", "some text here.");
        }

        public static int AddTwoNumbers(int a, int b)
        {
            //File.AppendAllText("C:\\Users\\rajneesh.kumar\\source\\repos\\SDIL\\WhoIsCaller\\Code\\result.txt", @"{'method':'" + System.Reflection.MethodBase.GetCurrentMethod().ToString() + "','Type':'" + b + "','param':" + string.Join(",", System.Reflection.MethodBase.GetCurrentMethod().GetParameters().Select(x => x.Name).ToArray()) + "}");

            //File.AppendAllText("C:\\Users\\rajneesh.kumar\\source\\repos\\SDIL\\WhoIsCaller\\Code\\result.txt", @"{'method':'" + System.Reflection.MethodBase.GetCurrentMethod().ToString() + "','Type':'" + b + "'}");

            a = 7; b = 5;
            int c = 100;
            if (a > b)
                return a - b;
            return a + b;
        }
        /*
         public static string WriteMessage()
         {
             GetSourceCodeLinesFromIL();

             var chnl = "new ChannelFactory<ICalculater>(binding, endpoint).asdasda()";

             var factoryText = chnl.Contains("ChannelFactory");
             var factoryTextIdx = chnl.IndexOf("ChannelFactory");

             var less = chnl.Contains("<");
             var lssidx = chnl.IndexOf("<");

             var more = chnl.Contains(">");
             var moridx = chnl.IndexOf(">");

             var chtxt = chnl.Substring(4, 14);

             return "Hello World";
         }

         private static void GetSourceCodeLinesFromIL()
         {
             StringBuilder sb_sample = new StringBuilder();

             sb_sample.AppendLine("    .method private hidebysig static void  Main(string[] args) cil managed");
             sb_sample.AppendLine("  {");
             sb_sample.AppendLine("    .entrypoint");
             sb_sample.AppendLine("    // Code size       19 (0x13)");
             sb_sample.AppendLine("    .maxstack  8");
             sb_sample.AppendLine(@"// Source File 'C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\Program.cs'");
             sb_sample.AppendLine("//000033:         {");
             sb_sample.AppendLine("    IL_0000:  nop");
             sb_sample.AppendLine("//000034:             //GenericInitializeFactory();");
             sb_sample.AppendLine("//000035:             InitializeFactory();");
             sb_sample.AppendLine("    IL_0001:  call       int32 ChannelFactorySample.Program::InitializeFactory()");
             sb_sample.AppendLine("    IL_0006:  pop");
             sb_sample.AppendLine("//000036:             Console.WriteLine(\"Executed\");");
             sb_sample.AppendLine("    IL_0007:  ldstr      \"Executed\"");
             sb_sample.AppendLine("    IL_000c:  call       void [mscorlib]System.Console::WriteLine(string)");
             sb_sample.AppendLine("    IL_0011:  nop ");
             sb_sample.AppendLine("//000037:             //Console.ReadLine();");
             sb_sample.AppendLine("//000038:         } ");
             sb_sample.AppendLine("    IL_0012:  ret");
             sb_sample.AppendLine("}");


             StringBuilder sb = new StringBuilder();

             using (StringReader reader = new StringReader(sb_sample.ToString()))
             {
                 while (true)
                 {
                     string line = reader.ReadLine();

                     if (line == null)
                     { break; }

                     if (line.StartsWith("//"))
                         sb.AppendLine(line);

                 }
             }
           
    }  */


        static void GetLocalFileds()
        {

            StringBuilder sb_lcfld = new StringBuilder();
            sb_lcfld.Append("   .locals init([0] class [System.ServiceModel] System.ServiceModel.ChannelFactory`1<class ChannelFactorySample.ICalculater> channelFactoryAtmethodLevel,");
            sb_lcfld.Append("[1] class ChannelFactorySample.ICalculater inst,");
            sb_lcfld.Append("[2] int32 output,");
            sb_lcfld.Append("[3] int32 V_3)");


            var str = sb_lcfld.ToString();

            var lcfldIdx = str.IndexOf(".locals");

            if (lcfldIdx > -1)
            {
                var openingParanthisBracktIdx = str.IndexOf("(") + 1;
                var closingParanthisBracktIdx = str.IndexOf(")");

                var arrayStr = str.Substring(openingParanthisBracktIdx, closingParanthisBracktIdx - openingParanthisBracktIdx);
                var splitstr = arrayStr.Split(',');

                var bracsplit = str.Split('(', ')')[1];
                var commasplitstr = bracsplit.Split(',');

                foreach (var line in commasplitstr)
                {
                    var openingBracketIdx = line.IndexOf('[') + 1;
                    var closingBracketIdx = line.IndexOf(']');

                    var fldIndexValue = line.Substring(openingBracketIdx, closingBracketIdx - openingBracketIdx);
                    var fldName = line.Substring(closingBracketIdx + 1);
                }

            }


        }

        static void GetMethodLocalFileds(string methodString = null)
        {

            StringBuilder sb_lcfld = new StringBuilder();
            //sb_lcfld.Append("   .locals init([0] class [System.ServiceModel] System.ServiceModel.ChannelFactory`1<class ChannelFactorySample.ICalculater> channelFactoryAtmethodLevel,");
            //sb_lcfld.Append("[1] class ChannelFactorySample.ICalculater inst,");
            //sb_lcfld.Append("[2] int32 output,");
            //sb_lcfld.Append("[3] int32 V_3)");

            sb_lcfld.Append(".method private hidebysig static void  InitializeFactory() cil managed");
            sb_lcfld.Append("{");
            sb_lcfld.Append("// Code size       61 (0x3d)");
            sb_lcfld.Append(".maxstack  3");
            sb_lcfld.Append(".locals init ([0] class [System.ServiceModel]System.ServiceModel.ChannelFactory`1<class ChannelFactorySample.ICalculater> channelFactory,");
            sb_lcfld.Append("[1] class [System.ServiceModel]System.ServiceModel.NetTcpBinding binding,");
            sb_lcfld.Append("[2] class [System.ServiceModel]System.ServiceModel.EndpointAddress endpoint,");
            sb_lcfld.Append("[3] class ChannelFactorySample.ICalculater serviceClient,");
            sb_lcfld.Append("[4] int32 result)");


            var str = sb_lcfld.ToString();

            var lcfldIdx = str.IndexOf(".locals");

            var lastParenthisIdx = str.LastIndexOf(")");

            var localFldStr = str.Substring(lcfldIdx+1, lastParenthisIdx - lcfldIdx);

            if (lcfldIdx > -1)
            {
                var openingParanthisBracktIdx = localFldStr.IndexOf("(") + 1;
                var closingParanthisBracktIdx = localFldStr.IndexOf(")");

                var arrayStr = localFldStr.Substring(openingParanthisBracktIdx, closingParanthisBracktIdx - openingParanthisBracktIdx);
                var splitstr = arrayStr.Split(',');

                //var isChannelFactoryExists = Array.IndexOf(splitstr, "[0] class [System.ServiceModel] System.ServiceModel.ChannelFactory`1<class ChannelFactorySample.ICalculater> channelFactoryAtmethodLevel");

                var isChannelFactoryExists = Array.Exists(splitstr, elm => elm.Contains("System.ServiceModel.ChannelFactory"));

                if (isChannelFactoryExists)
                {
                    var bracsplit = localFldStr.Split('(', ')')[1];
                    var commasplitstr = bracsplit.Split(',');

                    foreach (var line in commasplitstr)
                    {
                        var openingBracketIdx = line.IndexOf('[') + 1;
                        var closingBracketIdx = line.IndexOf(']');

                        var fldIndexValue = line.Substring(openingBracketIdx, closingBracketIdx - openingBracketIdx);
                        var fldName = line.Substring(closingBracketIdx + 1);
                    }
                }

            }


        }
    }
}
