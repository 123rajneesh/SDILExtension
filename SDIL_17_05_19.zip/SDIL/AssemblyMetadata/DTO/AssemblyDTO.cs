﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public class AssemblyDTO : IAssemblyDTO
    {
        public AssemblyDTO()
        {
            this.DefinedTypeDTO = new DefinedTypeDTO();
            this.ExportedTypeDTO = new ExportedTypeDTO();
        }
        public string Name { get; set; }
        public string FullName { get; set; }
        public string CodeBase { get; set; }
        public IDefinedTypeDTO DefinedTypeDTO { get; set; }
        public IExportedTypeDTO ExportedTypeDTO { get; set; }
        public int Count { get; set; }
        public bool IsPublic { get; set; }
        public bool IsPrivate { get; set; }
    }
}