﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public class DefinedTypeDTO : IDefinedTypeDTO
    {
        public int Count { get ; set ; }
        public string[] FullName { get ; set ; }
    }
}
