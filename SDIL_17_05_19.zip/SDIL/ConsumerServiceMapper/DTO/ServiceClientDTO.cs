﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumerServiceMapper.DTO
{
    public class ServiceClientDTO
    {
        public ServiceClientDTO()
        {
            this.Methods = new List<Method>();
        }

        public string ClassName { get; set; }
        public bool IsInterface { get; set; }
        public string AssemblyName { get; set; }
        public string FullName { get; set; }
        public string TypeName { get; set; }
        public string Namespace { get; set; }
        public List<Method> Methods { get; set; }
    }
    public class Method
    {
        public string MethodName { get; set; }
        public string MethodFullName { get; set; }
        public List<string> MethodParmeters { get; set; }
        public string MethodReturnType { get; set; }
        public string MethodSignature { get; set; }
    }

}
