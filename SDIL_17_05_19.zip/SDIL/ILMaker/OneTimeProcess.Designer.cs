﻿namespace ILMaker
{
    partial class OneTimeProcess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbx_File = new System.Windows.Forms.TextBox();
            this.btn_selectFile = new System.Windows.Forms.Button();
            this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.lbl_inputFile = new System.Windows.Forms.Label();
            this.lbl_sts = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbl_sts);
            this.panel1.Controls.Add(this.lbl_inputFile);
            this.panel1.Controls.Add(this.tbx_File);
            this.panel1.Controls.Add(this.btn_selectFile);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 122);
            this.panel1.TabIndex = 0;
            // 
            // tbx_File
            // 
            this.tbx_File.Location = new System.Drawing.Point(20, 35);
            this.tbx_File.Name = "tbx_File";
            this.tbx_File.Size = new System.Drawing.Size(556, 20);
            this.tbx_File.TabIndex = 2;
            // 
            // btn_selectFile
            // 
            this.btn_selectFile.Location = new System.Drawing.Point(582, 13);
            this.btn_selectFile.Name = "btn_selectFile";
            this.btn_selectFile.Size = new System.Drawing.Size(164, 62);
            this.btn_selectFile.TabIndex = 3;
            this.btn_selectFile.Text = "Select File (exe | dll) To inject Code\r\n";
            this.btn_selectFile.UseVisualStyleBackColor = true;
            this.btn_selectFile.Click += new System.EventHandler(this.btn_selectFile_Click);
            // 
            // lbl_inputFile
            // 
            this.lbl_inputFile.AutoSize = true;
            this.lbl_inputFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_inputFile.Location = new System.Drawing.Point(17, 19);
            this.lbl_inputFile.Name = "lbl_inputFile";
            this.lbl_inputFile.Size = new System.Drawing.Size(124, 13);
            this.lbl_inputFile.TabIndex = 6;
            this.lbl_inputFile.Text = "Input File (exe | dll) :";
            // 
            // lbl_sts
            // 
            this.lbl_sts.AllowDrop = true;
            this.lbl_sts.AutoEllipsis = true;
            this.lbl_sts.AutoSize = true;
            this.lbl_sts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sts.Location = new System.Drawing.Point(17, 92);
            this.lbl_sts.Name = "lbl_sts";
            this.lbl_sts.Size = new System.Drawing.Size(37, 13);
            this.lbl_sts.TabIndex = 8;
            this.lbl_sts.Text = "Status";
            // 
            // OneTimeProcess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "OneTimeProcess";
            this.Text = "One Time Process";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbx_File;
        private System.Windows.Forms.Button btn_selectFile;
        private System.Windows.Forms.OpenFileDialog dlgOpenFile;
        private System.Windows.Forms.Label lbl_inputFile;
        private System.Windows.Forms.Label lbl_sts;
    }
}