﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NewSDILReaderTest
{
    public partial class GenerateCode : Form
    {
        public GenerateCode()
        {
            InitializeComponent();
        }

        private void btnOpenAssembly_Click(object sender, EventArgs e)
        {
            dlgOpenFile.ShowDialog();

            try
            {
                if (dlgOpenFile.CheckFileExists)
                {
                    string fileName = dlgOpenFile.FileName;

                    lbl_fleName.Text = fileName;

                    RunCommandToGenerateILCode(fileName);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void RunCommandToGenerateILCode(string filename)
        {
            //string ildasmCMD = string.Format(@"CD {0}\tools\ ildasm {1}   /output:{0}\{2}.il", Config.ProjectDirectory, filename, Path.GetFileNameWithoutExtension(filename));


            string ildasmCMD = string.Format(@"cd {0} ildasm {1}   /output:{2}\{3}.il", Config.Ildasm, filename, Config.ProjectDirectory, Path.GetFileNameWithoutExtension(filename));


            StringBuilder sb = new StringBuilder();
            sb.Append($"cd {Config.Ildasm}\n");
            sb.Append($" ildasm {filename}   /output:{Config.ProjectDirectory}\\{Path.GetFileNameWithoutExtension(filename)}.il");
            ExecuteCommandSync(sb.ToString());

        }

        public void ExecuteCommandSync(string command)
        {
            try
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                startInfo.FileName = "cmd.exe";
                startInfo.Arguments = command;
                startInfo.UseShellExecute = false;
                process.StartInfo = startInfo;
                process.Start();
            }
            catch (Exception objException)
            {
                // Log the exception
            }
        }
    }
}
