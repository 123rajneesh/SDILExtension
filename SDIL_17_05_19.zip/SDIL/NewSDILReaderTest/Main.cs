﻿using ConsumerServiceMapper;
using ConsumerServiceMapper.DTO;
using SDILReader;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NewSDILReaderTest
{
    public partial class Main : Form
    {
        private static string assemblyPath = string.Empty;

        List<FieldInfo> fieldinfo = new List<FieldInfo>();

        public List<MethodInfo> methods = new List<MethodInfo>();

        List<string> formatedMethodCalling = new List<string>();

        List<ILCLRINFO> _ilclrinfo = null;

        ServiceClientDTO clientDTO = null;

        public int option = (int)Setting.DEFAULTSHOW;

        public Main()
        {
            Globals.LoadOpCodes();
            InitializeComponent();
        }

        private void btnOpenAssembly_Click(object sender, EventArgs e)
        {
            ServiceConfigDTO configClient = ServiceConfigMapper.ExtractWCFConfiguration(@"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\Web\web.config");

            clientDTO = ServiceClientMapper.ReadMock();


            // clear the methods cache
            methods.Clear();

            // clear the listview with the available methods
            lbAvailableMethodsList.Items.Clear();

            dlgOpenAssembly.ShowDialog();

            if (dlgOpenAssembly.CheckFileExists)
            {
                assemblyPath = dlgOpenAssembly.FileName;

                switch (option)
                {
                    case (int)Setting.SHOWMETHODONLY:
                        ShowMethods();
                        break;
                    case (int)Setting.SHOWMETHODANDTYPE:
                        ShowMethodsWithTypes(configClient);
                        break;
                    case (int)Setting.DEFAULTSHOW:
                    default:

                        break;
                }

                btn_AsmDtl.Visible = true;
            }
            else
            {
                MessageBox.Show("No assembly loadded !");
            }
        }

        private void ShowMethods()
        {
            try
            {// load the assembly
                Assembly ass = Assembly.LoadFrom(assemblyPath);

                // get all the methods within the loaded assembly
                Module[] modules = ass.GetModules();

                for (int i = 0; i < modules.Length; i++)
                {
                    Type[] types = modules[i].GetTypes();
                    for (int k = 0; k < types.Length; k++)
                    {
                        MethodInfo[] mis = types[k].GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance);
                        for (int j = 0; j < mis.Length; j++)
                        {
                            // check if the method has a body
                            if (mis[j].GetMethodBody() != null)
                            {
                                methods.Add(mis[j]);
                                lbAvailableMethodsList.Items.Add(mis[j].Name);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Invalid Assembly Error: {ex.ToString()}");
            }
        }

        private void ShowMethodsWithTypes(ServiceConfigDTO configClient)
        {
            try
            {
                Assembly ass = Assembly.LoadFrom(assemblyPath);

                // get all the methods within the loaded assembly
                Module[] modules = ass.GetModules();

                for (int i = 0; i < modules.Length; i++)
                {
                    Type[] types = modules[i].GetTypes();

                    //parse Method IL code
                    GetMethodOFTypes(configClient, types);

                    //parse Field IL code
                    GetFieldsOFType(configClient, types);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Invalid Assembly Error: {ex.ToString()}");
            }
        }

        private void GetFieldsOFType(ServiceConfigDTO configClient, Type[] types)
        {
            //parse Field IL code
            for (int k = 0; k < types.Length; k++)
            {
                FieldInfo[] fis = types[k].GetFields(BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance);

                for (int j = 0; j < fis.Length; j++)
                {
                    // check if the method has a body
                    if (fis[j] != null)
                    {
                        fieldinfo.Add(fis[j]);

                        string fieldDetail = string.Format("Class:  {0},  Field Type:{1},  Field Name:  {2}", types[k].Name, fis[j].FieldType.Name, fis[j].Name);

                        foreach (var ep in configClient.Endpoints)
                        {
                            if (ep.Contract.Contains(types[k].Name))
                            {
                                lbl_slctdMthd.Text = ep.Contract + "---" + types[k].Name;
                            }
                        }
                        lbAvailableFieldList.Items.Add(fieldDetail);
                    }
                }
            }
        }

        private void GetMethodOFTypes(ServiceConfigDTO configClient, Type[] types)
        {
            for (int k = 0; k < types.Length; k++)
            {
                MethodInfo[] mis = types[k].GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance);
                for (int j = 0; j < mis.Length; j++)
                {
                    // check if the method has a body
                    if (mis[j].GetMethodBody() != null)
                    {
                        methods.Add(mis[j]);

                        string methodDetail = string.Format("Type:  {0},    Method:  {1}", types[k].Name, mis[j].Name);

                        foreach (var ep in configClient.Endpoints)
                        {
                            if (ep.Contract.Contains(types[k].Name))
                            {
                                lbl_slctdMthd.Text = ep.Contract + "-----" + types[k].Name;
                            }
                        }
                        lbAvailableMethodsList.Items.Add(methodDetail);

                    }
                }
            }
        }

        private void lbAvailableMethodsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetRadioButtons();
            _ilclrinfo = new List<ILCLRINFO>();
            try
            {

                MethodInfo mi = methods[lbAvailableMethodsList.SelectedIndex];

                SDILReader.MethodBodyReader mr = new MethodBodyReader(mi);
                rchMethodBodyCode.Clear();
                string bodyCode = mr.GetBodyCode();
                _ilclrinfo = mr.GetBodyCodeInObject();
                rchMethodBodyCode.Text = bodyCode;
            }
            catch
            {

            }
        }

        private void lbAvailableFieldList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                FieldInfo fi = fieldinfo[lbAvailableFieldList.SelectedIndex];


                var val = fi.GetValue(null);
                //var GetRawConstantValue = fi.GetRawConstantValue();

                SDILReader.MethodBodyReader mr = new MethodBodyReader(fi.Module.GetMethods()[0]);

                //rchMethodBodyCode.Clear();

                //string bodyCode = mr.GetBodyCode();

                //_ilclrinfo = mr.GetBodyCodeInObject();

                //rchMethodBodyCode.Text = bodyCode;
            }
            catch
            {
                throw new Exception();
            }
        }

        private void rdb_shw_mth_CheckedChanged(object sender, EventArgs e)
        {
            option = (int)Setting.SHOWMETHODONLY;
        }

        private void rdb_shw_mth_typ_CheckedChanged(object sender, EventArgs e)
        {
            option = (int)Setting.SHOWMETHODANDTYPE;
        }

        private void rdb_fld_CheckedChanged(object sender, EventArgs e)
        {
            lbClrInfo.Items.Clear();
            var flds = _ilclrinfo.Select(f => f.Field).ToList();
            foreach (var f in flds)
            {
                if (!string.IsNullOrEmpty(f.Name) && !string.IsNullOrEmpty(f.FieldType))
                {
                    string filedDetail = string.Format("Field name: {0},      FieldType: {1},   Reflected Type: {2}\n", f.Name, f.FieldType, f.ReflectedType);
                    lbClrInfo.Items.Add(filedDetail);
                }
            }

        }

        BindingSource _bindingSource = new BindingSource();
        private void rdb_mthd_CheckedChanged(object sender, EventArgs e)
        {
            lbClrInfo.Items.Clear();

            List<InlineMethod> mthds = _ilclrinfo.Select(f => f.Method).ToList();

            var bindingList = new BindingList<InlineMethod>(mthds.Where(m => !string.IsNullOrEmpty(m.Name) && !string.IsNullOrEmpty(m.ReflectedType)).ToList());

            var source = new BindingSource(bindingList, null);

            dtgw_method.DataSource = source;


            foreach (var m in mthds)
            {
                if (!string.IsNullOrEmpty(m.Name) && !string.IsNullOrEmpty(m.ReflectedType))
                {
                    string filedDetail = string.Format("Method name: {0} | Return Type: {1} | Reflected Type: {2} | Signature: {3}\n", m.Name, m.ReturnType, m.ReflectedType, m.Signature);
                    lbClrInfo.Items.Add(filedDetail);
                }
            }
        }

        private void rdb_str_CheckedChanged(object sender, EventArgs e)
        {
            lbClrInfo.Items.Clear();
            var flds = _ilclrinfo.Select(f => f.String).ToList();
            foreach (var f in flds)
            {
                if (!string.IsNullOrEmpty(f.Value))
                {
                    string filedDetail = string.Format("Value: {0}\n", f.Value);
                    lbClrInfo.Items.Add(filedDetail);
                }
            }
        }

        private void ResetRadioButtons()
        {
            foreach (Control control in gb_filter.Controls)
            {
                if (control is RadioButton)
                {
                    RadioButton rb = control as RadioButton;
                    rb.Checked = false;
                }
            }
        }

        private void btn_AsmDtl_Click(object sender, EventArgs e)
        {
            var AssemblyInfo = new AssemblyInfo(assemblyPath);
            AssemblyInfo.Show();
        }

        private void btn_gntr_Click(object sender, EventArgs e)
        {
            var generatecodeFrm = new GenerateCode();
            generatecodeFrm.Show();
        }
    }

    public enum Setting
    {
        DEFAULTSHOW = 0,
        SHOWMETHODONLY = 1,
        SHOWMETHODANDTYPE = 2,


    }
}
