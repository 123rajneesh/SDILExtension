﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringEngine
{
    public class ILInstruction
    {
        public string MethodName { get; set; }
        public string OldILHexCode { get; set; }
        public string NewILHexCode { get; set; }
        public string OpCode { get; set; }
        public string Instruction { get; set; }
        public bool IsAdded { get; set; }
    }
    public class ILLocalField
    {
        public string FieldIndex { get; set; }
        public string LocalField { get; set; }
    }
}
