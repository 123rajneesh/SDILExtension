﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public class Info
    {
        private static AssemblyMetadata assemblyMetadata = new AssemblyMetadata();
        private static TypeMetdadata typeMetdadata = new TypeMetdadata();
        private static MethodMetadata methodMetadata = new MethodMetadata();

        public static AssemblyDTO GetAssemblyInfo(Assembly assembly)
        {
            return assemblyMetadata.GetAssemblyInfo(assembly);
        }

        public static List<TypeDTO> GetTypeInfo(Assembly assembly)
        {
            return typeMetdadata.GetTypeInfo(assembly);
        }

        public static List<MethodDTO> GetMethodInfo(Assembly assembly)
        {
            return methodMetadata.GetMethodInfo(assembly);
        }
    }
}
