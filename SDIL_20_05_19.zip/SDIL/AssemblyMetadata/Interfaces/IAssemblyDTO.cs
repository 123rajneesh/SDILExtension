﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    public interface IAssemblyDTO :IDTO
    {
        string CodeBase { get; set; }
        IDefinedTypeDTO DefinedTypeDTO { get; set; }
        IExportedTypeDTO ExportedTypeDTO { get; set; }
        
    }
}
