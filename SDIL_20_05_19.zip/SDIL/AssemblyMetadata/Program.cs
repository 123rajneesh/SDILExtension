using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Metadata
{
    class Program
    {
        static void Main(string[] args)
        {
            var asm = Assembly.LoadFrom(@"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\WCFProxyFactory\bin\Debug\WCFProxyFactory.exe");

            var asminfo = Info.GetAssemblyInfo(asm);
            var typinfo = Info.GetTypeInfo(asm);
            var methodinfo = Info.GetMethodInfo(asm);
        }
    }
}
