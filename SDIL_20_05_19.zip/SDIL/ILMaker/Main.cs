﻿using StringEngine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ILMaker
{
    public partial class Main : Form
    {
        public static string option = string.Empty;

        public static string Command { get; set; }

        public static string CommandWorkingDirectory { get; set; }

        public static string SelectedOutputDirectory { get; set; }

        public static string OutputFileName { get; set; }

        public static string InputFileNameWithoutExtns { get; set; }

        public string DialogFilter { get; set; }

        public Main()
        {
            InitializeComponent();
        }

        private void btn_selectFile_Click(object sender, EventArgs e)
        {
            dlgOpenFile.InitialDirectory = "C:\\Users\\rajneesh.kumar\\source\\repos\\";
            dlgOpenFile.Filter = DialogFilter;
            dlgOpenFile.RestoreDirectory = true;
            dlgOpenFile.ShowDialog();

            try
            {
                if (dlgOpenFile.CheckFileExists)
                {
                    tbx_File.Text = dlgOpenFile.FileName;
                    InputFileNameWithoutExtns = Path.GetFileNameWithoutExtension(tbx_File.Text);

                }
            }
            catch (Exception ex)
            {

            }
        }

        public void RunCommand(string command)
        {
            try
            {
                lbl_sts.Text = "Running...";

                ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
                //procStartInfo.WorkingDirectory = @"C:\Program Files (x86)\Microsoft SDKs\Windows\v10.0A\bin\\NETFX 4.6.1 Tools";
                //ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
                procStartInfo.WorkingDirectory = CommandWorkingDirectory;
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                procStartInfo.CreateNoWindow = true;

                // wrap IDisposable into using (in order to release hProcess) 
                using (Process process = new Process())
                {
                    process.StartInfo = procStartInfo;
                    process.Start();

                    // Add this: wait until process does its work
                    process.WaitForExit();

                    // and only then read the result
                    string result = process.StandardOutput.ReadToEnd();

                    lbl_sts.Text = "Completed.";
                }
            }
            catch (Exception ex)
            {
                lbl_sts.Text = ex.ToString();
            }

        }

        private void btn_Outputpath_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    tbx_OutPath.Text = fbd.SelectedPath;
                }
            }
        }

        private void Btn_Generate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(tbx_File.Text))
                {

                    if (!string.IsNullOrEmpty(tbx_OutPath.Text))
                    {
                        CommandBuilder.DefaultOutputDirectory = tbx_OutPath.Text;
                    }

                    SelectedOutputDirectory = string.Format("{0}\\{1}", CommandBuilder.DefaultOutputDirectory, InputFileNameWithoutExtns);

                    switch (option)
                    {
                        case "IL2EXE":

                            OutputFileName = string.Format("{0}.exe", SelectedOutputDirectory);

                            Command = string.Format("ilasm {0} /output:{1}", tbx_File.Text, OutputFileName);

                            break;
                        case "EXE2IL":
                            var sourceConfig = Path.GetDirectoryName(tbx_File.Text) + "\\" + InputFileNameWithoutExtns;
                            try
                            {
                                File.Copy(sourceConfig + ".exe.config", SelectedOutputDirectory + ".exe.config");
                            }
                            catch
                            {

                            }

                            OutputFileName = string.Format("{0}.il", SelectedOutputDirectory);
                            Command = string.Format("ildasm {0} /output:{1}", tbx_File.Text, OutputFileName);
                            break;
                    }
                    CommandBuilder.RunCommand(Command, CommandWorkingDirectory);
                    tbx_OutPath.Text = OutputFileName;

                }
                else
                {
                    lbl_sts.Text = "Select file to convert.";
                }
            }
            catch (Exception ex)
            {
                lbl_sts.Text = ex.ToString();
            }

        }

        private void rdb_ILtoEXE_CheckedChanged(object sender, EventArgs e)
        {
            option = "IL2EXE";
            tbx_OutPath.Text = string.Empty;
            tbx_File.Text = string.Empty;

            DialogFilter = "IL files (*.il)|*.il";

            CommandWorkingDirectory = CommandBuilder.ilasmDirectory;
            //OutputFileName = string.Format("{0}.exe",InputFileNameWithoutExtns);

            panel_converter.Enabled = true;
        }

        private void rdb_EXEtoIL_CheckedChanged(object sender, EventArgs e)
        {
            option = "EXE2IL";
            tbx_OutPath.Text = string.Empty;
            tbx_File.Text = string.Empty;

            DialogFilter = "dll files (*.dll)|*.dll|exe files (*.exe)|*.exe";

            CommandWorkingDirectory = CommandBuilder.ildasmDirectory;
            //OutputFileName = string.Format("{0}.il", InputFileNameWithoutExtns);

            panel_converter.Enabled = true;
        }

        private void btn_injectCode_Click(object sender, EventArgs e)
        {
            //string inputILFile = @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\bin\Debug\ChannelFactorySample.il";

            //string outputILFile = @"C:\Users\rajneesh.kumar\source\repos\SDIL\StringEngine\bin\Debug\ChannelFactorySample.il";

            string HookedContext = @"C:\Users\rajneesh.kumar\source\repos\SDIL\ILMaker\StaticILInstruction.json";

            //Inject.File(inputILFile, hookedContext, outputILFile);

            Inject.File(OutputFileName, HookedContext, OutputFileName);

            lbl_sts.Text = "C:\\ILhooked.txt";
        }
    }
}
