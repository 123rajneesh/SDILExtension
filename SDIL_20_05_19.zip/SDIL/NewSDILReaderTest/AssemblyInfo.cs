﻿using Metadata;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NewSDILReaderTest
{
    public partial class AssemblyInfo : Form
    {
        private static AssemblyDTO assemblyDTO = null;

        private static List<TypeDTO> typeDTO = null;

        private static List<MethodDTO> methodDTO = null;

        List<AssemblyName> assemblies = null;
        public AssemblyInfo()
        {
            InitializeComponent();
        }
        public AssemblyInfo(string assemblypath)
        {
            InitializeComponent();

            LoadAssembly(assemblypath);
        }

        private void btnOpenAssembly_Click(object sender, EventArgs e)
        {
            dlgOpenAssembly.ShowDialog();

            try
            {
                if (dlgOpenAssembly.CheckFileExists)
                {
                    string assemblyName = dlgOpenAssembly.FileName;

                    // get the filename of the assembly
                    LoadAssembly(assemblyName);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void LoadAssembly(string path)
        {
            lblAsmPath.Text = path;
            // load the assembly
            var mainASM = Assembly.LoadFrom(path);

            assemblies = new List<AssemblyName>();

            assemblies.Add(mainASM.GetName());

            assemblies.AddRange(mainASM.GetReferencedAssemblies().Where(r => !Config.AssemblyExclude.Contains(r.Name)).ToList());

            BindAssemblyddl(assemblies);

            ProcessAsembly(mainASM);

            FillTreeView();
        }
        private void BindAssemblyddl(List<AssemblyName> assemblies)
        {
            cmbx_ASM.DataSource = assemblies;
            cmbx_ASM.DisplayMember = "Name";
            cmbx_ASM.ValueMember = "FullName";

        }
        private void ReferenceLoadAssembly(string assemblyname)
        {
            // Display the set of assemblies our assemblies reference.
            AssemblyName refAsmbly = assemblies.Single(x => x.FullName == assemblyname);

            Assembly serviceModelASM = Assembly.Load(refAsmbly);

            ProcessAsembly(serviceModelASM);

            FillTreeView();
        }

        private static void ProcessAsembly(Assembly asm)
        {
            assemblyDTO = Info.GetAssemblyInfo(asm);

            typeDTO = Info.GetTypeInfo(asm);

            methodDTO = Info.GetMethodInfo(asm).Where(m => m.IsPrivate == Config.PrivateExclude).ToList();
        }

        private void GetReferencedAssemblyInfo(string assemblyPath)
        {
            var parentAsmbly = Assembly.LoadFrom(assemblyPath);
            var refernceAsmbly = parentAsmbly.GetReferencedAssemblies();
        }

        private void FillTreeView()
        {
            this.treeView_AsmDtl.Nodes.Clear();

            var asmNodetxt = string.Format("Assembly:{0} Defined Type:{1} Exported Type:{2}", assemblyDTO.FullName, assemblyDTO.DefinedTypeDTO.Count, assemblyDTO.ExportedTypeDTO.Count);

            TreeNode assembly_node = new TreeNode();

            assembly_node.Name = assemblyDTO.FullName;

            assembly_node.Text = asmNodetxt;

            assembly_node.BackColor = Color.Magenta;

            var tdto = typeDTO.Where(x => IsAssemblyAreEqual(x.AssemblyDTO, assemblyDTO)).ToList();

            foreach (var t in tdto)
            {
                TreeNode type_node = new TreeNode();

                type_node.Name = t.FullName;

                type_node.Text = t.Name;

                type_node.BackColor = Color.LightGray;

                assembly_node.Nodes.Add(type_node);

                var mdto = methodDTO.Where(x => IsTypeAreEqual(x.TypeDTO, t)).ToList();

                foreach (var m in mdto)
                {
                    TreeNode method_node = new TreeNode();

                    method_node.Name = m.FullName;

                    method_node.Text = m.FullName;

                    method_node.BackColor = Color.LightCyan;

                    type_node.Nodes.Add(method_node);
                }
            }

            this.treeView_AsmDtl.Nodes.Add(assembly_node);
        }
       
        public static bool IsTypeAreEqual(TypeDTO source, TypeDTO target)
        {
            bool flag = false;

            if (source.Namespace == target.Namespace
                && IsAssemblyAreEqual(source.AssemblyDTO, target.AssemblyDTO)
                && source.Count == target.Count
                && source.Name == target.Name
                && source.FullName == target.FullName
                && source.Type == target.Type)
            {
                flag = true;
            }

            return flag;
        }

        public static bool IsAssemblyAreEqual(AssemblyDTO source, AssemblyDTO target)
        {
            bool flag = false;

            if (target.CodeBase == source.CodeBase
               && target.Count == source.Count
               && target.FullName == source.FullName
               && target.Name == source.Name
               && target.DefinedTypeDTO.Count == source.DefinedTypeDTO.Count
               && target.ExportedTypeDTO.Count == source.ExportedTypeDTO.Count
               && target.DefinedTypeDTO.FullName.SequenceEqual(source.DefinedTypeDTO.FullName)
               && target.ExportedTypeDTO.FullName.SequenceEqual(source.ExportedTypeDTO.FullName))
            {
                flag = true;
            }

            return flag;

        }

        private void cmbx_ASM_SelectedIndexChanged(object sender, EventArgs e)
        {
            var asmbName = cmbx_ASM.SelectedValue.ToString();

            ReferenceLoadAssembly(asmbName);
        }
    }
}
