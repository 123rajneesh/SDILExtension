﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace StringEngine
{
    public class Inject
    {
        public static void File(string inputILFile, string hookContext, string outputILFile)
        {
            Dictionary<Guid, string> dic_noneSpecialClass = new Dictionary<Guid, string>();

            Dictionary<Guid, string> dic_SpecialClass = new Dictionary<Guid, string>();

            Dictionary<Guid, string> newdic_noneSpecialClass = new Dictionary<Guid, string>();

            var ILfile = StringOperation.ReadILFile(inputILFile, hookContext);

           // var filewithoutComment = StringOperation.RemoveCommentedLines(ILfile);

            var filewithoutComment = ILfile;

            var file = Regex.Replace(filewithoutComment, @"^\s*$\n", string.Empty, RegexOptions.Multiline).TrimStart();


            var allClass = file.Split(new[] { ".class" }, StringSplitOptions.RemoveEmptyEntries)
                .Where(c => !c.Contains(".assembly"))
                .Select(c =>
                new
                {
                    placeholder = Guid.NewGuid(),
                    text = string.Format(".class{0}", c)
                }).ToDictionary(d => d.placeholder, d => d.text);

            //StringOperation.GetServiceContractInfo(allClass);

            foreach (var ac in allClass)
            {
                var OldString = ac.Value;

                var guidPlaceholder = string.Format("\r\n{0}\r\n", ac.Key.ToString());

                var temp = file.Replace(OldString, guidPlaceholder);

                file = temp;
            }
            foreach (var ac in allClass)
            {
                var firstBracIndex = ac.Value.IndexOf('{');
                var classSignature = ac.Value.Substring(0, firstBracIndex);
                if (classSignature != null)
                {
                    if (!classSignature.Contains(".class interface"))
                    {
                        dic_noneSpecialClass.Add(ac.Key, ac.Value);
                    }
                    else
                    {
                        dic_SpecialClass.Add(ac.Key, ac.Value);
                    }
                }
            }
            foreach (var nsc in dic_noneSpecialClass)
            {
                var temp = StringOperation.ReadILClass(nsc.Value);

                newdic_noneSpecialClass.Add(nsc.Key, temp);

            }
            foreach (var nnsc in newdic_noneSpecialClass)
            {
                var newString = nnsc.Value;

                var guidPlaceholder = string.Format("\r\n{0}\r\n", nnsc.Key.ToString());

                var temp = file.Replace(guidPlaceholder, newString);

                file = temp;
            }
            foreach (var ac in dic_SpecialClass)
            {
                var newString = ac.Value;

                var guidPlaceholder = string.Format("\r\n{0}\r\n", ac.Key.ToString());

                var temp = file.Replace(guidPlaceholder, newString);

                file = temp;
            }

            System.IO.File.WriteAllLines(outputILFile, new[] { file });
        }
    }
}
