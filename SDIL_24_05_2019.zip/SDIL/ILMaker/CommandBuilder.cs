﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ILMaker
{
    public class CommandBuilder
    {
        public static string DefaultOutputDirectory { get { return Environment.CurrentDirectory; } set { } }

        public static string OutputILFileName { get { return ConfigurationManager.AppSettings["OutputILFileName"]; } }

        public static string ildasmDirectory { get { return ConfigurationManager.AppSettings["IldasmDirectory"]; } }

        public static string ilasmDirectory { get { return ConfigurationManager.AppSettings["IlasmDirectory"]; } }

        public static string InjecTCodeJson { get { return ConfigurationManager.AppSettings["InjectJson"]; } }

        public static void RunCommand(string command, string CommandWorkingDirectory)
        {
            try
            {

                ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
                //procStartInfo.WorkingDirectory = @"C:\Program Files (x86)\Microsoft SDKs\Windows\v10.0A\bin\\NETFX 4.6.1 Tools";
                //ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
                procStartInfo.WorkingDirectory = CommandWorkingDirectory;
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                procStartInfo.CreateNoWindow = true;

                // wrap IDisposable into using (in order to release hProcess) 
                using (Process process = new Process())
                {
                    process.StartInfo = procStartInfo;
                    process.Start();

                    // Add this: wait until process does its work
                    process.WaitForExit();

                    // and only then read the result
                    string result = process.StandardOutput.ReadToEnd();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
