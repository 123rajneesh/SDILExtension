﻿using Mono.Cecil;
using Mono.Cecil.Cil;
using System;
using System.Collections;
using System.IO;
using System.Resources;

class Program
{
    static void Main(string[] args)
    {
        string resxFile = @"C:\Users\rajneesh.kumar\source\repos\SDIL\Mono.CecilExample\ILInstructionResource.resx";
        using (ResXResourceReader resxReader = new ResXResourceReader(resxFile))
        {
            foreach (DictionaryEntry entry in resxReader)
            {
                if (((string)entry.Key).StartsWith("static_local_variables"))
                {
                    var dto = entry.Value;
                }
            }
        }
        //SimpleStringInjectOnTop(args);
        GenereateLogFileByILProcessor(args);
    }
    private static void GenereateLogFileByILProcessor(string[] args)
    {

        string ouputAssembly = @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\bin\Debug\ChannelFactorySample1.exe";
        if (args.Length == 0)
            return;
        string assemblyPath = args[0];
        var assembly = AssemblyDefinition.ReadAssembly(assemblyPath);
        //   Console.WriteLine,    
        var writeLineMethod = typeof(File).GetMethod("AppendAllText", new Type[] { typeof(string), typeof(string) });

        //    ,  Reflection,    
        var writeLineRef = assembly.MainModule.Import(writeLineMethod);
        //Gets all types of the MainModule of the assembly
        foreach (TypeDefinition type in assembly.MainModule.Types)
        {
            //Gets all methods of the current type
            foreach (MethodDefinition method in type.Methods)
            {
                //Don't run for Interfaces
                //Don't run for counstructor methods
                //Dont't run for abstract methods

                if (type.Name != "<Module>" && !type.IsInterface && !method.IsConstructor)
                {
                    var cout = method.Body.Instructions.Count;
                    //Gets the CilWorker of the method for working with CIL instructions
                    ILProcessor worker = method.Body.GetILProcessor();

                    //Creates the MSIL instruction for inserting the sentence
                    Instruction insertlogpath;
                    insertlogpath = worker.Create(OpCodes.Ldstr, @"C:\Users\rajneesh.kumar\source\repos\SDIL\Mono.CecilExample\bin\Debug\log.txt");

                    Instruction methodname;
                    methodname = worker.Create(OpCodes.Ldstr, $"code injected in {method.Name} by ILProcessor.\r\n");

                    Instruction callFileAppendmethod;
                    callFileAppendmethod = worker.Create(OpCodes.Call, writeLineRef);

                    //Getting the first instruction of the current method
                    Instruction ins = method.Body.Instructions[cout - 1];

                    //Inserts the insertlogpath instruction before the first //instruction

                    
                    worker.InsertBefore(ins, insertlogpath);

                    worker.InsertAfter(insertlogpath, methodname);

                    worker.InsertAfter(methodname, callFileAppendmethod);

                }
            }
        }
        assembly.Write(ouputAssembly);
    }

    private static void LogFileOnTop(string[] args)
    {
        string ouputAssembly = @"C:\Users\rajneesh.kumar\source\repos\SDIL\Mono.CecilExample\bin\Debug\TestApp.exe";
        if (args.Length == 0)
            return;
        string assemblyPath = args[0];
        var assembly = AssemblyDefinition.ReadAssembly(assemblyPath);
        //   Console.WriteLine,    
        var writeLineMethod = typeof(File).GetMethod("AppendAllText", new Type[] { typeof(string), typeof(string) });

        //    ,  Reflection,    
        var writeLineRef = assembly.MainModule.Import(writeLineMethod);

        foreach (var typeDef in assembly.MainModule.Types)
        {
            foreach (var method in typeDef.Methods)
            {
                try
                {
                    var len = method.Body.Instructions.Count;
                    //skip for interface methods
                    if (!method.DeclaringType.IsInterface)
                    {
                        method.Body.Instructions.Insert(0, Instruction.Create(OpCodes.Ldstr, @"C:\Users\rajneesh.kumar\source\repos\SDIL\Mono.CecilExample\bin\Debug\log.txt"));
                        method.Body.Instructions.Insert(1, Instruction.Create(OpCodes.Ldstr, $"code injected in {method.Name} \r\n"));
                        //Console.WriteLine, -"Injected".
                        method.Body.Instructions.Insert(2, Instruction.Create(OpCodes.Call, writeLineRef));

                    }


                }
                catch (Exception ex)
                {
                    ex.ToString();
                }

            }
        }
        assembly.Write(ouputAssembly);
    }
    private static void SimpleStringInjectOnTop(string[] args)
    {
        string ouputAssembly = @"C:\Users\rajneesh.kumar\source\repos\SDIL\Mono.CecilExample\bin\Debug\TestApp.exe";
        if (args.Length == 0)
            return;
        string assemblyPath = args[0];
        var assembly = AssemblyDefinition.ReadAssembly(assemblyPath);
        //   Console.WriteLine,    
        var writeLineMethod = typeof(Console).GetMethod("WriteLine", new Type[] { typeof(string) });

        //    ,  Reflection,    
        var writeLineRef = assembly.MainModule.Import(writeLineMethod);

        foreach (var typeDef in assembly.MainModule.Types)
        {
            foreach (var method in typeDef.Methods)
            {
                try
                {
                    //skip for interface methods
                    if (!method.DeclaringType.IsInterface)
                    {
                        method.Body.Instructions.Insert(0, Instruction.Create(OpCodes.Ldstr, "Inject!"));
                        //   Console.WriteLine, -"Injected".
                        method.Body.Instructions.Insert(1, Instruction.Create(OpCodes.Call, writeLineRef));
                    }

                }
                catch (Exception ex)
                {
                    ex.ToString();
                }

            }
        }
        assembly.Write(ouputAssembly);
    }
}