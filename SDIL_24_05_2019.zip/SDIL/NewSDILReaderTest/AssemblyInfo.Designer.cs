﻿namespace NewSDILReaderTest
{
    partial class AssemblyInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOpenAssembly = new System.Windows.Forms.Button();
            this.dlgOpenAssembly = new System.Windows.Forms.OpenFileDialog();
            this.lblAsmPath = new System.Windows.Forms.Label();
            this.treeView_AsmDtl = new System.Windows.Forms.TreeView();
            this.cmbx_ASM = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnOpenAssembly
            // 
            this.btnOpenAssembly.Location = new System.Drawing.Point(482, 5);
            this.btnOpenAssembly.Name = "btnOpenAssembly";
            this.btnOpenAssembly.Size = new System.Drawing.Size(106, 30);
            this.btnOpenAssembly.TabIndex = 6;
            this.btnOpenAssembly.Text = "Open Assembly ...";
            this.btnOpenAssembly.UseVisualStyleBackColor = true;
            this.btnOpenAssembly.Click += new System.EventHandler(this.btnOpenAssembly_Click);
            // 
            // dlgOpenAssembly
            // 
            this.dlgOpenAssembly.FileName = "*.*";
            // 
            // lblAsmPath
            // 
            this.lblAsmPath.AutoSize = true;
            this.lblAsmPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAsmPath.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblAsmPath.Location = new System.Drawing.Point(12, 543);
            this.lblAsmPath.Name = "lblAsmPath";
            this.lblAsmPath.Size = new System.Drawing.Size(0, 15);
            this.lblAsmPath.TabIndex = 7;
            // 
            // treeView_AsmDtl
            // 
            this.treeView_AsmDtl.Location = new System.Drawing.Point(12, 41);
            this.treeView_AsmDtl.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.treeView_AsmDtl.Name = "treeView_AsmDtl";
            this.treeView_AsmDtl.Size = new System.Drawing.Size(576, 494);
            this.treeView_AsmDtl.TabIndex = 8;
            // 
            // cmbx_ASM
            // 
            this.cmbx_ASM.FormattingEnabled = true;
            this.cmbx_ASM.Location = new System.Drawing.Point(634, 11);
            this.cmbx_ASM.Name = "cmbx_ASM";
            this.cmbx_ASM.Size = new System.Drawing.Size(286, 21);
            this.cmbx_ASM.TabIndex = 9;
            this.cmbx_ASM.SelectedIndexChanged += new System.EventHandler(this.cmbx_ASM_SelectedIndexChanged);
            // 
            // AssemblyInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1367, 567);
            this.Controls.Add(this.cmbx_ASM);
            this.Controls.Add(this.treeView_AsmDtl);
            this.Controls.Add(this.lblAsmPath);
            this.Controls.Add(this.btnOpenAssembly);
            this.Name = "AssemblyInfo";
            this.Text = "Assembly Information";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOpenAssembly;
        private System.Windows.Forms.OpenFileDialog dlgOpenAssembly;
        private System.Windows.Forms.Label lblAsmPath;
        private System.Windows.Forms.TreeView treeView_AsmDtl;
        private System.Windows.Forms.ComboBox cmbx_ASM;
    }
}