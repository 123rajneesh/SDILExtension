﻿namespace NewSDILReaderTest
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOpenAssembly = new System.Windows.Forms.Button();
            this.dlgOpenAssembly = new System.Windows.Forms.OpenFileDialog();
            this.lblAvailableMethods = new System.Windows.Forms.Label();
            this.lblCode = new System.Windows.Forms.Label();
            this.rchMethodBodyCode = new System.Windows.Forms.RichTextBox();
            this.lbAvailableMethodsList = new System.Windows.Forms.ListBox();
            this.gb_radio_btn = new System.Windows.Forms.GroupBox();
            this.rdb_shw_mth_typ = new System.Windows.Forms.RadioButton();
            this.rdb_shw_mth = new System.Windows.Forms.RadioButton();
            this.lbl_slctdMthd = new System.Windows.Forms.Label();
            this.lbClrInfo = new System.Windows.Forms.ListBox();
            this.gb_filter = new System.Windows.Forms.GroupBox();
            this.rdb_str = new System.Windows.Forms.RadioButton();
            this.rdb_mthd = new System.Windows.Forms.RadioButton();
            this.rdb_fld = new System.Windows.Forms.RadioButton();
            this.lbAvailableFieldList = new System.Windows.Forms.ListBox();
            this.lb_availableflds = new System.Windows.Forms.Label();
            this.btn_AsmDtl = new System.Windows.Forms.Button();
            this.dtgw_method = new System.Windows.Forms.DataGridView();
            this.btn_gntr = new System.Windows.Forms.Button();
            this.gb_radio_btn.SuspendLayout();
            this.gb_filter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgw_method)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOpenAssembly
            // 
            this.btnOpenAssembly.Location = new System.Drawing.Point(481, 12);
            this.btnOpenAssembly.Name = "btnOpenAssembly";
            this.btnOpenAssembly.Size = new System.Drawing.Size(106, 23);
            this.btnOpenAssembly.TabIndex = 5;
            this.btnOpenAssembly.Text = "Open Assembly ...";
            this.btnOpenAssembly.UseVisualStyleBackColor = true;
            this.btnOpenAssembly.Click += new System.EventHandler(this.btnOpenAssembly_Click);
            // 
            // dlgOpenAssembly
            // 
            this.dlgOpenAssembly.FileName = "*.*";
            // 
            // lblAvailableMethods
            // 
            this.lblAvailableMethods.AutoSize = true;
            this.lblAvailableMethods.Location = new System.Drawing.Point(14, 82);
            this.lblAvailableMethods.Name = "lblAvailableMethods";
            this.lblAvailableMethods.Size = new System.Drawing.Size(93, 13);
            this.lblAvailableMethods.TabIndex = 9;
            this.lblAvailableMethods.Text = "Available methods";
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Location = new System.Drawing.Point(14, 416);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(94, 13);
            this.lblCode.TabIndex = 8;
            this.lblCode.Text = "MethodBody code";
            // 
            // rchMethodBodyCode
            // 
            this.rchMethodBodyCode.Location = new System.Drawing.Point(14, 432);
            this.rchMethodBodyCode.Name = "rchMethodBodyCode";
            this.rchMethodBodyCode.Size = new System.Drawing.Size(600, 260);
            this.rchMethodBodyCode.TabIndex = 7;
            this.rchMethodBodyCode.Text = "";
            this.rchMethodBodyCode.WordWrap = false;
            // 
            // lbAvailableMethodsList
            // 
            this.lbAvailableMethodsList.FormattingEnabled = true;
            this.lbAvailableMethodsList.Location = new System.Drawing.Point(14, 98);
            this.lbAvailableMethodsList.Name = "lbAvailableMethodsList";
            this.lbAvailableMethodsList.Size = new System.Drawing.Size(443, 199);
            this.lbAvailableMethodsList.TabIndex = 6;
            this.lbAvailableMethodsList.SelectedIndexChanged += new System.EventHandler(this.lbAvailableMethodsList_SelectedIndexChanged);
            // 
            // gb_radio_btn
            // 
            this.gb_radio_btn.Controls.Add(this.rdb_shw_mth_typ);
            this.gb_radio_btn.Controls.Add(this.rdb_shw_mth);
            this.gb_radio_btn.Location = new System.Drawing.Point(17, 12);
            this.gb_radio_btn.Name = "gb_radio_btn";
            this.gb_radio_btn.Size = new System.Drawing.Size(458, 68);
            this.gb_radio_btn.TabIndex = 10;
            this.gb_radio_btn.TabStop = false;
            this.gb_radio_btn.Text = "groupBox_radio";
            // 
            // rdb_shw_mth_typ
            // 
            this.rdb_shw_mth_typ.AutoSize = true;
            this.rdb_shw_mth_typ.Location = new System.Drawing.Point(222, 14);
            this.rdb_shw_mth_typ.Name = "rdb_shw_mth_typ";
            this.rdb_shw_mth_typ.Size = new System.Drawing.Size(140, 17);
            this.rdb_shw_mth_typ.TabIndex = 1;
            this.rdb_shw_mth_typ.TabStop = true;
            this.rdb_shw_mth_typ.Text = "Show Method And Type";
            this.rdb_shw_mth_typ.UseVisualStyleBackColor = true;
            this.rdb_shw_mth_typ.CheckedChanged += new System.EventHandler(this.rdb_shw_mth_typ_CheckedChanged);
            // 
            // rdb_shw_mth
            // 
            this.rdb_shw_mth.AutoSize = true;
            this.rdb_shw_mth.Location = new System.Drawing.Point(31, 17);
            this.rdb_shw_mth.Name = "rdb_shw_mth";
            this.rdb_shw_mth.Size = new System.Drawing.Size(115, 17);
            this.rdb_shw_mth.TabIndex = 0;
            this.rdb_shw_mth.TabStop = true;
            this.rdb_shw_mth.Text = "Show Method Only";
            this.rdb_shw_mth.UseVisualStyleBackColor = true;
            this.rdb_shw_mth.CheckedChanged += new System.EventHandler(this.rdb_shw_mth_CheckedChanged);
            // 
            // lbl_slctdMthd
            // 
            this.lbl_slctdMthd.AutoSize = true;
            this.lbl_slctdMthd.Location = new System.Drawing.Point(14, 367);
            this.lbl_slctdMthd.Name = "lbl_slctdMthd";
            this.lbl_slctdMthd.Size = new System.Drawing.Size(87, 13);
            this.lbl_slctdMthd.TabIndex = 11;
            this.lbl_slctdMthd.Text = "Selected method";
            // 
            // lbClrInfo
            // 
            this.lbClrInfo.FormattingEnabled = true;
            this.lbClrInfo.HorizontalScrollbar = true;
            this.lbClrInfo.Location = new System.Drawing.Point(633, 432);
            this.lbClrInfo.Name = "lbClrInfo";
            this.lbClrInfo.Size = new System.Drawing.Size(792, 238);
            this.lbClrInfo.TabIndex = 12;
            // 
            // gb_filter
            // 
            this.gb_filter.Controls.Add(this.rdb_str);
            this.gb_filter.Controls.Add(this.rdb_mthd);
            this.gb_filter.Controls.Add(this.rdb_fld);
            this.gb_filter.Location = new System.Drawing.Point(766, 82);
            this.gb_filter.Name = "gb_filter";
            this.gb_filter.Size = new System.Drawing.Size(556, 43);
            this.gb_filter.TabIndex = 14;
            this.gb_filter.TabStop = false;
            // 
            // rdb_str
            // 
            this.rdb_str.AutoSize = true;
            this.rdb_str.Location = new System.Drawing.Point(299, 17);
            this.rdb_str.Name = "rdb_str";
            this.rdb_str.Size = new System.Drawing.Size(85, 17);
            this.rdb_str.TabIndex = 2;
            this.rdb_str.TabStop = true;
            this.rdb_str.Text = "Show strings";
            this.rdb_str.UseVisualStyleBackColor = true;
            this.rdb_str.CheckedChanged += new System.EventHandler(this.rdb_str_CheckedChanged);
            // 
            // rdb_mthd
            // 
            this.rdb_mthd.AutoSize = true;
            this.rdb_mthd.Location = new System.Drawing.Point(170, 17);
            this.rdb_mthd.Name = "rdb_mthd";
            this.rdb_mthd.Size = new System.Drawing.Size(91, 17);
            this.rdb_mthd.TabIndex = 1;
            this.rdb_mthd.TabStop = true;
            this.rdb_mthd.Text = "Show Method";
            this.rdb_mthd.UseVisualStyleBackColor = true;
            this.rdb_mthd.CheckedChanged += new System.EventHandler(this.rdb_mthd_CheckedChanged);
            // 
            // rdb_fld
            // 
            this.rdb_fld.AutoSize = true;
            this.rdb_fld.Location = new System.Drawing.Point(31, 17);
            this.rdb_fld.Name = "rdb_fld";
            this.rdb_fld.Size = new System.Drawing.Size(82, 17);
            this.rdb_fld.TabIndex = 0;
            this.rdb_fld.TabStop = true;
            this.rdb_fld.Text = "Show Fileds";
            this.rdb_fld.UseVisualStyleBackColor = true;
            this.rdb_fld.CheckedChanged += new System.EventHandler(this.rdb_fld_CheckedChanged);
            // 
            // lbAvailableFieldList
            // 
            this.lbAvailableFieldList.FormattingEnabled = true;
            this.lbAvailableFieldList.Location = new System.Drawing.Point(484, 98);
            this.lbAvailableFieldList.Name = "lbAvailableFieldList";
            this.lbAvailableFieldList.Size = new System.Drawing.Size(262, 199);
            this.lbAvailableFieldList.TabIndex = 15;
            this.lbAvailableFieldList.SelectedIndexChanged += new System.EventHandler(this.lbAvailableFieldList_SelectedIndexChanged);
            // 
            // lb_availableflds
            // 
            this.lb_availableflds.AutoSize = true;
            this.lb_availableflds.Location = new System.Drawing.Point(481, 82);
            this.lb_availableflds.Name = "lb_availableflds";
            this.lb_availableflds.Size = new System.Drawing.Size(80, 13);
            this.lb_availableflds.TabIndex = 16;
            this.lb_availableflds.Text = "Available Fields";
            // 
            // btn_AsmDtl
            // 
            this.btn_AsmDtl.Location = new System.Drawing.Point(723, 5);
            this.btn_AsmDtl.Name = "btn_AsmDtl";
            this.btn_AsmDtl.Size = new System.Drawing.Size(231, 36);
            this.btn_AsmDtl.TabIndex = 17;
            this.btn_AsmDtl.Text = "Show Assembly Detail";
            this.btn_AsmDtl.UseVisualStyleBackColor = true;
            this.btn_AsmDtl.Visible = false;
            this.btn_AsmDtl.Click += new System.EventHandler(this.btn_AsmDtl_Click);
            // 
            // dtgw_method
            // 
            this.dtgw_method.Location = new System.Drawing.Point(766, 131);
            this.dtgw_method.Name = "dtgw_method";
            this.dtgw_method.Size = new System.Drawing.Size(659, 261);
            this.dtgw_method.TabIndex = 18;
            // 
            // btn_gntr
            // 
            this.btn_gntr.Location = new System.Drawing.Point(1013, 10);
            this.btn_gntr.Name = "btn_gntr";
            this.btn_gntr.Size = new System.Drawing.Size(231, 36);
            this.btn_gntr.TabIndex = 19;
            this.btn_gntr.Text = "Generate Code";
            this.btn_gntr.UseVisualStyleBackColor = true;
            this.btn_gntr.Click += new System.EventHandler(this.btn_gntr_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1450, 704);
            this.Controls.Add(this.btn_gntr);
            this.Controls.Add(this.dtgw_method);
            this.Controls.Add(this.btn_AsmDtl);
            this.Controls.Add(this.lb_availableflds);
            this.Controls.Add(this.lbAvailableFieldList);
            this.Controls.Add(this.gb_filter);
            this.Controls.Add(this.lbClrInfo);
            this.Controls.Add(this.lbl_slctdMthd);
            this.Controls.Add(this.gb_radio_btn);
            this.Controls.Add(this.btnOpenAssembly);
            this.Controls.Add(this.lblAvailableMethods);
            this.Controls.Add(this.lblCode);
            this.Controls.Add(this.rchMethodBodyCode);
            this.Controls.Add(this.lbAvailableMethodsList);
            this.Name = "Main";
            this.Text = "Main";
            this.gb_radio_btn.ResumeLayout(false);
            this.gb_radio_btn.PerformLayout();
            this.gb_filter.ResumeLayout(false);
            this.gb_filter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgw_method)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOpenAssembly;
        private System.Windows.Forms.OpenFileDialog dlgOpenAssembly;
        private System.Windows.Forms.Label lblAvailableMethods;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.RichTextBox rchMethodBodyCode;
        private System.Windows.Forms.ListBox lbAvailableMethodsList;
        private System.Windows.Forms.GroupBox gb_radio_btn;
        private System.Windows.Forms.RadioButton rdb_shw_mth_typ;
        private System.Windows.Forms.RadioButton rdb_shw_mth;
        private System.Windows.Forms.Label lbl_slctdMthd;
        private System.Windows.Forms.ListBox lbClrInfo;
        private System.Windows.Forms.GroupBox gb_filter;
        private System.Windows.Forms.RadioButton rdb_mthd;
        private System.Windows.Forms.RadioButton rdb_fld;
        private System.Windows.Forms.RadioButton rdb_str;
        private System.Windows.Forms.ListBox lbAvailableFieldList;
        private System.Windows.Forms.Label lb_availableflds;
        private System.Windows.Forms.Button btn_AsmDtl;
        private System.Windows.Forms.DataGridView dtgw_method;
        private System.Windows.Forms.Button btn_gntr;
    }
}