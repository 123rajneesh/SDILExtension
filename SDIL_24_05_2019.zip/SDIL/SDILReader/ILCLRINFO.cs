﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDILReader
{
    public class ILCLRINFO
    {
        public ILCLRINFO()
        {
            this.Field = new InlineField();
            this.Method = new InlineMethod();
            this.String = new InlineString();
        }
        public InlineField Field { get; set; }
        public InlineMethod Method { get; set; }
        public InlineString String { get; set; }
    }
    public class InlineField
    {
        public string Name { get; set; }
        public string FieldType { get; set; }
        public string ReflectedType { get; set; }
    }
    public class InlineMethod
    {
        public string Name { get; set; }
        public string ReturnType { get; set; }
        public string ReflectedType { get; set; }
        public string Signature { get; set; }
    }
    public class InlineString
    {
        public string Value { get; set; }
    }

}
