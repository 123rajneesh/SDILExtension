﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticILCodeInjection
{
    interface IAssemblyILMember
    {
        void GetFieldsMember();
        void GetLocalMember();
        void GetILMemberInfo();
    }
}
