﻿using Mono.Cecil;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticILCodeInjection
{
    public class ILInjection
    {
        public void LoadAssemblies(string[] assemblyPath)
        {
            if (assemblyPath.Length > 0)
            {
                foreach (var path in assemblyPath)
                {
                    var assembly = AssemblyDefinition.ReadAssembly(path);
                    //File.AppendAllLines("path","contents");
                    //   Console.WriteLine,    
                    var fileAppendAllTextMethod = typeof(File).GetMethod("AppendAllText", new Type[] { typeof(string), typeof(string) });
                    var writeLineRef = assembly.MainModule.Import(fileAppendAllTextMethod);
                }
            }
        }
    }
}
