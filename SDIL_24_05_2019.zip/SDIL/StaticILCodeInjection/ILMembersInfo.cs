﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticILCodeInjection
{
    public class AssemblyInfo
    {
        public AssemblyInfo()
        {
            ILMembersInfo = new ILMembersInfo();
        }
        public string Path { get; set; }
        public string Configuration { get; set; }
        public string AssemblyName { get; set; }
        public string OutputAssembly { get; set; }
        public ILMembersInfo ILMembersInfo { get; set; }
    }
    public class ILMembersInfo
    {
        public ILMembersInfo()
        {
            FieldMembers = new FieldMembers();

            LocalMembers = new List<LocalMembers>();
        }
        public string ClassName { get; set; }

        public FieldMembers FieldMembers { get; set; }

        public List<LocalMembers> LocalMembers { get; set; }
    }
    public class LocalMembers
    {
        public string MethodName { get; set; }

        public int Index { get; set; }

        public string Name { get; set; }

        public string ILString { get; set; }
    }
    public class FieldMembers
    {
        public int Index { get; set; }

        public string Name { get; set; }

        public string ILString { get; set; }
    }
}
