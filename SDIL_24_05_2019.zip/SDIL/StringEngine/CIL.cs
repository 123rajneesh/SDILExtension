﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringEngine
{
    public class CIL
    {
    }
    public class Fields
    {
    }
    public class LocalVariable
    {
        public int Index { get; set; }
        public string type { get; set; }
        public string Name { get; set; }
    }
}
