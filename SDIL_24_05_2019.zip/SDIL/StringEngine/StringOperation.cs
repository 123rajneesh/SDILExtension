﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace StringEngine
{
    public class StringOperation
    {
        public static int ILCodeLineCount = 2;

        public static string ILINSTRUCTION_TEXT = "System.ServiceModel.ChannelFactory";

        public static string ILOPCODE = "newobj";

        public static string[] SKIPILOPCODE = new[] { "stloc" };

        public static string MaxStackSize = "8";

        public static int MaxStackSizePadLeft = 3;

        private static string HookedContext { get; set; }

        public static string ReadILFile(string ILFILE, string hook)
        {
            string ilText = string.Empty;

            HookedContext = hook;

            try
            {   // Open the text file using a stream reader.
                using (StreamReader sr = new StreamReader(ILFILE))
                {
                    // Read the stream to a string, and write the string to the console.
                    ilText = sr.ReadToEnd();
                }
            }
            catch (IOException e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }

            return ilText;
        }

        public static string ReadILClass(string nonespecialclass)
        {
            var ilText = nonespecialclass;

            //find .class in IL
            var classIdx = ilText.IndexOf(".class");

            var classText = ilText.Substring(classIdx);

            var firstIdxOfMethod = classText.IndexOf(".method");

            string[] allmethod = classText.Split(new[] { ".method" }, StringSplitOptions.RemoveEmptyEntries).Where(t => !t.Contains(".class")).Select(m => string.Format(".method{0}", m)).ToArray();


            //filter contructor and none constructor methods by first line

            List<string> list_ConstructorMethods = new List<string>();

            List<string> list_noneConstructorMethods = new List<string>();

            foreach (var method in allmethod)
            {
                var firstBracIndex = method.IndexOf('{');

                var methodSignature = method.Substring(0, firstBracIndex);

                if (methodSignature != null)
                {
                    if (methodSignature.Contains(".ctor()") | methodSignature.Contains(".cctor()"))
                    {
                        list_ConstructorMethods.Add(method);
                    }
                    else
                    {
                        list_noneConstructorMethods.Add(method);
                    }
                }

            }

            var newClassTemplate = classText.Substring(classIdx, firstIdxOfMethod);

            StringBuilder sbnewTemplate = new StringBuilder();

            sbnewTemplate.AppendLine(newClassTemplate);

            foreach (var method in list_noneConstructorMethods)
            {              
                var customMethod = InjectBelowChannelFactoryInstance(method, out string injectedMethodSig);

                sbnewTemplate.AppendLine(customMethod);
            }
            foreach (var method in list_ConstructorMethods)
            {
                sbnewTemplate.AppendLine(method);
            }            
            char[] trim_cahracters = { '*', ' ' };

            var result = sbnewTemplate.ToString().TrimEnd(trim_cahracters);

            var template = ilText.Replace(classText, result);

            return template;
        }
        private static string InjectBelowChannelFactoryInstance(string methodContent, out string injectedMethodSig)
        {
            var methodSignature = GetMethodSignature(methodContent);

            var localflds = GetMethodLocalFiledIndex(methodContent, "System.ServiceModel.ChannelFactory");

            StringReader strReader = new StringReader(methodContent);

            //Get method il in dto
            var il = GetILInstruction(methodContent);

            StringBuilder sb = new StringBuilder();

            List<string> HexCodes = new List<string>();

            List<ILInstruction> ilInstructionlist = new List<ILInstruction>();

            List<ILInstruction> ilReplcaholder = new List<ILInstruction>();

            List<ILInstruction> staticIL = null;

            string methodTemplate = string.Empty;

            injectedMethodSig = methodSignature;

            ILInstruction hookedFromline = null;

            var channelfactoryIndex = il.FindIndex(x => x.Instruction.Contains(ILINSTRUCTION_TEXT) && x.OpCode.Contains(ILOPCODE));



            for (int i = channelfactoryIndex + 1; i < il.Count && i > 0; i++)
            {
                var next = il[i];

                if (SKIPILOPCODE.Any(s => next.OpCode.StartsWith(s)))
                {
                    hookedFromline = next;
                    continue;
                }
                else
                {
                    break;
                }
            }

            string lasthexCode = string.Empty;
            if (channelfactoryIndex > -1)
            {
                while (true)
                {
                    string line = strReader.ReadLine();

                    if (line == null)
                    {
                        break;
                    }

                    //update maxstack for injected code snipt
                    if (line.TrimStart().StartsWith(".maxstack"))
                    {
                        var mstkcSize = line.Split(new[] { ".maxstack" }, StringSplitOptions.RemoveEmptyEntries).Last();

                        line = line.Replace(mstkcSize, MaxStackSize.PadLeft(MaxStackSizePadLeft));

                    }
                    if (line.Contains("IL_"))
                    {
                        if (line.IndexOf(hookedFromline.OpCode) > -1)
                        {
                            using (StreamReader reader = new StreamReader(HookedContext))
                            {
                                string json = reader.ReadToEnd();

                                staticIL = JsonConvert.DeserializeObject<List<ILInstruction>>(json);

                                staticIL.ForEach(x => x.MethodName = methodSignature);
                            }

                            //Added on top ilInstruction object from where code will be inject
                            staticIL.Insert(0, hookedFromline);
                            //reorder IL codes to avoid duplicate
                            ReArrangeILInstruction(staticIL, hookedFromline.OpCode);

                            for (int counter = 0; counter < staticIL.Count(); counter++)
                            {
                                if (staticIL[counter].OpCode.StartsWith("ldloc"))
                                {
                                    //get local field index of channelfactory
                                    var fld = localflds.First(x => il.Any(y => y.ILLocalField.FieldIndex == x.FieldIndex));
                                    if (fld != null)
                                    {
                                        staticIL[counter].OpCode = string.Format("{0}.{1}", staticIL[counter].OpCode, fld.FieldIndex);
                                    }
                                }
                                string statment = string.Format("    {0} {1}        {2}", staticIL[counter].NewILHexCode, staticIL[counter].OpCode, staticIL[counter].Instruction);
                                sb.AppendLine(statment);
                            }
                            lasthexCode = staticIL.Last().NewILHexCode;
                        }
                        else
                        {   //update remaining IL of method
                            if (staticIL != null)
                            {
                                string[] col = line.Split(new[] { "  ", "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                                if (col.Length > 0)
                                {
                                    var IL_OldHexCode = col[0];

                                    //returning hexcode
                                    var hexvalue = GetIncrementedILHexCode(lasthexCode);

                                    //formating hexcode to IL_hexcode
                                    var newIL_HexCode = FormateILHexCode(IL_OldHexCode, hexvalue);
                                    //Replace oldhexcode from new hexcode
                                    line = line.Replace(IL_OldHexCode, newIL_HexCode);

                                    if (col.Length == 3)
                                    {
                                        if (col[2].Trim().StartsWith("IL_"))
                                        {
                                            ilReplcaholder.Add(new ILInstruction() { OldILHexCode = IL_OldHexCode, NewILHexCode = newIL_HexCode, OpCode = col[1], Instruction = col[2] });
                                        }
                                    }
                                    else
                                    {
                                        ilReplcaholder.Add(new ILInstruction() { OldILHexCode = IL_OldHexCode, NewILHexCode = newIL_HexCode, OpCode = col[1] });
                                    }
                                    lasthexCode = newIL_HexCode;

                                }

                            }

                            sb.AppendLine(line);
                        }
                    }
                    else
                    {
                        sb.AppendLine(line);
                    }
                }
                methodTemplate = sb.ToString();
            }
            else
            {
                methodTemplate = methodContent;
            }
            if (ilReplcaholder.Count > 0)
            {
                methodTemplate = UpdateOldILInstructionReferences(methodTemplate, ilReplcaholder);
            }

            return methodTemplate;
        }

        private static string UpdateOldILInstructionReferences(string methodTemplate, List<ILInstruction> ilReplcaholder)
        {
            StringBuilder sb_updatelabelrefernce = new StringBuilder();

            var reader = new StringReader(methodTemplate);

            while (true)
            {

                var line = reader.ReadLine();
                if (line == null) { break; }

                foreach (var il in ilReplcaholder)
                {
                    if (il.Instruction != null)
                    {
                        var refernceILHexCode = il.Instruction + ":";
                        var RefernceIL = ilReplcaholder.Single(x => x.OldILHexCode.Trim() == refernceILHexCode.Trim());

                        //break line into array
                        string[] col = line.Split(new[] { "  ", "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);

                        if (col.Length == 3)
                        {
                            if (col[2].Trim().StartsWith("IL_"))
                            {
                                var referenceLabel = col[2].Trim();
                                if (referenceLabel == RefernceIL.OldILHexCode.Trim(' ', ':'))
                                {
                                    line = line.Replace(il.Instruction, RefernceIL.NewILHexCode.TrimEnd(':'));
                                }

                            }
                        }
                    }

                }
                sb_updatelabelrefernce.AppendLine(line);
            }

            return sb_updatelabelrefernce.ToString(); ;
        }

        private static List<ILInstruction> GetILInstruction(string methodContent)
        {
            List<ILInstruction> il = new List<ILInstruction>();

            StringReader strReader = new StringReader(methodContent);

            while (true)
            {
                string line = strReader.ReadLine();

                if (line == null)
                {
                    break;
                }

                //Extract each line w.r.t ILInstruction DTO to get oldhexcode of method
                if (line.Contains("IL_"))
                {
                    ILInstruction ilinstruction = new ILInstruction();

                    string[] col = line.Split(new[] { "  ", "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);

                    ilinstruction.IsAdded = false;

                    ilinstruction.OldILHexCode = col[0];

                    ilinstruction.OpCode = col[1];

                    if (ilinstruction.OpCode.StartsWith("ldloc"))
                    {
                        var opcode = ilinstruction.OpCode.Split('.');

                        ilinstruction.ILLocalField.FieldIndex = opcode[0];
                        ilinstruction.ILLocalField.FieldIndex = opcode[1];
                    }

                    switch (col.Length)
                    {
                        //If Instruction is not available
                        case 1:
                        case 2:
                            ilinstruction.Instruction = string.Empty;
                            break;
                        case 3:
                            ilinstruction.Instruction = col[2];
                            break;
                    }
                    il.Add(ilinstruction);
                }
            }

            return il;

        }

        private static string UpdateOldILInstructionReferences(List<ILInstruction> staticInstruction, string methodString)
        {
            string template = string.Empty;

            var opcode = staticInstruction.Where(x => x.OpCode.Contains("ldloc")).FirstOrDefault();

            if (opcode != null && !opcode.IsAdded)
            {

                template = methodString.Replace(opcode.OldILHexCode.TrimEnd(':'), opcode.NewILHexCode.TrimEnd(':'));
            }
            else
            {
                template = methodString;
            }

            return template;
        }

        private static void ReArrangeILInstruction(List<ILInstruction> staticInstruction, string hookedfrom)
        {
            GenerateNewILCodeForInstructions(staticInstruction, hookedfrom);
        }

        private static void GenerateNewILCodeForInstructions(List<ILInstruction> ILInstructions, string startFrom = null)
        {
            var lastInstruction = ILInstructions.Single(x => x.OpCode.ToLower() == startFrom.ToLower());

            string tempHexCode = lastInstruction.OldILHexCode;

            foreach (var iLInstruction in ILInstructions)
            {

                iLInstruction.NewILHexCode = tempHexCode;

                string hexValue = GetIncrementedILHexCode(tempHexCode);

                tempHexCode = FormateILHexCode(tempHexCode, hexValue);
            }
        }

        private static string FormateILHexCode(string tempHexCode, string hexValue)
        {
            switch (hexValue.Length)
            {
                case 3:
                    tempHexCode = "IL_0" + hexValue + ":";
                    break;
                case 2:
                    tempHexCode = "IL_00" + hexValue + ":";
                    break;
                case 1:
                    tempHexCode = "IL_000" + hexValue + ":";
                    break;
            }

            return tempHexCode;
        }

        private static string GetIncrementedILHexCode(string tempHexCode)
        {
            var hexcode = ExtractHexCode(tempHexCode);

            int intFromHex = int.Parse(hexcode, System.Globalization.NumberStyles.HexNumber) + 1;

            string hexValue = intFromHex.ToString("X");
            return hexValue;
        }

        private static string ExtractHexCode(string ilhexcode)
        {
            string hexCode = string.Empty;

            var colonIdx = ilhexcode.IndexOf(':');

            if (colonIdx > -1)
            {
                var leftString = ilhexcode.Substring(0, colonIdx).Trim();

                var underScoreIdx = leftString.IndexOf('_') + 1;

                hexCode = leftString.Substring(underScoreIdx);
            }

            return hexCode;
        }

        public static string RemoveCommentedLines(string classText)
        {
            var blockComments = @"/\*(.*?)\*/";
            var lineComments = @"//(.*?)\r?\n";
            var strings = @"""((\\[^\n]|[^""\n])*)""";
            var verbatimStrings = @"@(""[^""]*"")+";


            string noComments = Regex.Replace(classText,
                                                blockComments + "|" + lineComments + "|" + strings + "|" + verbatimStrings,
                                                me =>
                                                {
                                                    if (me.Value.StartsWith("/*") || me.Value.StartsWith("//"))
                                                        return me.Value.StartsWith("//") ? Environment.NewLine : "";
                                                    // Keep the literal strings
                                                    return me.Value;
                                                },
                                                RegexOptions.Singleline);

            return noComments;
        }

        private static string GetMethodSignature(string methodText)
        {
            var firstBracIndex = methodText.IndexOf('{');

            var methodAssemblySig = methodText.Substring(0, firstBracIndex);

            var hidebysig = "hidebysig";

            var sigArray = methodAssemblySig.Split(new[] { hidebysig }, StringSplitOptions.None);

            var lastString = sigArray.LastOrDefault();

            var lastIndexofBrack = lastString.LastIndexOf(')') + 1;

            var signature = lastString.Substring(0, lastIndexofBrack).TrimStart();

            return signature;
        }

        internal static void GetServiceContractInfo(Dictionary<Guid, string> allClass)
        {
            throw new NotImplementedException();
        }

        private static void GetSourceCodeLinesFromIL(string methodText)
        {
            StringBuilder sb_sample = new StringBuilder();

            sb_sample.AppendLine("    .method private hidebysig static void  Main(string[] args) cil managed");
            sb_sample.AppendLine("  {");
            sb_sample.AppendLine("    .entrypoint");
            sb_sample.AppendLine("    // Code size       19 (0x13)");
            sb_sample.AppendLine("    .maxstack  8");
            sb_sample.AppendLine(@"// Source File 'C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\Program.cs'");
            sb_sample.AppendLine("//000033:         {");
            sb_sample.AppendLine("    IL_0000:  nop");
            sb_sample.AppendLine("//000034:             //GenericInitializeFactory();");
            sb_sample.AppendLine("//000035:             InitializeFactory();");
            sb_sample.AppendLine("    IL_0001:  call       int32 ChannelFactorySample.Program::InitializeFactory()");
            sb_sample.AppendLine("    IL_0006:  pop");
            sb_sample.AppendLine("//000036:             Console.WriteLine(\"Executed\");");
            sb_sample.AppendLine("    IL_0007:  ldstr      \"Executed\"");
            sb_sample.AppendLine("    IL_000c:  call       void [mscorlib]System.Console::WriteLine(string)");
            sb_sample.AppendLine("    IL_0011:  nop ");
            sb_sample.AppendLine("//000037:             //Console.ReadLine();");
            sb_sample.AppendLine("//000038:         } ");
            sb_sample.AppendLine("    IL_0012:  ret");
            sb_sample.AppendLine("}");


            StringBuilder sb = new StringBuilder();
            using (StringReader reader = new StringReader(methodText))
            {
                while (true)
                {
                    string line = reader.ReadLine();

                    if (line == null)
                    { break; }

                    if (line.StartsWith("//"))
                        sb.AppendLine(line);

                }
                File.WriteAllLines(Environment.CurrentDirectory + "\\SoucreMethod,txt", new[] { sb.ToString() });
            }
        }
        /// <summary>
        /// Get methods local fields
        /// </summary>
        /// <param name="methodString"></param>
        /// <returns></returns>
        public static List<ILLocalField> GetMethodLocalFileds(string methodString)
        {
            List<ILLocalField> ilLocalField = new List<ILLocalField>();

            var str = methodString;

            var lcfldIdx = str.IndexOf(".locals");

            var lastParenthisIdx = str.LastIndexOf(")");

            var localFldStr = str.Substring(lcfldIdx + 1, lastParenthisIdx - lcfldIdx);

            if (lcfldIdx > -1)
            {
                var openingParanthisBracktIdx = localFldStr.IndexOf("(") + 1;
                var closingParanthisBracktIdx = localFldStr.IndexOf(")");

                var arrayStr = localFldStr.Substring(openingParanthisBracktIdx, closingParanthisBracktIdx - openingParanthisBracktIdx);
                var splitstr = arrayStr.Split(',');


                var isChannelFactoryExists = Array.Exists(splitstr, elm => elm.Contains("System.ServiceModel.ChannelFactory"));

                if (isChannelFactoryExists)
                {
                    var bracsplit = localFldStr.Split('(', ')')[1];
                    var commasplitstr = bracsplit.Split(',');

                    foreach (var line in commasplitstr)
                    {
                        ILLocalField ilLocalFieldObj = new ILLocalField();

                        var openingBracketIdx = line.IndexOf('[') + 1;
                        var closingBracketIdx = line.IndexOf(']');

                        ilLocalFieldObj.FieldIndex = line.Substring(openingBracketIdx, closingBracketIdx - openingBracketIdx);
                        ilLocalFieldObj.LocalField = line.Substring(closingBracketIdx + 1);
                        ilLocalField.Add(ilLocalFieldObj);
                    }
                }

            }

            return ilLocalField;

        }

        public static List<ILLocalField> GetMethodLocalFiledIndex(string methodString, string localfield)
        {
            List<ILLocalField> ilLocalField = new List<ILLocalField>();

            var str = methodString;

            var lcfldIdx = str.IndexOf(".locals");

            var lastParenthisIdx = str.LastIndexOf(")");

            var localFldStr = str.Substring(lcfldIdx + 1, lastParenthisIdx - lcfldIdx);

            if (lcfldIdx > -1)
            {
                var openingParanthisBracktIdx = localFldStr.IndexOf("(") + 1;
                var closingParanthisBracktIdx = localFldStr.IndexOf(")");

                var arrayStr = localFldStr.Substring(openingParanthisBracktIdx, closingParanthisBracktIdx - openingParanthisBracktIdx);
                var splitstr = arrayStr.Split(',');

                var collection = Array.FindAll(splitstr, elm => elm.Contains(localfield));

                if (collection.Length > 0)
                {
                    foreach (var line in collection)
                    {
                        ILLocalField ilLocalFieldObj = new ILLocalField();

                        var openingBracketIdx = line.IndexOf('[') + 1;
                        var closingBracketIdx = line.IndexOf(']');

                        ilLocalFieldObj.FieldIndex = line.Substring(openingBracketIdx, closingBracketIdx - openingBracketIdx);
                        ilLocalFieldObj.LocalField = line.Substring(closingBracketIdx + 1);
                        ilLocalField.Add(ilLocalFieldObj);
                    }
                }

            }

            return ilLocalField;

        }
    }
}