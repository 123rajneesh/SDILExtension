﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp
{
    class Program
    {
        public static void Main(string[] args)
        {
            WriteLine("");
            Add();
            Multiply();
            Console.WriteLine("Main Called.");
            Console.Read();
        }

        /*
          .method public hidebysig static int32  Add() cil managed
            {
              // Code size       26 (0x1a)
              .maxstack  2
              .locals init ([0] int32 a,
                       [1] int32 b,
                       [2] int32 result,
                       [3] int32 V_3)
              IL_0000:  nop
              IL_0001:  ldc.i4.2
              IL_0002:  stloc.0
              IL_0003:  ldc.i4.3
              IL_0004:  stloc.1
              IL_0005:  ldloc.0
              IL_0006:  ldloc.1
              IL_0007:  add
              IL_0008:  stloc.2
              IL_0009:  ldstr      "Add Called."
              IL_000e:  call       void [mscorlib]System.Console::WriteLine(string)
              IL_0013:  nop
              IL_0014:  ldloc.2
              IL_0015:  stloc.3
              IL_0016:  br.s       IL_0018

              IL_0018:  ldloc.3
              IL_0019:  ret
            } // end of method Program::Add
        */

        public static int Add()
        {
            int a = 2;
            int b = 3;
            int result = a + b;
            Console.WriteLine("Add Called.");
            return result;
        }
        public static void Multiply()
        {
            Console.WriteLine("Multiply Called.");
        }
        public static void WriteLine(string str)
        {
            Console.WriteLine("WriteLine Called.");
        }
    }
}
