﻿using StringEngine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ILMaker
{
    public partial class OneTimeProcess : Form
    {
        public string InputFileNameWithoutExtns { get; set; }
        public static string SelectedOutputDirectory { get; set; }
        public OneTimeProcess()
        {
            InitializeComponent();
        }
        private void btn_selectFile_Click(object sender, EventArgs e)
        {           
            dlgOpenFile.InitialDirectory = "C:\\Users";

            dlgOpenFile.Filter = "dll files (*.dll)|*.dll|exe files (*.exe)|*.exe";
            dlgOpenFile.RestoreDirectory = true;
            dlgOpenFile.ShowDialog();

            try
            {
                if (dlgOpenFile.CheckFileExists)
                {
                    lbl_sts.Text = "Running...";

                    tbx_File.Text = dlgOpenFile.FileName;
                    InputFileNameWithoutExtns = Path.GetFileNameWithoutExtension(tbx_File.Text);

                    SelectedOutputDirectory = string.Format("{0}\\{1}", CommandBuilder.DefaultOutputDirectory, InputFileNameWithoutExtns);

                    //Convert Exe or Dll To IL
                    var sourceConfig = Path.GetDirectoryName(tbx_File.Text) + "\\" + InputFileNameWithoutExtns;
                    try
                    {
                        try
                        {
                            File.Copy(sourceConfig + ".exe.config", SelectedOutputDirectory + ".exe.config");
                        }
                        catch
                        {
                        }

                        var ilFile = string.Format("{0}.il", SelectedOutputDirectory);
                        var CommandForIL = string.Format("ildasm {0} /output:{1}", tbx_File.Text, ilFile);
                        CommandBuilder.RunCommand(CommandForIL, Directory.GetParent(Directory.GetParent(Environment.CurrentDirectory).FullName).FullName + "\\" + CommandBuilder.ildasmDirectory);

                        //Inject code in IL File
                        //string HookedContext = @"C:\Users\rajneesh.kumar\source\repos\SDIL\ILMaker\StaticILInstruction.json";

                        Inject.File(ilFile, Directory.GetParent(Directory.GetParent(Environment.CurrentDirectory).FullName).FullName + "\\" + CommandBuilder.InjecTCodeJson, ilFile);

                        //Convert IL back to EXE OR DLL

                        var exeFile = string.Format("{0}.exe", SelectedOutputDirectory);
                        var CommandForEXE = string.Format("ilasm {0} /output:{1}", ilFile, exeFile);
                        CommandBuilder.RunCommand(CommandForEXE, Directory.GetParent(Directory.GetParent(Environment.CurrentDirectory).FullName).FullName + "\\" + CommandBuilder.ilasmDirectory);

                        lbl_sts.Text = String.Format("Process completed. output:{0}", exeFile);

                    }
                    catch (Exception ex)
                    {
                        lbl_sts.Text = ex.ToString();
                    }

                }
            }
            catch (Exception ex)
            {
                lbl_sts.Text = ex.ToString();
            }
        }
    }
}
