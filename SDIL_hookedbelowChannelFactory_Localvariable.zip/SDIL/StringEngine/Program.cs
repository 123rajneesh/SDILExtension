using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputILFile = @"C:\Users\Rajne\source\repos\ChannelFactorySample_07_05_2019\ChannelFactorySample\bin\Debug\ChannelFactorySample.il";

            string outputILFile = @"C:\Users\Rajne\source\repos\SDIL_17_05_19\SDIL\StringEngine\bin\Debug\ChannelFactorySample.il";

            string hookedContext = @"C:\Users\Rajne\source\repos\SDIL_17_05_19\SDIL\StringEngine\serviceDetailIL.json";

            Inject.File(inputILFile, hookedContext, outputILFile);

            Console.ReadLine();
        }
    }
}
