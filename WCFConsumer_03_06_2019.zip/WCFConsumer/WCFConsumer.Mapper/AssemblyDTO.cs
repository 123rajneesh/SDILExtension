﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace WCFConsumer.Mapper
{
    public class AssemblyDTO
    {
        public AssemblyDTO()
        {
            this.TypeMethods = new List<Method>();
        }
        public Type Type { get; set; }
        public bool IsInterface { get; set; }
        public string TypeAssemblyName { get; set; }
        public string TypeFullName { get; set; }
        public string TypeName { get; set; }
        public string TypeNamespace { get; set; }
        public List<Method> TypeMethods { get; set; }
    }
    public class Method
    {
        public string MethodName { get; set; }
        public string MethodFullName { get; set; }
        public List<string> MethodParmeters { get; set; }
        public string MethodReturnType { get; set; }
        public string MethodSignature { get; set; }
    }

    public class AssemblyReader
    {
        public static AssemblyDTO GetCLRTypesInfo(Type type)
        {
            try
            {
                var dto = GetTypeInfo(type);

                return dto;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private static AssemblyDTO GetTypeInfo(Type type)
        {
            try
            {
                AssemblyDTO dto = new AssemblyDTO();

                dto.Type = type;

                dto.TypeAssemblyName = type.AssemblyQualifiedName;

                dto.TypeNamespace = type.Namespace;

                dto.TypeName = type.Name;

                dto.TypeFullName = type.FullName;

                dto.IsInterface = type.IsInterface;

                MethodInfo[] methodInfo = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly);

                foreach (var minfo in methodInfo)
                {
                    string[] param = minfo.GetParameters().Select(p => String.Format("{0} {1}", p.ParameterType.Name, p.Name)).ToArray();

                    string signature = String.Format("{0} {1}({2})", minfo.ReturnType.Name, minfo.Name, String.Join(",", param));

                    string fullname = String.Format("{0}.{1}({2})", type.FullName, minfo.Name, String.Join(",", param));

                    var method = new Method();

                    method.MethodName = minfo.Name;

                    method.MethodParmeters = param.ToList();

                    method.MethodSignature = signature;

                    method.MethodReturnType = minfo.ReturnType.Name;

                    method.MethodFullName = fullname;

                    dto.TypeMethods.Add(method);
                }

                return dto;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }

}
