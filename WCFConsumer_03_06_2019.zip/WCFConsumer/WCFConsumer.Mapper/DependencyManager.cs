﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCFConsumer.Mapper
{
    public class DependencyManager
    {
        public static string[] DependecyMember
        {
            get
            {
                if (Convert.ToBoolean(ConfigurationManager.AppSettings["Dependency:FilterEnabled"]))
                {
                    return ConfigurationManager.AppSettings["Dependency:FilterNamespace"].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                }
                else
                {
                    return ConfigurationManager.AppSettings["Dependency:Namespace"].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                };
            }
        }
    }

    public enum ServiceInfoType
    {
        ConsumerMethodInfo = 0,
        ServiceMethodInfo = 1,
        AddressInfo = 2,
        BindingInfo = 3,
        ContractInfo = 4
    }
}
