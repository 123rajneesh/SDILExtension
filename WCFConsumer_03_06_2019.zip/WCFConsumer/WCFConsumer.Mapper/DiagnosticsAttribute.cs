﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCFConsumer.Mapper
{
    public class DiagnosticsAttribute
    {
        public string BindingImplementation { get; set; }
        public int ApplicationDataId { get; set; }
        public string CallStack { get; set; }
        public string ConsumerMethodSig { get; set; }

        public string Address { get; set; }
        public string Contract { get; set; }
        public string Binding { get; set; }
    }


    public static class Bindings
    {

        public const string HttpBinding = "http";
        public const string NetTcpBinding = "tcp";
        public const string ClientProxy = "ClientProxy";
        public const string Unkown = "Unknown";
    }
    public class DefaultBinding
    {
        public static readonly Dictionary<string, string[]> Bindings = new Dictionary<string, string[]>() {
             { "basichttpbinding", new[] { "http", "https" } },

             { "wshttpbinding", new[] { "http", "https" } },

             { "wsdualhttpbinding", new[] { "http", "https" } },

             { "wsfederationhttpbinding", new[] { "http", "https" } },

             { "nettcpbinding", new[] { "tcp","net.tcp" } },

             { "netnamedpipebinding", new[] { "pipe" } },

             { "netmsmqbinding", new[] { "msmq" } },

             { "netpeertcpbinding", new[] { "p2p" } },

             { "msmqintegrationbinding", new[] { "msmq" } }

        };
    }

}

