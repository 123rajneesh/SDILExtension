﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace WCFConsumer.Mapper
{
    class Program
    {

        public static bool DependencyProxy { get { return Convert.ToBoolean(ConfigurationManager.AppSettings["Dependency:Proxy"]); } }
        public static string AssemblyConfigurationPath { get; set; }

        public static string AssemblyPath { get; set; }

        static void Main(string[] args)
        {
            var servicedto = TraceParser.GetDataFromTracingTables();

            AssemblyPath = args[0];
            
            AssemblyConfigurationPath = args[1];

            var assembly = Assembly.LoadFrom(AssemblyPath);
          
            /* Get Assembly types and their members */

            var modules = assembly.GetModules();

            List<AssemblyDTO> assemblydtocollection = new List<AssemblyDTO>();

            foreach (var module in modules)
            {
                Type[] types = module.GetTypes().Where(t => !t.IsInterface).ToArray();

                foreach (var type in types)
                {
                    AssemblyDTO dto = AssemblyReader.GetCLRTypesInfo(type);

                    assemblydtocollection.Add(dto);
                }
            }

            /*matched find types and their members*/

            foreach (var dto in assemblydtocollection)
            {
                //if matched then add dignostic code to assembly config//

            }

        }

    }
}
