﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCFConsumer.Mapper
{
    public class ServiceInbound
    {
        //[JsonProperty("methodIdentifier")]
        //public string MethodIdentifier { get; set; }

        //[JsonProperty("matchingKey")]
        //public string MatchingKey { get; set; }

        //[JsonProperty("apiName")]
        //public string ApiName { get; set; }

        //[JsonProperty("metadataInfo")]
        //public List<ObjectDictionary> MetaDataInfo
        //{
        //    get;
        //    set;
        //}
    }

}
