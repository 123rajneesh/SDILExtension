﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace WCFConsumer.Mapper
{
    public class TraceParser
    {
        private static string TRIM_KEYWORD_AT = "at";

        private static string SKIP_KEYWORD = "System";

        private static string INDEXOF_IN = " in ";

        private static string LOG_TRACE_FILE_PATH = @"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\bin\Debug\Traces.svclog";
        //Based on channelFactory
        public static List<DiagnosticsAttribute> GetDataFromTracingTables()
        {
            try
            {
                var dsColetions = ReadTraceFileToDataset();

                //var dtSystem = xmlDataset.Tables["System"];
                //var dtSubType = xmlDataset.Tables["SubType"];
                //var dtTimeCreated = xmlDataset.Tables["TimeCreated"];
                //var dtSource = xmlDataset.Tables["Source"];
                //var dtCorrelation = xmlDataset.Tables["Correlation"];
                //var dtExecution = xmlDataset.Tables["Execution"];

                List<DiagnosticsAttribute> diagnosticsAttribute = new List<DiagnosticsAttribute>();

                foreach (var ds in dsColetions)
                {
                    List<DiagnosticsAttribute> traceDTO = null;
                    //used for http data mapping
                    var dtApplicationData = ds.Tables["ApplicationData"];
                    var dtTraceData = ds.Tables["TraceData"];
                    var dtDataItem = ds.Tables["DataItem"];
                    var dtTraceRecord = ds.Tables["TraceRecord"];
                    var dtExtendedData = ds.Tables["ExtendedData"];
                    var dtMessageProperties = ds.Tables["MessageProperties"];
                    var dtSystemDiagnostics = ds.Tables["System.Diagnostics"];
                    var dtEndpointReference = ds.Tables["EndpointReference"];

                    switch (ds.DataSetName)
                    {
                        /*  */
                        case Bindings.HttpBinding:

                            //join tables with keys columns

                            traceDTO = (from dsd in dtSystemDiagnostics.AsEnumerable()
                                        join dtd in dtTraceData.AsEnumerable() on dsd.Field<int>("ApplicationData_Id") equals dtd.Field<int>("ApplicationData_Id")
                                        join ddi in dtDataItem.AsEnumerable() on dtd.Field<int>("TraceData_Id") equals ddi.Field<int>("TraceData_Id")
                                        join dtr in dtTraceRecord.AsEnumerable() on ddi.Field<int>("DataItem_Id") equals dtr.Field<int>("DataItem_Id")
                                        join ded in dtExtendedData.AsEnumerable() on dtr.Field<int>("TraceRecord_Id") equals ded.Field<int>("TraceRecord_Id")
                                        join dmp in dtMessageProperties.AsEnumerable() on ded.Field<int>("ExtendedData_Id") equals dmp.Field<int>("ExtendedData_Id")
                                        where dmp.Field<string>("Via") != null
                                        select new DiagnosticsAttribute
                                        {
                                            ApplicationDataId = dsd.Field<int>("ApplicationData_Id"),
                                            CallStack = dsd.Field<string>("CallStack"),
                                            ConsumerMethodSig = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ConsumerMethodInfo),
                                            Address = dmp.Field<string>("Via"),
                                            Contract = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ContractInfo),
                                            Binding = GetBinding(dmp.Field<string>("Via")),
                                            BindingImplementation = Bindings.Unkown

                                        }).Distinct().ToList<DiagnosticsAttribute>();
                            break;


                        case Bindings.NetTcpBinding:

                            //join tables with keys columns

                            traceDTO = (from dsd in dtSystemDiagnostics.AsEnumerable()
                                        join dtd in dtTraceData.AsEnumerable() on dsd.Field<int>("ApplicationData_Id") equals dtd.Field<int>("ApplicationData_Id")
                                        join ddi in dtDataItem.AsEnumerable() on dtd.Field<int>("TraceData_Id") equals ddi.Field<int>("TraceData_Id")
                                        join dtr in dtTraceRecord.AsEnumerable() on ddi.Field<int>("DataItem_Id") equals dtr.Field<int>("DataItem_Id")
                                        join ded in dtExtendedData.AsEnumerable() on dtr.Field<int>("TraceRecord_Id") equals ded.Field<int>("TraceRecord_Id")
                                        join der in dtEndpointReference.AsEnumerable() on ded.Field<int>("ExtendedData_Id") equals der.Field<int>("ExtendedData_Id")
                                        where der.Field<string>("Address") != null
                                        select new DiagnosticsAttribute
                                        {
                                            ApplicationDataId = dsd.Field<int>("ApplicationData_Id"),
                                            CallStack = dsd.Field<string>("CallStack"),
                                            ConsumerMethodSig = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ConsumerMethodInfo),
                                            Address = der.Field<string>("Address"),
                                            Contract = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ContractInfo),
                                            Binding = GetBinding(der.Field<string>("Address")),
                                            BindingImplementation = Bindings.Unkown
                                        }).Distinct().ToList<DiagnosticsAttribute>();

                            break;
                        case Bindings.ClientProxy:
                            //join tables with keys columns

                            traceDTO = (from dsd in dtSystemDiagnostics.AsEnumerable()
                                        join dtd in dtTraceData.AsEnumerable() on dsd.Field<int>("ApplicationData_Id") equals dtd.Field<int>("ApplicationData_Id")
                                        join ddi in dtDataItem.AsEnumerable() on dtd.Field<int>("TraceData_Id") equals ddi.Field<int>("TraceData_Id")
                                        join dtr in dtTraceRecord.AsEnumerable() on ddi.Field<int>("DataItem_Id") equals dtr.Field<int>("DataItem_Id")
                                        join ded in dtExtendedData.AsEnumerable() on dtr.Field<int>("TraceRecord_Id") equals ded.Field<int>("TraceRecord_Id")
                                        where ded.Field<string>("RemoteEndpointUri") != null
                                        select new DiagnosticsAttribute
                                        {
                                            ApplicationDataId = dsd.Field<int>("ApplicationData_Id"),
                                            CallStack = dsd.Field<string>("CallStack"),
                                            ConsumerMethodSig = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ConsumerMethodInfo),
                                            Address = ded.Field<string>("RemoteEndpointUri"),
                                            Contract = ReadCallStack(ded.Field<string>("ContractName"), ServiceInfoType.ContractInfo),
                                            Binding = ded.Field<string>("Binding"),
                                            BindingImplementation = Bindings.ClientProxy
                                        }).Distinct().ToList<DiagnosticsAttribute>();
                            break;
                    }
                    if (traceDTO != null)
                        diagnosticsAttribute.AddRange(traceDTO);
                }
                var filter = UpdateForClientProxy(diagnosticsAttribute);

                return filter;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static List<DiagnosticsAttribute> UpdateForClientProxy(List<DiagnosticsAttribute> diagnosticsAttribute)
        {
            var isProxyDto = diagnosticsAttribute.Where(x => x.BindingImplementation == Bindings.ClientProxy).ToList();

            var isUnknownDto = diagnosticsAttribute.Where(x => x.BindingImplementation == Bindings.Unkown).ToList();

            List<DiagnosticsAttribute> filter = new List<DiagnosticsAttribute>();

            if (isProxyDto.Count > 0)
            {
                foreach (var p in isProxyDto)
                {
                    var temp = isUnknownDto.Where(u => u.Contract.ToLower() == p.Contract.ToLower() && u.Binding.ToLower() == p.Binding.ToLower() && u.Address.ToLower() == p.Address.ToLower()).ToList();

                    foreach (var t in temp)
                    {
                        if (!t.CallStack.Contains(p.ConsumerMethodSig))
                        {
                            filter.Add(t);
                        }
                    }
                    filter.Add(p);
                }
            }
            else
            {
                filter.AddRange(isUnknownDto);
            }
            var minDto = filter.Select(x => new DiagnosticsAttribute
            {
                Contract = x.Contract,
                Binding = x.Binding,
                Address = x.Address,
                ConsumerMethodSig = x.ConsumerMethodSig
            }).Distinct().ToList();

            List<DiagnosticsAttribute> distinct =
                                            minDto
                                            .GroupBy(a => new { a.Contract, a.Binding, a.Address })
                                            .Select(g => g.First())
                                            .ToList();
            return distinct;
        }

        private static List<DataSet> ReadTraceFileToDataset()
        {
            try
            {
                List<DataSet> dsCollection = null;

                DataSet dshttpTrace = null;
                DataSet dsnetTcpTrace = null;
                DataSet dsProxyTrace = null;

                if (File.Exists(LOG_TRACE_FILE_PATH))
                {
                    dsCollection = new List<DataSet>();

                    dshttpTrace = new DataSet();

                    dsnetTcpTrace = new DataSet();

                    dsProxyTrace = new DataSet();

                    //Setting to read all root elements
                    XmlReaderSettings settings = new XmlReaderSettings();

                    settings.ConformanceLevel = ConformanceLevel.Fragment;

                    //Invoke the ReadXmlSchema method with the from resourec file object.               
                    dshttpTrace.ReadXmlSchema(new StringReader(DiagnosticsResource.DataSet_Http_Schema));
                    dsnetTcpTrace.ReadXmlSchema(new StringReader(DiagnosticsResource.DataSet_NetTcp_Schema));
                    dsProxyTrace.ReadXmlSchema(new StringReader(DiagnosticsResource.DataSet_Proxy_Schema));

                    using (XmlReader reader = XmlReader.Create(LOG_TRACE_FILE_PATH, settings))
                    {
                        while (reader.Read())
                        {
                            dshttpTrace.ReadXml(reader, XmlReadMode.Auto);

                        }

                    }
                    using (XmlReader reader = XmlReader.Create(LOG_TRACE_FILE_PATH, settings))
                    {
                        while (reader.Read())
                        {
                            dsnetTcpTrace.ReadXml(reader, XmlReadMode.Auto);
                        }

                    }
                    using (XmlReader reader = XmlReader.Create(LOG_TRACE_FILE_PATH, settings))
                    {
                        while (reader.Read())
                        {
                            dsProxyTrace.ReadXml(reader, XmlReadMode.Auto);
                        }

                    }

                    dshttpTrace.DataSetName = Bindings.HttpBinding;
                    dsnetTcpTrace.DataSetName = Bindings.NetTcpBinding;
                    dsProxyTrace.DataSetName = Bindings.ClientProxy;

                    dsCollection.Add(dshttpTrace);
                    dsCollection.Add(dsnetTcpTrace);
                    dsCollection.Add(dsProxyTrace);
                }
                return dsCollection;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        //Read call stack to get properties values
        private static string ReadCallStack(string callStack, ServiceInfoType serviceInfoType)
        {
            try
            {
                string value = string.Empty;
                using (StringReader reader = new StringReader(callStack))
                {
                    while (true)
                    {
                        var line = reader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }

                        //skip systems calls
                        line = line.TrimStart(' ');

                        var nsline = line.TrimStart(TRIM_KEYWORD_AT.ToCharArray()).TrimStart(' ');

                        if (!nsline.StartsWith(SKIP_KEYWORD))
                        {
                            var indexOfin = nsline.IndexOf(INDEXOF_IN);

                            switch (serviceInfoType)
                            {
                                case ServiceInfoType.ContractInfo:
                                    if (indexOfin == -1)
                                    {
                                        return GetContract(nsline);
                                    }
                                    break;
                                case ServiceInfoType.ServiceMethodInfo:
                                    if (indexOfin == -1)
                                    {
                                        value = nsline.Trim();
                                        return value;
                                    }
                                    break;
                                case ServiceInfoType.ConsumerMethodInfo:
                                    if (indexOfin > -1)
                                    {
                                        value = nsline.Substring(0, indexOfin).Trim();
                                        if (!value.Contains("ctor()"))
                                            return value;
                                    }
                                    break;
                            }
                        }
                    }
                    return value;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static string GetContract(string nsline)
        {
            string contract = string.Empty;
            try
            {
                var line = nsline.Trim();
                var lastIndexOf_Dot = line.LastIndexOf('.');

                if (line.Contains('('))
                {
                    var fullName = line.Substring(0, lastIndexOf_Dot);

                    var fullNameIdx = fullName.LastIndexOf('.') + 1;

                    contract = line.Substring(fullNameIdx, fullName.Length - fullNameIdx);
                }
                else
                {
                    contract = line.Substring(lastIndexOf_Dot, line.Length - lastIndexOf_Dot).Trim('.');
                }
                return contract;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static string GetBinding(string serviceUrl)
        {
            Uri uri = new Uri(serviceUrl);
            //string requested = uri.Scheme + Uri.SchemeDelimiter + uri.Host + ":" + uri.Port;
            string protocol = uri.Scheme;

            string binding = string.Empty;

            foreach (var bb in DefaultBinding.Bindings)
            {
                foreach (var v in bb.Value)
                {
                    if (v == protocol)
                    {
                        binding = bb.Key;
                        return binding;
                    }

                }
            }
            return binding;
        }
    }
}
