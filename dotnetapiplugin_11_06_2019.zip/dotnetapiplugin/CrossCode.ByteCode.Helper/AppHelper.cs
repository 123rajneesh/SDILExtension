﻿//-----------------------------------------------------------------------
// <copyright file="AppHelper.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.ByteCode.Helper
{
    using System.Collections.Generic;

    public enum RoutingTypes
    {
        None,
        AttributeRouting,
        TemplateRouting,
        MixedRouting
    }

    /// <summary>
    /// This class helps in getting the information around http client
    /// </summary>
    public class AppHelper
    {
        private const string HTTPLIBNAME = "System.Net.Http";
        private const string SERVICEMODELLIBNAME = "System.ServiceModel";

        public static List<string> GetHttpClientConnectedLibraryInApp()
        {
            List<string> allHttpClient = new List<string>();
            allHttpClient.Add(HTTPLIBNAME);

            return allHttpClient;
        }

        public static List<Dictionary<string, string>> GetHttpClientConnectedLibraryInAppAll()
        {
            List<Dictionary<string, string>> allHttpClient = new List<Dictionary<string, string>>();
            Dictionary<string, string> httpClient = new Dictionary<string, string>();

            httpClient.Add("A", HTTPLIBNAME + ".dll");
            httpClient.Add("N", HTTPLIBNAME);
            httpClient.Add("C", "HttpClient");
            httpClient.Add("M", "PostAsync");
            httpClient.Add("L", SERVICEMODELLIBNAME);
            httpClient.Add("P", SERVICEMODELLIBNAME + ".dll");

            allHttpClient.Add(httpClient);
            return allHttpClient;
        }

        public static List<string> GetFrameworkLibraryOfNET()
        {
            List<string> allFrameworkAssembly = new List<string>();
            allFrameworkAssembly.Add(HTTPLIBNAME);
            return allFrameworkAssembly;
        }
    }
}
