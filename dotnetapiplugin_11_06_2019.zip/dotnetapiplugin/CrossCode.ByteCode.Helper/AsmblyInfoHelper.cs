﻿//-----------------------------------------------------------------------
// <copyright file="TemplateRoutingData.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

namespace CrossCode.ByteCode.Helper
{
    /// <summary>
    /// Helper class for Assembly related information extraction
    /// </summary>
    public class AsmblyInfoHelper
    {

        public static List<Type> GetAllEntities(Type t)
        {
            return AppDomain.CurrentDomain
                    .GetAssemblies()//.Where(y=> !y.GetName().Name.Contains("EdinaRealty.Web.Api")).ToArray().
                    .SelectMany(x => x.GetTypes()).Where(x => t.IsAssignableFrom(x) && !x.IsInterface && !x.IsAbstract)
                     .Select(x => x).ToList();
        }
    }
}
