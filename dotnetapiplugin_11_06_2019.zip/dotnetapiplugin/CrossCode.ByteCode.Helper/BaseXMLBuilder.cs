﻿//-----------------------------------------------------------------------
// <copyright file="XMLNodeBuilder.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using CrossCode.Helper;
using System.IO;
using System.Xml;

namespace CrossCode.ByteCode.Helper
{
    public abstract class BaseXMLBuilder
    {

        public static void GetXMLConfigSectionByXpath(string appFullPath, out XmlDocument doc, out XmlElement webConfigData, string XpathConfiguSection)
        {
            string SourcePath = Path.GetDirectoryName(PathHelper.APIPHostedpath);
            doc = new XmlDocument();
            doc.Load(appFullPath);

            webConfigData = (XmlElement)doc.SelectSingleNode(XpathConfiguSection);
        }
    }
}