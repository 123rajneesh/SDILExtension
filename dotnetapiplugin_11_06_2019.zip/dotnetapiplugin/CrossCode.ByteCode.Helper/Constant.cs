﻿//-----------------------------------------------------------------------
// <copyright file="ConstantAPIModule.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using CrossCode.Globals;
using System.Collections.Generic;

namespace CrossCode.ByteCode.Helper
{
    public enum ServiceProd
    {
        HTTPOnly,
        WCF,
        WCFOnly,
        SOAP,
        HTTPWCF,
        WebService,
        HTTPWS,
        All,
        None
    }
    public enum Order
    {
        Controller,
        Action
    }

    public enum TemplateType
    {
        OnlyController,
        ControlerWithAction
    }
    public class ConstantAPIModule
    {
        public const string Seperatorline = ":line";
        public const string ApplicationDatatNode = "ApplicationData";
        public const string SeperatorCreateCodeStackTrace = "Create(";
        public const string SeperatorWebRequestCodeStackTrace = "HttpWebRequest(";
        public const string UrlRegx = @"^(http|https|ftp|)\://|[a-zA-Z0-9\-\.]+\.[a-zA-Z](:[a-zA-Z0-9]*)?/?([a-zA-Z0-9\-\._\?\,\'/\\\+&amp;%\$#\=~])*[^\.\,\)\(\s]$";
        public const string RootNodeStart = "<Catalog>";
        public const string RootNodeEnd = "</Catalog>";

        public const string RegisterRouteMethod = "Register";
        public const string RouteAttributeTypeName = "Route";

        public const string HttpRouteAttributeName = "HttpRoute";
        public static readonly string RoutingSeperator = Constants.RouteSeperator;

        public const string MethodIdentifierKeyHeder = "MethodKey";
        public const string MethodNameKeyHeder = "MethodName";
        public const string SeparatorAttribute = "#@:";
        public const string MethodNameKeyHeader = "MethodName";
        public const string ParamInfoNameKeyHeader = "ParamInfo";
        public const string ControllerToken = "{controller}";
        public const string ActionToken = "{action}";
    }

    /*WCF Settings*/
    public enum ServiceInfoType
    {
        ConsumerMethodInfo = 0,
        ServiceMethodInfo = 1,
        AddressInfo = 2,
        BindingInfo = 3,
        ContractInfo = 4
    }
    public class DefaultBinding
    {
        public static readonly Dictionary<string, string[]> Bindings = new Dictionary<string, string[]>() {
             { "basichttpbinding", new[] { "http", "https" } },

             { "wshttpbinding", new[] { "http", "https" } },

             { "wsdualhttpbinding", new[] { "http", "https" } },

             { "wsfederationhttpbinding", new[] { "http", "https" } },

             { "nettcpbinding", new[] { "tcp","net.tcp" } },

             { "netnamedpipebinding", new[] { "pipe" } },

             { "netmsmqbinding", new[] { "msmq" } },

             { "netpeertcpbinding", new[] { "p2p" } },

             { "msmqintegrationbinding", new[] { "msmq" } }

        };
    }
}
