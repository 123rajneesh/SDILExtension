﻿//-----------------------------------------------------------------------
// <copyright file="CustomStringComparer.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.DeepTrace.Engine
{
    using System.Collections.Generic;

    public class CustomStringComparer : EqualityComparer<string>
    {
        public override bool Equals(string b1, string b2)
        {
            if (b1.Replace(" ", "") == b2.Replace(" ", ""))
                return true;
            else
                return false;
        }

        public override int GetHashCode(string bx)
        {
            return bx.GetHashCode();
        }
    }
}
