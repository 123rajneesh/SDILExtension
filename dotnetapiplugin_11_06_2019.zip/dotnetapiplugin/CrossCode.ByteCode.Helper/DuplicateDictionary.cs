﻿//-----------------------------------------------------------------------
// <copyright file="DuplicateDictionary.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.ByteCode.Helper
{
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Custom Dictionary class which allows to add the dupicate value in a dictionary.
    /// </summary>
    /// <typeparam name="TKey">Key item</typeparam>
    /// <typeparam name="TValue">Value item</typeparam>
    public class DuplicateDictionary<TKey, TValue> : Dictionary<TKey, List<TValue>>, IEnumerable<KeyValuePair<TKey, TValue>>
    {
        public new IEnumerable<KeyValuePair<TKey, TValue>> this[TKey key]
        {
            get
            {
                List<TValue> values;
                if (!TryGetValue(key, out values))
                {
                    return Enumerable.Empty<KeyValuePair<TKey, TValue>>();
                }

                return values.Select(v => new KeyValuePair<TKey, TValue>(key, v));
            }
            set
            {
                foreach (var _value in value.Select(kvp => kvp.Value))
                {
                    Add(key, _value);
                }
            }
        }



        public void Add(TKey key, TValue value)
        {
            List<TValue> values;
            if (!TryGetValue(key, out values))
            {
                values = new List<TValue>();
                Add(key, values);
            }
            values.Add(value);
        }

        public new IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
        {
            foreach (var item in ((Dictionary<TKey, List<TValue>>)this))
            {
                foreach (var value in item.Value)
                {
                    yield return new KeyValuePair<TKey, TValue>(item.Key, value);
                }
            }
        }
    }
}
