﻿//-----------------------------------------------------------------------
// <copyright file="FileHelper.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.DeepTrace.Engine
{
    using CrossCode.Helper;
    using CrossCode.Log;
    using System;
    using System.IO;

    /// <summary>
    /// Helper class for file related actions
    /// </summary>
    public class FileHelper
    {
        private const string httpLog = "System.Net.trace.trcnet"; 
        private const string RenameFileName = "{0}.log";
        private const string LocalLogFolderName = "httpTrace";
        private const string logFileNameWithExtension ="traces.svclog";

        public static string RecollectTheLogInLocal(string sourceDir, string processID)
        {
            string localLogPath = Path.Combine(PathHelper.GetCurrentExecPath, LocalLogFolderName, string.Format(RenameFileName, processID));
            string sourceLogFolder = Path.Combine(PathHelper.GetCurrentExecPath, LocalLogFolderName);

            if (!Directory.Exists(sourceLogFolder))
            {
                Directory.CreateDirectory(sourceLogFolder);
            }

            if (!File.Exists(localLogPath))
            {
                string path = Path.Combine(sourceDir, httpLog);
                string content =  LoadFile(path);
                File.WriteAllText(localLogPath, content);
            }
            else
            {
                string sourceFileName = Path.Combine(sourceDir, httpLog);

                if (File.Exists(sourceFileName))
                {
                    File.Copy(sourceFileName, localLogPath, true);
                    AppLog.Debug("Trace file generated for application path = {0}", sourceFileName);
                }
                else
                {
                    AppLog.Debug("Trace file could not be generated for application path = {0}", sourceFileName);
                }
            }

            return localLogPath;
        }
        public static string RecollectStandAloneLogInLocal(string sourceDir, string processID)
        {
            string localLogPath = Path.Combine(PathHelper.GetCurrentExecPath, LocalLogFolderName, string.Format(RenameFileName, processID));
            string sourceLogFolder = Path.Combine(PathHelper.GetCurrentExecPath, LocalLogFolderName);

            if (!Directory.Exists(sourceLogFolder))
            {
                Directory.CreateDirectory(sourceLogFolder);
            }

            if (!File.Exists(localLogPath))
            {
                string path = Path.Combine(sourceDir, logFileNameWithExtension);
                string content = LoadFile(path);
                File.WriteAllText(localLogPath, content);
            }
            else
            {
                string sourceFileName = Path.Combine(sourceDir, logFileNameWithExtension);

                if (File.Exists(sourceFileName))
                {
                    File.Copy(sourceFileName, localLogPath, true);
                    AppLog.Debug("Trace file generated for application path = {0}", sourceFileName);
                }
                else
                {
                    AppLog.Debug("Trace file could not be generated for application path = {0}", sourceFileName);
                }
            }

            return localLogPath;
        }

        private static string  LoadFile(string filePath)
        {
            string data = string.Empty;
            try
            {
                using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    using (StreamReader streamReader = new StreamReader(fileStream))
                    {
                        data = streamReader.ReadToEnd();
                    }
                }
            }
            catch (Exception ex)
            {
                
            }
            return data;
        }
    }
}
