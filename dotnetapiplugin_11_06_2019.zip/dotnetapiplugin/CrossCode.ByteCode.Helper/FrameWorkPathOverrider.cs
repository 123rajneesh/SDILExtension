﻿//-----------------------------------------------------------------------
// <copyright file="FrameWorkPathOverrider.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using System;
    using System.IO;
    using System.Reflection;

    /// <summary>
    /// Class to change the default assembly  loading path.
    /// </summary>
    public class FrameWorkPathOverrider
    {

        public string SourcePath
        {
            get;
            set;
        }


        /// <summary>
        /// Assem Resolve Event Handler
        /// </summary>
        /// <param name="sender">event sender</param>
        /// <param name="args">all the arguments while sending event notification</param>
        /// <returns>after the failing resolution it si the path to bind the assembly.</returns>
        public Assembly AssemResolveEventHandler(object sender, ResolveEventArgs args)
        {
            Assembly myAssembly = null;
           string withoutExt = Path.GetDirectoryName(this.SourcePath);
            string strTempAssmbPath = string.Empty;

            try
            {
                if (args.Name.IndexOf(",") > 0)
                {
                    strTempAssmbPath = Path.Combine(withoutExt, args.Name.Substring(0, args.Name.IndexOf(",")) + ".dll");
                }
                else
                {
                    strTempAssmbPath = args.Name;
                }

                //// Load the assembly from the specified path. 
                myAssembly = Assembly.LoadFrom(strTempAssmbPath);
            }
            catch (Exception ex)
            {
                // not logging because of known error  wrong path args.Name
                Console.WriteLine(ex.Message);
            }

            //// Return the loaded assembly.
            return myAssembly;
        }

    }
}
