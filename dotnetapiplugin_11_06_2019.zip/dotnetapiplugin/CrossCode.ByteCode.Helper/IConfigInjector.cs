﻿//-----------------------------------------------------------------------
// <copyright file="TraceConfigInjector.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.ByteCode.Helper
{
    public interface IConfigInjector
    {
       void AddTraceConfigInApplication(string appfullPath);      
    }
}