﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Ashutosh Kumar SIngh 
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// This is sample to create MSIL from reflection and can be extended further.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.Reflection;
using System.Reflection.Emit;

namespace ILEmitHelper
{
    class ILEmitTest
    {
        public MethodBuilder BuildMethodStartTime(TypeBuilder type)
        {
            // Declaring method builder
            // Method attributes
            System.Reflection.MethodAttributes methodAttributes = System.Reflection.MethodAttributes.Public |
                                                                  System.Reflection.MethodAttributes.HideBySig |
                                                                  System.Reflection.MethodAttributes.Static;

            MethodBuilder method = type.DefineMethod("StartTime", methodAttributes);
            // Preparing Reflection instances
            ConstructorInfo ctor1 = typeof(DateTime).GetConstructor(
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                null,
                new Type[]
                    {
                        typeof (Int32),
                        typeof (Int32),
                        typeof (Int32),
                        typeof (Int32),
                        typeof (Int32),
                        typeof (Int32)
                    },
                null
                );
            // Setting return type
            method.SetReturnType(typeof(DateTime));
            // Adding parameters
            ILGenerator gen = method.GetILGenerator();
            // Preparing locals
            LocalBuilder cs = gen.DeclareLocal(typeof(DateTime));
            // Preparing labels
            Label label22 = gen.DefineLabel();
            // Writing body
            gen.Emit(OpCodes.Nop);
            gen.Emit(OpCodes.Ldc_I4, 2000);
            gen.Emit(OpCodes.Ldc_I4_7);
            gen.Emit(OpCodes.Ldc_I4_S, 23);
            gen.Emit(OpCodes.Ldc_I4_S, 15);
            gen.Emit(OpCodes.Ldc_I4_S, 15);
            gen.Emit(OpCodes.Ldc_I4_0);
            gen.Emit(OpCodes.Newobj, ctor1);
            gen.Emit(OpCodes.Stloc_0);
            gen.Emit(OpCodes.Br_S, label22);
            gen.MarkLabel(label22);
            gen.Emit(OpCodes.Ldloc_0);
            gen.Emit(OpCodes.Ret);
            // finished
            return method;
        }

        static void Main(string[] args)
        {
            ILEmitTest prg = new ILEmitTest();
            AppDomain currentDomain = AppDomain.CurrentDomain;
            AssemblyName assemName = new AssemblyName();
            assemName.Name = "MyAssembly";

            AssemblyBuilder assemBuilder = currentDomain.DefineDynamicAssembly(assemName, AssemblyBuilderAccess.Run);

            ModuleBuilder moduleBuilder = assemBuilder.DefineDynamicModule("MyModule", true);

            TypeBuilder typeBuilder = moduleBuilder.DefineType("MyClass", TypeAttributes.Public);
            var methodBuilder = prg.BuildMethodStartTime(typeBuilder);

            ILEmitTest.CallDynamicMethod(typeBuilder);
            ILEmitTest.CallStaticMethod(typeBuilder);

            //assemBuilder.Save("m.dll", PortableExecutableKinds.ILOnly, ImageFileMachine.AMD64);

            assemBuilder.Save("mymodule.dll");
            System.Console.ReadLine();
        }

        private static void CallStaticMethod(TypeBuilder typeBuilder)
        {
            Type t = typeBuilder.CreateType();
            MethodInfo helloWorld = t.GetMethod("StartTime");
            if (helloWorld != null)
            {
                DateTime dt = (DateTime)helloWorld.Invoke(null, null);
                System.Console.WriteLine("Time is: " + dt.ToShortTimeString());
            }
        }

        private static void CallDynamicMethod(TypeBuilder typeBuilder)
        {
            Type t = typeBuilder.CreateType();
            if (t != null)
            {
                object o = Activator.CreateInstance(t);
                MethodInfo helloWorld = t.GetMethod("StartTime");
                if (helloWorld != null)
                {
                    DateTime dt = (DateTime)helloWorld.Invoke(o, null);
                    System.Console.WriteLine("Time is: " + dt.ToShortTimeString());
                }
            }
        }
    }
}
