﻿//-----------------------------------------------------------------------
// <copyright file="KeyComparer.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.ByteCode.Helper
{
    using System.Collections.Generic;

    /// <summary>
    /// Comparing key and value of a KVP data structure
    /// </summary>
    public class KeyComparer : IEqualityComparer<KeyValuePair<string, string>>
    {
        public bool Equals(KeyValuePair<string, string> x, KeyValuePair<string, string> y)
        {
            return x.Key == y.Key && x.Value == y.Value;
        }
        public int GetHashCode(KeyValuePair<string, string> keyAndValue)
        {
            return keyAndValue.Key == null ? 0 : keyAndValue.GetHashCode();
        }
    }
}
