﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace CrossCode.ByteCode.Helper
{
    public class WCFHelper
    {
        private static string TRIM_KEYWORD_AT = "at";

        private static string SKIP_KEYWORD = "System";

        private static string INDEXOF_IN = " in ";

        public static string ReadCallStack(string callStack, ServiceInfoType serviceInfoType)
        {
            try
            {
                string value = string.Empty;
                using (StringReader reader = new StringReader(callStack))
                {
                    while (true)
                    {
                        var line = reader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }
                        //skip systems types calls
                        line = line.TrimStart(' ');

                        var nsline = line.TrimStart(TRIM_KEYWORD_AT.ToCharArray()).TrimStart(' ');

                        if (!nsline.StartsWith(SKIP_KEYWORD))
                        {
                            var indexOfin = nsline.IndexOf(INDEXOF_IN);

                            switch (serviceInfoType)
                            {
                                case ServiceInfoType.ContractInfo:
                                    if (indexOfin == -1)
                                    {
                                        return GetContract(nsline);
                                    }
                                    break;
                                case ServiceInfoType.ServiceMethodInfo:
                                    if (indexOfin == -1)
                                    {
                                        value = nsline.Trim();
                                        return value;
                                    }
                                    break;
                                case ServiceInfoType.ConsumerMethodInfo:
                                    if (indexOfin > -1)
                                    {
                                        value = nsline.Substring(0, indexOfin).Trim();
                                        if (!value.Contains("ctor()"))
                                            return value;
                                    }
                                    break;
                            }
                        }
                    }
                    return value;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static string GetContract(string nsline)
        {
            string contract = string.Empty;
            try
            {
                var line = nsline.Trim();
                var lastIndexOf_Dot = line.LastIndexOf('.');

                if (line.Contains('('))
                {
                    var fullName = line.Substring(0, lastIndexOf_Dot);

                    var fullNameIdx = fullName.LastIndexOf('.') + 1;

                    contract = line.Substring(fullNameIdx, fullName.Length - fullNameIdx);
                }
                else
                {
                    contract = line.Substring(lastIndexOf_Dot, line.Length - lastIndexOf_Dot).Trim('.');
                }
                return contract;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static string GetBinding(string serviceUrl)
        {
            Uri uri = new Uri(serviceUrl);
            //string requested = uri.Scheme + Uri.SchemeDelimiter + uri.Host + ":" + uri.Port;
            string protocol = uri.Scheme;

            string binding = string.Empty;

            foreach (var bb in DefaultBinding.Bindings)
            {
                foreach (var v in bb.Value)
                {
                    if (v == protocol)
                    {
                        binding = bb.Key;
                        return binding;
                    }

                }
            }
            return binding;
        }

        public static List<KeyValuePair<string, string>> GenericPropertyGetter<T>(T wCFConsumerData)
        {
            List<KeyValuePair<string, string>> pairs = new List<KeyValuePair<string, string>>();

            var propInfo = wCFConsumerData.GetType().GetProperties();

            foreach (var property in propInfo)
            {
                var propName = property.Name;

                var PropValue = property.GetValue(wCFConsumerData, null);

                pairs.Add(new KeyValuePair<string, string>(propName, PropValue.ToString()));
            }

            return pairs;
        }
    }
  
}
