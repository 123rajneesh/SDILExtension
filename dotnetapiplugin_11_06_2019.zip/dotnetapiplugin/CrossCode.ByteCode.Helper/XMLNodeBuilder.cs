﻿//-----------------------------------------------------------------------
// <copyright file="XMLNodeBuilder.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.ByteCode.Helper
{
    using System.Xml;

    /// <summary>
    /// This class manipulates with XMl structure and add/modify the node and attribute in a XMl file
    /// </summary>
    public class XMLNodeBuilder : BaseXMLBuilder
    {
        public static void CheckNAddSwitchesInConfig(XmlDocument doc, XmlElement webConfigData, XmlNodeList switchesNode, string innerXML, ref bool isConfigNeedsToAdd)
        {
            if (switchesNode != null && switchesNode.Count > 0)
            {
                bool isConfigAdded = false;

                foreach (XmlNode item in switchesNode[0].ChildNodes)
                {
                    if (item.Attributes.GetNamedItem("name").Value == "System.Net")
                    {
                        isConfigAdded = true;
                    }
                }

                if (!isConfigAdded)
                {
                    isConfigNeedsToAdd = true;

                    XmlElement sorcNode = doc.CreateElement("add");

                    XmlAttribute xmlNameAttribute = doc.CreateAttribute("name");
                    xmlNameAttribute.Value = "System.Net";

                    XmlAttribute valueAttribute = doc.CreateAttribute("value");
                    valueAttribute.Value = "All";

                    sorcNode.SetAttributeNode(xmlNameAttribute);
                    sorcNode.SetAttributeNode(valueAttribute);

                    switchesNode[0].PrependChild(sorcNode);
                }

            }
            else
            {
                var sorcNode = doc.CreateNode("element", "switches", "");
                sorcNode.InnerXml = innerXML;
                webConfigData.AppendChild(sorcNode);
                isConfigNeedsToAdd = true;

            }
        }

        public static void CheckNAddSharedListeners(XmlDocument doc, XmlElement webConfigData, XmlNodeList sharedListenerAttr, string innerXML, ref bool isConfigNeedsToAdd)
        {
            if (sharedListenerAttr != null && sharedListenerAttr.Count > 0)
            {
                bool isConfigAdded = false;
                //"<add name="CCTraceFile" " +
                //    "type="System.Diagnostics.XmlWriterTraceListener" " +
                //    "traceOutputOptions="ProcessId, DateTime, Callstack" " +
                //    "initializeData="System.Net.trace.trcnet" />"

                foreach (XmlNode item in sharedListenerAttr[0].ChildNodes)
                {
                    if (item.Attributes.GetNamedItem("name").Value == "CCTraceFile")
                    {
                        isConfigAdded = true;
                    }
                }

                if (!isConfigAdded)
                {
                    isConfigNeedsToAdd = true;
                    XmlElement sorcNode = doc.CreateElement("add");

                    XmlAttribute xmlNameAttribute = doc.CreateAttribute("name");
                    xmlNameAttribute.Value = "CCTraceFile";

                    XmlAttribute typeAttribute = doc.CreateAttribute("type");
                    typeAttribute.Value = "System.Diagnostics.XmlWriterTraceListener";

                    XmlAttribute traceAttribute = doc.CreateAttribute("traceOutputOptions");
                    traceAttribute.Value = "ProcessId, DateTime, Callstack";

                    XmlAttribute initializeDataAttribute = doc.CreateAttribute("initializeData");
                    initializeDataAttribute.Value = "System.Net.trace.trcnet";

                    sorcNode.SetAttributeNode(xmlNameAttribute);
                    sorcNode.SetAttributeNode(typeAttribute);
                    sorcNode.SetAttributeNode(traceAttribute);
                    sorcNode.SetAttributeNode(initializeDataAttribute);

                    sharedListenerAttr[0].PrependChild(sorcNode);
                }
            }
            else
            {
                var sorcNode = doc.CreateNode("element", "sharedListeners", "");
                sorcNode.InnerXml = innerXML;
                webConfigData.AppendChild(sorcNode);
                isConfigNeedsToAdd = true;
            }
        }
        public static void CheckNAddListeners(XmlDocument doc, XmlElement webConfigData, XmlNodeList sharedListenerAttr, string innerXML, ref bool isConfigNeedsToAdd)
        {
            if (sharedListenerAttr != null && sharedListenerAttr.Count > 0)
            {
                bool isConfigAdded = false;
                //"<add name="CCTraceFile" " +
                //    "type="System.Diagnostics.XmlWriterTraceListener" " +
                //    "traceOutputOptions="ProcessId, DateTime, Callstack" " +
                //    "initializeData="System.Net.trace.trcnet" />"

                foreach (XmlNode item in sharedListenerAttr[0].ChildNodes)
                {
                    if (item.Attributes.GetNamedItem("name").Value == "CCTraceFile")
                    {
                        isConfigAdded = true;
                    }
                }

                if (!isConfigAdded)
                {
                    isConfigNeedsToAdd = true;
                    XmlElement sorcNode = doc.CreateElement("add");

                    XmlAttribute xmlNameAttribute = doc.CreateAttribute("name");
                    xmlNameAttribute.Value = "CCTraceFile";

                    XmlAttribute typeAttribute = doc.CreateAttribute("type");
                    typeAttribute.Value = "System.Diagnostics.XmlWriterTraceListener";

                    XmlAttribute traceAttribute = doc.CreateAttribute("traceOutputOptions");
                    traceAttribute.Value = "ProcessId, DateTime, Callstack";

                    XmlAttribute initializeDataAttribute = doc.CreateAttribute("initializeData");
                    initializeDataAttribute.Value = "Traces.svclog";

                    sorcNode.SetAttributeNode(xmlNameAttribute);
                    sorcNode.SetAttributeNode(typeAttribute);
                    sorcNode.SetAttributeNode(traceAttribute);
                    sorcNode.SetAttributeNode(initializeDataAttribute);

                    sharedListenerAttr[0].PrependChild(sorcNode);
                }
            }
            else
            {
                var sorcNode = doc.CreateNode("element", "listeners", "");
                sorcNode.InnerXml = innerXML;
                webConfigData.AppendChild(sorcNode);
                isConfigNeedsToAdd = true;
            }
        }

        public static void ChekNAddSourceInConfig(XmlDocument doc, XmlElement webConfigData, XmlNodeList sourceAttr, string innerXML, ref bool isConfigNeedsToAdd)
        {
            // <sources>
            //<source name = "System.Net" maxdatasize = "1024" switchValue = "Verbose">
            //       <listeners>
            //         <add name = "CCTraceFile" />
            //        </listeners>
            //      </source>
            //    </sources>

            if (sourceAttr != null && sourceAttr.Count > 0)
            {
                bool isConfigAdded = false;

                foreach (XmlNode item in sourceAttr[0].ChildNodes[0].ChildNodes[0])
                {
                    if (item.Attributes.GetNamedItem("name").Value == "CCTraceFile")
                    {
                        isConfigAdded = true;
                    }
                }

                if (!isConfigAdded)
                {
                    isConfigNeedsToAdd = true;
                    XmlElement sorcNode = doc.CreateElement("add");

                    XmlAttribute xmlNameAttribute = doc.CreateAttribute("name");
                    xmlNameAttribute.Value = "CCTraceFile";

                    sourceAttr[0].PrependChild(sorcNode);
                }
            }
            else
            {
                var sorcNode = doc.CreateNode("element", "sources", "");
                sorcNode.InnerXml = innerXML;
                webConfigData.AppendChild(sorcNode);
                isConfigNeedsToAdd = true;
            }
        }

        public static void ChekNAddSourceInConfigServiceModel(XmlDocument doc, XmlElement webConfigData, XmlNodeList sourceAttr, string innerXML, ref bool isConfigNeedsToAdd)
        {
            //  <source name="System.ServiceModel"
            //        switchValue="Information, ActivityTracing"
            //        propagateActivity="true">
            //  <listeners>
            //    <add name="traceListener"
            //        type="System.Diagnostics.XmlWriterTraceListener"
            //         traceOutputOptions="DateTime, Timestamp, ProcessId, ThreadId, Callstack"
            //        initializeData="Traces.svclog"  />
            //  </listeners>
            //</source>

            if (sourceAttr != null && sourceAttr.Count > 0)
            {
                bool isConfigAdded = false;

                foreach (XmlNode item in sourceAttr[0].ChildNodes[0].ChildNodes[0])
                {
                    if (item.Attributes.GetNamedItem("name").Value == "System.ServiceModel")
                    {
                        isConfigAdded = true;
                    }
                }

                if (!isConfigAdded)
                {
                    isConfigNeedsToAdd = true;
                    XmlElement sorcNode = doc.CreateElement("add");

                    XmlAttribute xmlNameAttribute = doc.CreateAttribute("name");
                    xmlNameAttribute.Value = "System.ServiceModel";

                    sourceAttr[0].PrependChild(sorcNode);
                }
            }
            else
            {
                var sorcNode = doc.CreateNode("element", "sources", "");
                sorcNode.InnerXml = innerXML;
                webConfigData.AppendChild(sorcNode);
                isConfigNeedsToAdd = true;
            }
        }

        public static void AddNewSystemDiagnstcs(XmlDocument doc, string innerXml)
        {
            var sorcNode = doc.CreateNode("element", "system.diagnostics", "");
            sorcNode.InnerXml = innerXml;
            doc.LastChild.AppendChild(sorcNode);
        }
        public static void ChekNAddTraceInConfig(XmlDocument doc, XmlElement webConfigData, XmlNodeList traceAttr, string innerXML, ref bool isConfigNeedsToAdd)
        {
            if (traceAttr != null && traceAttr.Count > 0)
            {
                foreach(XmlNode traceIteminConfig in traceAttr)
                {
                    if (traceIteminConfig.ParentNode.Name.ToLower() == "system.diagnostics".ToLower())
                    {
                        if (traceIteminConfig.Attributes.GetNamedItem("autoflush") is null)
                        {
                            XmlAttribute xmlNameAttribute = doc.CreateAttribute("autoflush");
                            xmlNameAttribute.Value = "true";
                            traceIteminConfig.Attributes.Append(xmlNameAttribute);
                            isConfigNeedsToAdd = true;
                        }
                        else if (traceIteminConfig.Attributes.GetNamedItem("autoflush").Value == "false")
                        {
                            traceIteminConfig.Attributes.GetNamedItem("autoflush").Value = "true";
                            isConfigNeedsToAdd = true;
                        }
                    }
                }
            }
            else
            {
                XmlElement sorcNode = doc.CreateElement("trace");

                XmlAttribute xmlNameAttribute = doc.CreateAttribute("autoflush");
                xmlNameAttribute.Value = "true";

                traceAttr[0].PrependChild(sorcNode);
                isConfigNeedsToAdd = true;

            }
        }
    }
}
