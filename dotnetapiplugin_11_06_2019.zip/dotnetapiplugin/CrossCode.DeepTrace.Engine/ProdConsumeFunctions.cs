﻿//-----------------------------------------------------------------------
// <copyright file="ProdConsumeFunctions.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.DeepTrace.Engine
{
    using CrossCode.BLL.Domain;
    using CrossCode.HttpAnalyzer;
    using CrossCode.Integration.Api;
    using CrossCode.Trace.BLL;
    using System;
    using System.Collections.Generic;

    class ProdConsumeFunctions
    {
        public static List<HttpApiPreDTO> GetConsumerHttpApiUrlsFromStartegy(string proFullPath, string processID, string taskTyp)
        {
            try
            {
                //create the backup of config file
                Context context;

                context = new Context(new StrategyByTracing() { TaskType = taskTyp });
                var urlData = context.ContextInterface(proFullPath, processID);

                //prepare the information  and do the mapping in DTO
                var apiConsumerUsage = PluginAPIDTOMapper.CreateAPIClientData(urlData, proFullPath);

                // Fill and find the function key  
                NETPluginInterface.GetAllTheHttpCallingDetails(apiConsumerUsage);
                return apiConsumerUsage;

            }
            catch (Exception ex)
            {
                return new List<HttpApiPreDTO>();
            }
        }

        public static List<HttpProducerUrlsPreDTO> GetProducerHttpApiUrls(string appPath, string TaskType)
        {
            try
            {
                var producerUrls = RESTServerProducerAPI.Program.FetchWeAppServerUrls(appPath, TaskType);

                //Get the Wrapper DTO information to send in CSPlugin Main agent via .NET plugin agent
                var srverPreDTO = PluginAPIDTOMapper.CreateAPIServerData(producerUrls);

                return srverPreDTO;
            }
            catch (Exception ex)
            {
                return new List<HttpProducerUrlsPreDTO>();
            }
        }
    }
}
