﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.DeepTrace.Engine
{
    using CrossCode.BLL.Domain;
    using CrossCode.ByteCode.Helper;
    using CrossCode.WCF.Analyzer;
    using DotNetServiceFactory;
    using System;
    using System.Collections.Generic;
    using System.IO;

    /// <summary>
    /// Put the Stategy pattern here 
    /// </summary>
    public class Program
    {
        // TODO: Change the Name of class and method while changing the assembly executable to DLL library
        private static readonly List<KeyValuePair<string, string>> SnifferData = new List<KeyValuePair<string, string>>();

        public static List<ProcessHttpApiData> ApiData
        {
            get;
            set;
        }
        public static void Main(string[] args)
        {
            //ApiData = GetApiDataExternal(args);
            //var ret = GetAllCommunicationServiceData(args, "WCFOnly");
            ConsumerExtractStartegy.GetConsumerWCFApiFromStartegy(@"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\ChannelFactorySample\bin\Debug\ChannelFactorySample.exe", "12240", "");
            //ConsumerExtractStartegy.GetConsumerWCFApiFromStartegy(@"C:\Users\rajneesh.kumar\source\repos\sampleapp-dotnet\WCF-Consumer-Service-Samples\WCFConsumerSamples\Web\bin\Release\Publish\bin\Web.dll", "17536", "IIS");

        }

        /// <summary>
        ///  It is to fetch all the internet servics like Http,WCF, Web servbice etc.
        ///  // We need to put a factory here and their would be two product 
        ///  1.HttpAnalyzer   2.WCFAnalyzer 3. Web Service Analyzer
        /// </summary>
        /// <param name="args">Required parmater for processing</param>
        /// <param name="option">It is the setting which would drive the required analyzer in service</param>
        /// <returns></returns>
        public static List<ProcessInternetServiceAPIData> GetAllCommunicationServiceData(string[] args, string option)
        {
            //string argument = @"C:\Users\rajneesh.kumar\source\repos\dotnetapiplugin\SampleApp1\obj\x86\Debug\SampleApp1.exe||||1234||||IIS||||option";

            List<ProcessInternetServiceAPIData> processInternetServiceApiDatas = new List<ProcessInternetServiceAPIData>();
            string processLocPath = string.Empty;
            string procID = string.Empty;
            string tskTyp = string.Empty;
            string configOptions = string.Empty;

            foreach (string input in args)
            {
                var inputCollection = input.Split(new string[1] { "||||" }, StringSplitOptions.None);

                if (inputCollection.Length > 1)
                {
                    processLocPath = inputCollection[0];
                    procID = inputCollection[1];
                    tskTyp = string.IsNullOrWhiteSpace(inputCollection[2]) ? string.Empty : inputCollection[2];
                    configOptions = inputCollection[3];

                    ServiceProd servicProd = ServiceProd.None;
                    if (string.IsNullOrWhiteSpace(configOptions))
                    {
                        servicProd = ServiceProd.HTTPOnly;
                    }
                    else
                    {
                        servicProd = (ServiceProd)Enum.Parse(typeof(ServiceProd), configOptions);
                    }


                    if (tskTyp == "IIS")
                    {
                        processLocPath = Path.Combine(processLocPath, "IISProcess.exe");
                       
                    }

                    ServiceFactory factory = new ServiceFactory();
                    var data = factory.GetServiceDependProduct(servicProd, processLocPath, procID, tskTyp);

                    processInternetServiceApiDatas.Add(data);
                }
            }

            return processInternetServiceApiDatas;
        }


        public static List<ProcessHttpApiData> GetApiDataExternal(string[] args)
        {
            // sample argument = C:\Users\ashutosh.singh\source\repos\WebApplicationTest1\WebApplicationTest1\bin\SampleApp1.exe||||1234||||IIS
            List<ProcessHttpApiData> apiDataCollection = new List<ProcessHttpApiData>();

            string processLocPath = string.Empty;
            string procID = string.Empty;
            string tskTyp = string.Empty;

            foreach (string input in args)
            {
                var inputCollection = input.Split(new string[1] { "||||" }, StringSplitOptions.None);

                if (inputCollection.Length > 1)
                {
                    processLocPath = inputCollection[0];
                    procID = inputCollection[1];
                    tskTyp = string.IsNullOrWhiteSpace(inputCollection[2]) ? string.Empty : inputCollection[2];

                    if (tskTyp == "IIS")
                    {
                        processLocPath = Path.Combine(processLocPath, "IISProcess.exe");
                    }

                    ProcessHttpApiData api = new ProcessHttpApiData();
                    api.ConsumerAPIData = ProdConsumeFunctions.GetConsumerHttpApiUrlsFromStartegy(processLocPath, procID, tskTyp);
                    api.ProducerAPIdata = ProdConsumeFunctions.GetProducerHttpApiUrls(processLocPath, tskTyp);

                    apiDataCollection.Add(api);
                }
            }

            return apiDataCollection;
        }

        //public static List<HttpApiPreDTO> GetConsumerHttpApiUrlsFromStartegy(string proFullPath, string processID, string taskTyp)
        //{
        //    try
        //    {
        //        //create the backup of config file
        //        Context context;

        //        context = new Context(new StrategyByTracing() { TaskType = taskTyp } );
        //        var urlData = context.ContextInterface(proFullPath, processID);

        //        //prepare the information  and do the mapping in DTO
        //        var apiConsumerUsage = PluginAPIDTOMapper.CreateAPIClientData(urlData, proFullPath);

        //        // Fill and find the function key  
        //        NETPluginInterface.GetAllTheHttpCallingDetails(apiConsumerUsage);
        //        return apiConsumerUsage;

        //    }
        //    catch (Exception ex)
        //    {
        //        return new List<HttpApiPreDTO>();
        //    }
        //}

        //public static List<HttpProducerUrlsPreDTO> GetProducerHttpApiUrls(string appPath, string TaskType)
        //{
        //    try
        //    {
        //        var producerUrls = RESTServerProducerAPI.Program.FetchWeAppServerUrls(appPath, TaskType);

        //        //Get the Wrapper DTO information to send in CSPlugin Main agent via .NET plugin agent
        //        var srverPreDTO = PluginAPIDTOMapper.CreateAPIServerData(producerUrls);

        //        return srverPreDTO;
        //    }
        //    catch (Exception ex)
        //    {
        //        return new List<HttpProducerUrlsPreDTO>();
        //    }
        //}
    }
}
