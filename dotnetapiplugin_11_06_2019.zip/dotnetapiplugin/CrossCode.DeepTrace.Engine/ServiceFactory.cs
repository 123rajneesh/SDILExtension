﻿//-----------------------------------------------------------------------
// <copyright file="ServiceFactory.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace DotNetServiceFactory
{
    using CrossCode.BLL.Domain;
    using CrossCode.ByteCode.Helper;
    using CrossCode.DeepTrace.Engine;
    using CrossCode.WCF.Analyzer;

    public class ServiceFactory
    {
        public ProcessInternetServiceAPIData GetServiceDependProduct(ServiceProd service, string servicePath, string procID, string taskType)
        {
            ProcessInternetServiceAPIData commServiceData = new ProcessInternetServiceAPIData();

            if (service == ServiceProd.HTTPOnly)
            {
                GetHttpData(servicePath, procID, taskType, commServiceData);
            }
            else if (service == ServiceProd.WCFOnly)
            {
                WCFProdProcessor.GetWCFData(servicePath, commServiceData);
                WCFProdProcessor.GetWCFConsumerData(servicePath, procID, taskType, commServiceData);
            }
            else if (service == ServiceProd.WCF)
            {
                WCFProdProcessor.GetWCFData(servicePath, commServiceData);
            }
            else if (service == ServiceProd.SOAP)
            {
                WCFProdProcessor.GetWCFData(servicePath, commServiceData);
            }
            else if (service == ServiceProd.WebService)
            {

            }
            else if (service == ServiceProd.All)
            {
                GetHttpData(servicePath, procID, taskType, commServiceData);
                WCFProdProcessor.GetWCFData(servicePath, commServiceData);
            }
            else if (service == ServiceProd.HTTPWCF)
            {
                GetHttpData(servicePath, procID, taskType, commServiceData);
                WCFProdProcessor.GetWCFData(servicePath, commServiceData);
            }

            return commServiceData;
        }

        private static void GetHttpData(string servicePath, string procID, string taskType, ProcessInternetServiceAPIData commServiceData)
        {
            commServiceData.HttpAPIData = new ProcessHttpApiData();
            commServiceData.HttpAPIData = GetHttpAPidata(servicePath, procID, taskType);
        }

        private static ProcessHttpApiData GetHttpAPidata(string servicePath, string procID, string taskType)
        {
            ProcessHttpApiData api = new ProcessHttpApiData();
            api.ConsumerAPIData = ProdConsumeFunctions.GetConsumerHttpApiUrlsFromStartegy(servicePath, procID, taskType);
            api.ProducerAPIdata = ProdConsumeFunctions.GetProducerHttpApiUrls(servicePath, taskType);
            return api;
        }
    }
}
