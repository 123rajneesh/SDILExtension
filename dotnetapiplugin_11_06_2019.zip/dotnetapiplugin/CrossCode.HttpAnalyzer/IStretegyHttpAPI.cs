﻿////-----------------------------------------------------------------------
//// <copyright file="IStretegyHttpAPIConsumer.cs" company="CrossCode">
////     Copyright (c) CrossCode Inc. All rights reserved.
//// </copyright>
////-----------------------------------------------------------------------

//namespace CrossCode.HttpAnalyzer
//{
//    public interface IStretegyHttpAPIConsumer<T>
//    {
//        string TaskType { get; set; }
//        T GetHttpConsumptionAlgorithm(string configFullPath, string procID);
//    }
//}
