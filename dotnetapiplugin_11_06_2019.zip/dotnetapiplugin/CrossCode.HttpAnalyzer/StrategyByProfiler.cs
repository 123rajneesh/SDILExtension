﻿//-----------------------------------------------------------------------
// <copyright file="StrategyByProfiler.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.HttpAnalyzer
{
    using CrossCode.Trace.BLL;
    using System;
    using System.Collections.Generic;

    public class StrategyByProfiler : IStretegyHttpAPIConsumer<List<KeyValuePair<string,string>>>
    {
        public string TaskType
        {
            get;
            set;
        }

        public List<KeyValuePair<string, string>> GetHttpConsumptionAlgorithm(string configFullPath, string procID)
        {
            // Not yet implemented but if we need anything from profiling app then 
            // We can get many information from profiler application
            throw new NotImplementedException();
        }
    }
}
