﻿//-----------------------------------------------------------------------
// <copyright file="StrategyByTracing.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.HttpAnalyzer
{
    using CrossCode.ByteCode.Helper;
    using CrossCode.Trace.BLL;
    using System.Collections.Generic;
    using System.Linq;

    public class StrategyByTracing : IStretegyHttpAPIConsumer<List<KeyValuePair<string,string>>>
    {
        private const string configFileNameExtension = ".config";

        public string TaskType
        {
            get;
            set;
        }

        public string ConfigFileNameExtension
        {
            get
            {
                return configFileNameExtension;
            }
        }

        public List<KeyValuePair<string,string>> GetHttpConsumptionAlgorithm(string configFullPath, string procID)
        {
            if (TaskType == "IIS")
            { 
                return new StrategyByTracingAspNet().GetConsumptionByAppType(configFullPath, procID);
            }
            else
            {
                return new StrategyByTracingStandAlone().GetConsumptionByAppType(configFullPath, procID);
            }
        }
        

        protected virtual void FilterDuvplicateUrls(ref List<KeyValuePair<string, string>> httpConsumerData)
        {
            var dupAPI = httpConsumerData.Where(x => x.Key.Contains("#-")).ToList();
            dupAPI.AddRange(httpConsumerData.Where(x => x.Key.Contains("#")).ToList());

            foreach (var item in dupAPI)
            {
                httpConsumerData.Remove(item);
            }

            var distinctList = httpConsumerData.Distinct(new KeyComparer());
           
            httpConsumerData = distinctList.ToList();
        }
    }
}

