﻿//-----------------------------------------------------------------------
// <copyright file="StrategyByTracingAspNet.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.HttpAnalyzer
{
    using CrossCode.ByteCode.Helper;
    using CrossCode.DeepTrace.Engine;
    using RESTAPIConsumerFunct;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    /// <summary>
    /// This class is responsible for handling tracing for Asp.Net application 
    /// </summary>
   public class StrategyByTracingAspNet : StrategyByTracing
    {
        internal List<KeyValuePair<string, string>> GetConsumptionByAppType(string configFullPath, string procID)
        {
            string sourceDir = Path.GetDirectoryName(configFullPath);
            string mainModuleName = Path.GetFileName(configFullPath);

            //First we need to check  whether process is consuming the http api or not.
            List<KeyValuePair<string, string>> httpConsumerData = new List<KeyValuePair<string, string>>();
            string configFilePath = Path.Combine(sourceDir, mainModuleName + ConfigFileNameExtension);
            configFilePath = string.Concat(Path.GetDirectoryName(sourceDir), "\\web.config");

            if (HTTPApiFinderMain.GetHttpCalling(configFullPath, out Dictionary<string, object> data))
            {
                // return httpConsumerData;
                //Add the trace config in application 
                new TraceConfigInjector().AddTraceConfigInApplication(configFilePath);

                //Get the log
                string localLogPath = FileHelper.RecollectTheLogInLocal(Path.GetDirectoryName(sourceDir), procID);

                //interpretate the log
                httpConsumerData = LogDataParser.ParseHttpSniffingDataFromLog(localLogPath);

                // Filter duplicate urls in client side 
                FilterDuvplicateUrls(ref httpConsumerData);
            }

            return httpConsumerData;
        }

        protected override void FilterDuvplicateUrls(ref List<KeyValuePair<string, string>> httpConsumerData)
        {
            var dupAPI = httpConsumerData.Where(x => x.Key.Contains("#-")).ToList();
            dupAPI.AddRange(httpConsumerData.Where(x => x.Key.Contains("#")).ToList());

            foreach (var item in dupAPI)
            {
                string newKey = item.Key.Split(new string[1] { "#" }, StringSplitOptions.None)[0];

                KeyValuePair<string, string> newItem = new KeyValuePair<string, string>(newKey,item.Value);

                httpConsumerData.Add(newItem);

                httpConsumerData.Remove(item);

            }

            //foreach (var item in dupAPI)
            //{
            //    httpConsumerData.Remove(item);
            //}

            var distinctList = httpConsumerData.Distinct(new KeyComparer());

            httpConsumerData = distinctList.ToList();
        }
    }
}
