﻿//-----------------------------------------------------------------------
// <copyright file="StrategyByTracingStandAlone.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.HttpAnalyzer
{
    using CrossCode.ByteCode.Helper;
    using CrossCode.DeepTrace.Engine;
    using CrossCode.Log;
    using RESTAPIConsumerFunct;
    using System.Collections.Generic;
    using System.IO;

    /// <summary>
    /// This class is responsible for handling tracing for standalone application 
    /// </summary>
    public class StrategyByTracingStandAlone : StrategyByTracing
    {

        internal List<KeyValuePair<string, string>> GetConsumptionByAppType(string configFullPath, string procID)
        {
            string sourceDir = Path.GetDirectoryName(configFullPath);
            string mainModuleName = Path.GetFileName(configFullPath);

            //First we need to check  whether process is consuming the http api or not.
            List<KeyValuePair<string, string>> httpConsumerData = new List<KeyValuePair<string, string>>();

            if (HTTPApiFinderMain.GetHttpCalling(Path.Combine(sourceDir, mainModuleName + ConfigFileNameExtension), out Dictionary<string, object> data))
            {
                //Add the trace config in application 
                AppLog.Debug("AddTraceConfigInApplication = {0}", configFullPath);

                IConfigInjector configInject = new TraceConfigInjector();
                configInject.AddTraceConfigInApplication(Path.Combine(sourceDir, mainModuleName + base.ConfigFileNameExtension));

                //Get the log
                AppLog.Debug("RecollectTheLogInLocal = {0}", configFullPath);
                string localLogPath = FileHelper.RecollectTheLogInLocal(sourceDir, procID);

                //interpretate the log
                AppLog.Debug("ParseHttpSniffingDataFromLog = {0}", configFullPath);
                httpConsumerData = LogDataParser.ParseHttpSniffingDataFromLog(localLogPath);

                // Filter duplicate urls in client side 
                AppLog.Debug("FilterDuvplicateUrls = {0}", configFullPath);
                FilterDuvplicateUrls(ref httpConsumerData);
            }

            return httpConsumerData;
        }
    }
}
