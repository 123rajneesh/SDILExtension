﻿//-----------------------------------------------------------------------
// <copyright file="PluginAPIDTOMapper.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.Integration.Api
{
    using CrossCode.BLL.Domain;
    using System;
    using System.Collections.Generic;

    public class PluginAPIDTOMapper
    {
        private const string MethoNameWithSign = "MethodNameWithSign";
        private const string NameSpaceName = "NameSpaceName";
        private const string ClassName = "NameSpaceName";
        private const string ApiUrl = "URL";

        public static List<HttpApiPreDTO> CreateAPIClientData(List<KeyValuePair<string, string>> apiConsumerData, string processNameWthFullPatg)
        {
            List<HttpApiPreDTO> apiDTO = new List<HttpApiPreDTO>();

            //prepare the pre-DTO object  with the consumer http information
            foreach (var item in apiConsumerData)
            {
                HttpApiPreDTO singleApi = new HttpApiPreDTO();

                string[] breakDownDetails = item.Value.Split(new string[1] { "." }, StringSplitOptions.None);

                if (breakDownDetails != null && breakDownDetails.Length >= 2)
                {
                    if (!string.IsNullOrWhiteSpace(breakDownDetails[breakDownDetails.Length - 1]))
                    {
                        singleApi.MethodNameWithSigntr = breakDownDetails[breakDownDetails.Length - 1];
                        singleApi.FunctionName = ExtractFunctWithParmName(breakDownDetails[breakDownDetails.Length - 1]);
                    }

                    if (!string.IsNullOrWhiteSpace(breakDownDetails[breakDownDetails.Length - 2]))
                    {
                        singleApi.ClassName = breakDownDetails[breakDownDetails.Length - 2];
                    }

                    if (breakDownDetails.Length > 2 && !string.IsNullOrWhiteSpace(breakDownDetails[breakDownDetails.Length - 3]))
                    {
                        string nameSpaceName = string.Empty;

                        for (int i = 3; i <= breakDownDetails.Length; i++)
                        {
                            if (nameSpaceName == string.Empty)
                            {
                                nameSpaceName = breakDownDetails[breakDownDetails.Length - i];
                            }
                            else
                            {
                                nameSpaceName = breakDownDetails[breakDownDetails.Length - i] + "." + nameSpaceName;
                            }


                        }
                        singleApi.NameSpaceName = nameSpaceName;
                    }

                }

                singleApi.Url = item.Key;
                singleApi.ProcessNameWithPath = processNameWthFullPatg;
                apiDTO.Add(singleApi);
            }

            return apiDTO;
        }

        public static List<WCFServiceConsumerPreDTO> CreateAPIClientData(List<KeyValuePair<string, string>> apiConsumerData, string processNameWthFullPatg, string key)
        {
            List<WCFServiceConsumerPreDTO> apiDTO = new List<WCFServiceConsumerPreDTO>();

            //prepare the pre-DTO object  with the consumer http information
            foreach (var item in apiConsumerData)
            {
                if (item.Key == key)
                {

                    WCFServiceConsumerPreDTO singleApi = new WCFServiceConsumerPreDTO();
                    string[] breakDownDetails = item.Value.Split(new string[1] { "." }, StringSplitOptions.None);
                    if (breakDownDetails != null && breakDownDetails.Length >= 2)
                    {
                        if (!string.IsNullOrWhiteSpace(breakDownDetails[breakDownDetails.Length - 1]))
                        {
                            singleApi.MethodNameWithSigntr = breakDownDetails[breakDownDetails.Length - 1];
                            singleApi.FunctionName = ExtractFunctWithParmName(breakDownDetails[breakDownDetails.Length - 1]);
                        }

                        if (!string.IsNullOrWhiteSpace(breakDownDetails[breakDownDetails.Length - 2]))
                        {
                            singleApi.ClassName = breakDownDetails[breakDownDetails.Length - 2];
                        }

                        if (breakDownDetails.Length > 2 && !string.IsNullOrWhiteSpace(breakDownDetails[breakDownDetails.Length - 3]))
                        {
                            string nameSpaceName = string.Empty;

                            for (int i = 3; i <= breakDownDetails.Length; i++)
                            {
                                if (nameSpaceName == string.Empty)
                                {
                                    nameSpaceName = breakDownDetails[breakDownDetails.Length - i];
                                }
                                else
                                {
                                    nameSpaceName = breakDownDetails[breakDownDetails.Length - i] + "." + nameSpaceName;
                                }


                            }
                            singleApi.NameSpaceName = nameSpaceName;
                        }

                    }
                    FillApiDTO(apiConsumerData, ref singleApi);

                    singleApi.ProcessNameWithPath = processNameWthFullPatg;
                    apiDTO.Add(singleApi);
                }
            }
            return apiDTO;
        }

        private static void FillApiDTO(List<KeyValuePair<string, string>> apiConsumerData, ref WCFServiceConsumerPreDTO wcfserviceconsumerpredto)
        {
            foreach (var item in apiConsumerData)
            {
                if (item.Key == "Address")
                {
                    wcfserviceconsumerpredto.Address = item.Value;
                }
                else if (item.Key == "Contract")
                {
                    wcfserviceconsumerpredto.Contract = item.Value;
                }
                else if (item.Key == "Binding")
                {
                    wcfserviceconsumerpredto.Binding = item.Value;
                }
            }
        }

        private static string ExtractFunctWithParmName(string value)
        {
            //// example function name - Main(String[] args) -value = "Main(String[] args, String[] args)";

            var splitMthWithParam = value.Split(new string[2] { "(", ")" }, StringSplitOptions.None);
            List<string> paramWithoutName = new List<string>();

            if (splitMthWithParam.Length >= 2 && !string.IsNullOrWhiteSpace(splitMthWithParam[1]))
            {
                var param = splitMthWithParam[1].Split(new string[1] { "," }, StringSplitOptions.None);

                foreach (string str in param)
                {
                    string tempStr = str.StartsWith(" ") ? str.Remove(0, 1) : str;
                    paramWithoutName.Add(tempStr.Split(new string[] { " " }, StringSplitOptions.None)[0]);
                }
            }

            string methdNamewithSign = string.Format("{0}{1}{2}{3}", splitMthWithParam[0], "(", string.Join(", ", paramWithoutName), ")");
            return methdNamewithSign;
        }

        public static List<HttpProducerUrlsPreDTO> CreateAPIServerData(Dictionary<string, string> serverUrlsData)
        {
            List<HttpProducerUrlsPreDTO> httpProducerUrlsPreDTOs = new List<HttpProducerUrlsPreDTO>();

            foreach (KeyValuePair<string, string> url in serverUrlsData)
            {
                HttpProducerUrlsPreDTO serverDTO = new HttpProducerUrlsPreDTO
                {
                    FunctionKey = url.Key,
                    Urls = new List<string>
                {
                    url.Value
                }
                };

                httpProducerUrlsPreDTOs.Add(serverDTO);
            }

            return httpProducerUrlsPreDTOs;
        }
    }
}
