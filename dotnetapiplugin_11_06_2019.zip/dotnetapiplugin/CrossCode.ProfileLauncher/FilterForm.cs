﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;

namespace CrossCode.ProfileLauncher
{
    internal class HandleInfo
    {
        internal HandleInfo(int allocThreadId, ulong handleId, ulong initialObjectId, int allocTickIndex, int allocStacktraceId)
        {
            this.allocThreadId = allocThreadId;
            this.handleId = handleId;
            this.initialObjectId = initialObjectId;
            this.allocTickIndex = allocTickIndex;
            this.allocStacktraceId = allocStacktraceId;
        }

        internal int allocThreadId;
        internal ulong handleId;
        internal ulong initialObjectId;
        internal int allocTickIndex;
        internal int allocStacktraceId;
    };

    internal class FunctionList
    {
        internal class FunctionDescriptor
        {
            internal FunctionDescriptor(int functionId, int funcCallStack, uint funcSize, int funcModule)
            {
                this.functionId = functionId;
                this.funcCallStack = funcCallStack;
                this.funcSize = funcSize;
                this.funcModule = funcModule;
            }

            internal int functionId;
            internal int funcCallStack;
            internal uint funcSize;
            internal int funcModule;
        }

        ReadNewLog readNewLog;
        ArrayList functionList;

        internal FunctionList(ReadNewLog readNewLog)
        {
            this.readNewLog = readNewLog;
            this.functionList = new ArrayList();
        }

        internal void Add(int functionId, int funcCallStack, uint funcSize, int funcModule)
        {
            functionList.Add(new FunctionDescriptor(functionId, funcCallStack, funcSize, funcModule));
        }

        internal bool Empty
        {
            get
            {
                return functionList.Count == 0;
            }
        }

        void BuildFuncVertices(Graph graph, ref Vertex[] funcVertex, FilterForm filterForm)
        {
            for (int i = 0; i < readNewLog.funcName.Length; i++)
            {
                string name = readNewLog.funcName[i];
                string signature = readNewLog.funcSignature[i];
                if (name != null && signature != null)
                    readNewLog.AddFunctionVertex(i, name, signature, graph, ref funcVertex, filterForm);
            }
        }

        int BuildVertexStack(int stackTraceIndex, Vertex[] funcVertex, ref Vertex[] vertexStack, int skipCount)
        {
            int[] stackTrace = readNewLog.stacktraceTable.IndexToStacktrace(stackTraceIndex);

            while (vertexStack.Length < stackTrace.Length + 1)
                vertexStack = new Vertex[vertexStack.Length * 2];

            for (int i = skipCount; i < stackTrace.Length; i++)
                vertexStack[i - skipCount] = funcVertex[stackTrace[i]];

            return stackTrace.Length - skipCount;
        }

        void BuildFunctionTrace(Graph graph, int stackTraceIndex, int funcIndex, ulong size, Vertex[] funcVertex, ref Vertex[] vertexStack, FilterForm filterForm)
        {
            int stackPtr = BuildVertexStack(stackTraceIndex, funcVertex, ref vertexStack, 0);

            Vertex toVertex = graph.TopVertex;
            Vertex fromVertex;
            Edge edge;
            if ((funcVertex[funcIndex].interestLevel & InterestLevel.Interesting) == InterestLevel.Interesting
                && ReadNewLog.InterestingCallStack(vertexStack, stackPtr, filterForm))
            {
                vertexStack[stackPtr] = funcVertex[funcIndex];
                stackPtr++;
                stackPtr = ReadNewLog.FilterVertices(vertexStack, stackPtr);
                stackPtr = Vertex.SqueezeOutRepetitions(vertexStack, stackPtr);
                for (int i = 0; i < stackPtr; i++)
                {
                    fromVertex = toVertex;
                    toVertex = vertexStack[i];
                    edge = graph.FindOrCreateEdge(fromVertex, toVertex);
                    edge.AddWeight(size);
                }
                fromVertex = toVertex;
                toVertex = graph.BottomVertex;
                edge = graph.FindOrCreateEdge(fromVertex, toVertex);
                edge.AddWeight(size);
            }
        }

        internal Graph BuildFunctionGraph(FilterForm filterForm)
        {
            Vertex[] funcVertex = new Vertex[1];
            Vertex[] vertexStack = new Vertex[1];

            Graph graph = new Graph(this);
            graph.graphType = Graph.GraphType.FunctionGraph;

            BuildFuncVertices(graph, ref funcVertex, filterForm);

            foreach (FunctionDescriptor fd in functionList)
            {
                BuildFunctionTrace(graph, fd.funcCallStack, fd.functionId, fd.funcSize, funcVertex, ref vertexStack, filterForm);
            }

            foreach (Vertex v in graph.vertices.Values)
                v.active = true;
            graph.BottomVertex.active = false;

            return graph;
        }

        void BuildModVertices(Graph graph, ref Vertex[] modVertex, FilterForm filterForm)
        {
            for (int i = 0; i < readNewLog.modBasicName.Length; i++)
            {
                string basicName = readNewLog.modBasicName[i];
                string fullName = readNewLog.modFullName[i];
                if (basicName != null && fullName != null)
                {
                    readNewLog.AddFunctionVertex(i, basicName, fullName, graph, ref modVertex, filterForm);
                    modVertex[i].basicName = basicName;
                    modVertex[i].basicSignature = fullName;
                }
            }
        }

        int FunctionsInSameModule(int modIndex, int stackTraceIndex)
        {
            int[] stackTrace = readNewLog.stacktraceTable.IndexToStacktrace(stackTraceIndex);
            int result = 0;
            for (int i = stackTrace.Length - 1; i >= 0; i--)
            {
                int funcIndex = stackTrace[i];
                if (readNewLog.funcModule[funcIndex] == modIndex)
                    result++;
                else
                    break;
            }
            return result;
        }

        void BuildModuleTrace(Graph graph, int stackTraceIndex, int modIndex, ulong size, Vertex[] funcVertex, Vertex[] modVertex, ref Vertex[] vertexStack, FilterForm filterForm)
        {
            int functionsToSkip = FunctionsInSameModule(modIndex, stackTraceIndex);
            int stackPtr = BuildVertexStack(stackTraceIndex, funcVertex, ref vertexStack, 0) - functionsToSkip;

            Vertex toVertex = graph.TopVertex;
            Vertex fromVertex;
            Edge edge;
            if (ReadNewLog.InterestingCallStack(vertexStack, stackPtr, filterForm))
            {
                vertexStack[stackPtr] = modVertex[modIndex];
                stackPtr++;
                stackPtr = ReadNewLog.FilterVertices(vertexStack, stackPtr);
                stackPtr = Vertex.SqueezeOutRepetitions(vertexStack, stackPtr);
                for (int i = 0; i < stackPtr; i++)
                {
                    fromVertex = toVertex;
                    toVertex = vertexStack[i];
                    edge = graph.FindOrCreateEdge(fromVertex, toVertex);
                    edge.AddWeight(size);
                }
                fromVertex = toVertex;
                toVertex = graph.BottomVertex;
                edge = graph.FindOrCreateEdge(fromVertex, toVertex);
                edge.AddWeight(size);
            }
        }

        internal Graph BuildModuleGraph(FilterForm filterForm)
        {
            Vertex[] funcVertex = new Vertex[1];
            Vertex[] vertexStack = new Vertex[1];
            Vertex[] modVertex = new Vertex[1];

            Graph graph = new Graph(this);
            graph.graphType = Graph.GraphType.ModuleGraph;

            BuildFuncVertices(graph, ref funcVertex, filterForm);
            BuildModVertices(graph, ref modVertex, filterForm);

            foreach (FunctionDescriptor fd in functionList)
            {
                BuildModuleTrace(graph, fd.funcCallStack, fd.funcModule, fd.funcSize, funcVertex, modVertex, ref vertexStack, filterForm);
            }

            foreach (Vertex v in graph.vertices.Values)
                v.active = true;
            graph.BottomVertex.active = false;

            return graph;
        }

        string ClassNameOfFunc(int funcIndex)
        {
            string funcName = readNewLog.funcName[funcIndex];
            int colonColonIndex = funcName.IndexOf("::");
            if (colonColonIndex > 0)
                return funcName.Substring(0, colonColonIndex);
            else
                return funcName;
        }

        int FunctionsInSameClass(string className, int stackTraceIndex)
        {
            int[] stackTrace = readNewLog.stacktraceTable.IndexToStacktrace(stackTraceIndex);
            int result = 0;
            for (int i = stackTrace.Length - 1; i >= 0; i--)
            {
                int funcIndex = stackTrace[i];
                if (ClassNameOfFunc(funcIndex) == className)
                    result++;
                else
                    break;
            }
            return result;
        }

        void BuildClassTrace(Graph graph, int stackTraceIndex, int funcIndex, ulong size, Vertex[] funcVertex, ref Vertex[] vertexStack, FilterForm filterForm)
        {
            string className = ClassNameOfFunc(funcIndex);
            int functionsToSkip = FunctionsInSameClass(className, stackTraceIndex);
            int stackPtr = BuildVertexStack(stackTraceIndex, funcVertex, ref vertexStack, 0) - functionsToSkip;

            Vertex toVertex = graph.TopVertex;
            Vertex fromVertex;
            Edge edge;
            if (ReadNewLog.InterestingCallStack(vertexStack, stackPtr, filterForm))
            {
                vertexStack[stackPtr] = graph.FindOrCreateVertex(className, null, null);
                vertexStack[stackPtr].interestLevel = filterForm.IsInterestingMethodName(className, null)
                    ? InterestLevel.Interesting | filterForm.InterestLevelForParentsAndChildren() : InterestLevel.Ignore;

                stackPtr++;
                stackPtr = ReadNewLog.FilterVertices(vertexStack, stackPtr);
                stackPtr = Vertex.SqueezeOutRepetitions(vertexStack, stackPtr);
                for (int i = 0; i < stackPtr; i++)
                {
                    fromVertex = toVertex;
                    toVertex = vertexStack[i];
                    edge = graph.FindOrCreateEdge(fromVertex, toVertex);
                    edge.AddWeight(size);
                }
                if (toVertex != graph.TopVertex)
                {
                    fromVertex = toVertex;
                    toVertex = graph.BottomVertex;
                    edge = graph.FindOrCreateEdge(fromVertex, toVertex);
                    edge.AddWeight(size);
                }
            }
        }

        internal Graph BuildClassGraph(FilterForm filterForm)
        {
            Vertex[] funcVertex = new Vertex[1];
            Vertex[] vertexStack = new Vertex[1];

            Graph graph = new Graph(this);
            graph.graphType = Graph.GraphType.ClassGraph;

            BuildFuncVertices(graph, ref funcVertex, filterForm);

            foreach (FunctionDescriptor fd in functionList)
            {
                BuildClassTrace(graph, fd.funcCallStack, fd.functionId, fd.funcSize, funcVertex, ref vertexStack, filterForm);
            }

            foreach (Vertex v in graph.vertices.Values)
                v.active = true;
            graph.BottomVertex.active = false;

            return graph;
        }

        internal void ReportCallCountSizes(Histogram callstackHistogram)
        {
            uint[] callCount = new uint[readNewLog.funcName.Length];
            callstackHistogram.CalculateCallCounts(callCount);
            Console.WriteLine("{0},{1},{2} {3}", "# Calls", "Function Size", "Function Name", "Function Signature");
            foreach (FunctionDescriptor fd in functionList)
            {
                Console.WriteLine("{0},{1},{2} {3}", callCount[fd.functionId], fd.funcSize, readNewLog.funcName[fd.functionId], readNewLog.funcSignature[fd.functionId]);
            }
        }
    }
    internal class SampleObjectTable
    {
        internal class SampleObject
        {
            internal int typeIndex;
            internal int changeTickIndex;
            internal int origAllocTickIndex;
            internal SampleObject prev;

            internal SampleObject(int typeIndex, int changeTickIndex, int origAllocTickIndex, SampleObject prev)
            {
                this.typeIndex = typeIndex;
                this.changeTickIndex = changeTickIndex;
                this.origAllocTickIndex = origAllocTickIndex;
                this.prev = prev;
            }
        }

        internal SampleObject[][] masterTable;
        internal ReadNewLog readNewLog;

        internal const int firstLevelShift = 25;
        internal const int initialFirstLevelLength = 1 << (31 - firstLevelShift); // covering 2 GB of address space
        internal const int secondLevelShift = 10;
        internal const int secondLevelLength = 1 << (firstLevelShift - secondLevelShift);
        internal const int sampleGrain = 1 << secondLevelShift;
        internal int lastTickIndex;
        internal SampleObject gcTickList;

        void GrowMasterTable()
        {
            SampleObject[][] newMasterTable = new SampleObject[masterTable.Length * 2][];
            for (int i = 0; i < masterTable.Length; i++)
                newMasterTable[i] = masterTable[i];
            masterTable = newMasterTable;
        }

        internal SampleObjectTable(ReadNewLog readNewLog)
        {
            masterTable = new SampleObject[initialFirstLevelLength][];
            this.readNewLog = readNewLog;
            lastTickIndex = 0;
            gcTickList = null;
        }

        bool IsGoodSample(ulong start, ulong end)
        {
            // We want it as a sample if and only if it crosses a boundary
            return (start >> secondLevelShift) != (end >> secondLevelShift);
        }

        internal void RecordChange(ulong start, ulong end, int changeTickIndex, int origAllocTickIndex, int typeIndex)
        {
            lastTickIndex = changeTickIndex;
            for (ulong id = start; id < end; id += sampleGrain)
            {
                uint index = (uint)(id >> firstLevelShift);
                while (masterTable.Length <= index)
                    GrowMasterTable();
                SampleObject[] so = masterTable[index];
                if (so == null)
                {
                    so = new SampleObject[secondLevelLength];
                    masterTable[index] = so;
                }
                index = (uint)((id >> secondLevelShift) & (secondLevelLength - 1));
                Debug.Assert(so[index] == null || so[index].changeTickIndex <= changeTickIndex);
                SampleObject prev = so[index];
                if (prev != null && prev.typeIndex == typeIndex && prev.origAllocTickIndex == origAllocTickIndex)
                {
                    // no real change - can happen when loading files where allocation profiling was off
                    // to conserve memory, don't allocate a new sample object in this case
                }
                else
                {
                    so[index] = new SampleObject(typeIndex, changeTickIndex, origAllocTickIndex, prev);
                }
            }
        }

        internal void Insert(ulong start, ulong end, int changeTickIndex, int origAllocTickIndex, int typeIndex)
        {
            if (IsGoodSample(start, end))
                RecordChange(start, end, changeTickIndex, origAllocTickIndex, typeIndex);
        }

        internal void Delete(ulong start, ulong end, int changeTickIndex)
        {
            if (IsGoodSample(start, end))
                RecordChange(start, end, changeTickIndex, 0, 0);
        }

        internal void AddGcTick(int tickIndex, int gen)
        {
            lastTickIndex = tickIndex;

            gcTickList = new SampleObject(gen, tickIndex, 0, gcTickList);
        }

        internal void RecordComment(int tickIndex, int commentIndex)
        {
            lastTickIndex = tickIndex;
        }
    }
    internal class LiveObjectTable
    {
        internal struct LiveObject
        {
            internal ulong id;
            internal uint size;
            internal int typeIndex;
            internal int typeSizeStacktraceIndex;
            internal int allocTickIndex;
        }

        class IntervalTable
        {
            class Interval
            {
                internal ulong loAddr;
                internal ulong hiAddr;
                internal int generation;
                internal Interval next;
                internal bool hadRelocations;
                internal bool justHadGc;

                internal Interval(ulong loAddr, ulong hiAddr, int generation, Interval next)
                {
                    this.loAddr = loAddr;
                    this.hiAddr = hiAddr;
                    this.generation = generation;
                    this.next = next;
                }
            }

            const int allowableGap = 1024*1024;

            Interval liveRoot;
            Interval newLiveRoot;
            Interval updateRoot;
            bool nullRelocationsSeen;

            LiveObjectTable liveObjectTable;

            internal IntervalTable(LiveObjectTable liveObjectTable)
            {
                liveRoot = null;
                this.liveObjectTable = liveObjectTable;
            }

            private Interval OverlappingInterval(Interval i)
            {
                for (Interval ii = liveRoot; ii != null; ii = ii.next)
                {
                    if (ii != i)
                    {
                        if (ii.hiAddr > i.loAddr && ii.loAddr < i.hiAddr)
                            return ii;
                    }
                }
                return null;
            }

            private void DeleteInterval(Interval i)
            {   
                Interval prevInterval = null;
                for (Interval ii = liveRoot; ii != null; ii = ii.next)
                {
                    if (ii == i)
                    {
                        if (prevInterval != null)
                            prevInterval.next = ii.next;
                        else
                            liveRoot = ii.next;
                        break;
                    }
                    prevInterval = ii;
                }
            }

            private void MergeInterval(Interval i)
            {
                Interval overlappingInterval = OverlappingInterval(i);
                i.loAddr = Math.Min(i.loAddr, overlappingInterval.loAddr);
                i.hiAddr = Math.Max(i.hiAddr, overlappingInterval.hiAddr);
                DeleteInterval(overlappingInterval);
            }

            internal bool AddObject(ulong id, uint size, int allocTickIndex, SampleObjectTable sampleObjectTable)
            {
                size = (size + 3) & (uint.MaxValue - 3);
                Interval prevInterval = null;
                Interval bestInterval = null;
                Interval prevI = null;
                bool emptySpace = false;
                // look for the best interval to put this object in.
                for (Interval i = liveRoot; i != null; i = i.next)
                {
                    if (i.loAddr < id + size && id <= i.hiAddr + allowableGap)
                    {
                        if (bestInterval == null || bestInterval.loAddr < i.loAddr)
                        {
                            bestInterval = i;
                            prevInterval = prevI;
                        }
                    }
                    prevI = i;
                }
                if (bestInterval != null)
                {
                    if (bestInterval.loAddr > id)
                    {
                        bestInterval.loAddr = id;
                    }
                    if (id < bestInterval.hiAddr)
                    {
                        if (bestInterval.hadRelocations && bestInterval.justHadGc)
                        {
                            // Interval gets shortened
                            liveObjectTable.RemoveObjectRange(id, bestInterval.hiAddr - id, allocTickIndex, sampleObjectTable);
                            bestInterval.hiAddr = id + size;
                            bestInterval.justHadGc = false;
                        }
                    }
                    else
                    {
                        bestInterval.hiAddr = id + size;
                        emptySpace = true;
                    }                   
                    if (prevInterval != null)
                    {
                        // Move to front to speed up future searches.
                        prevInterval.next = bestInterval.next;
                        bestInterval.next = liveRoot;
                        liveRoot = bestInterval;
                    }
                    if (OverlappingInterval(bestInterval) != null)
                        MergeInterval(bestInterval);
                    return emptySpace;
                }
                liveRoot = new Interval(id, id + size, -1, liveRoot);
                Debug.Assert(OverlappingInterval(liveRoot) == null);
                return emptySpace;
            }

            internal void GenerationInterval(ulong rangeStart, ulong rangeLength, int generation)
            {
                newLiveRoot = new Interval(rangeStart, rangeStart + rangeLength, generation, newLiveRoot);
            }

            internal int GenerationOfObject(ulong id)
            {
                Interval prev = null;
                for (Interval i = liveRoot; i != null; i = i.next)
                {
                    if (i.loAddr <= id && id < i.hiAddr)
                    {
                        if (prev != null)
                        {
                            // Move to front to speed up future searches.
                            prev.next = i.next;
                            i.next = liveRoot;
                            liveRoot = i;
                        }
                        return i.generation;
                    }
                    prev = i;
                }
                return -1;
            }

            internal void Preserve(ulong id, ulong length)
            {
                if (updateRoot != null && updateRoot.hiAddr == id)
                    updateRoot.hiAddr = id + length;
                else
                    updateRoot = new Interval(id, id + length, -1, updateRoot);
            }

            internal void Relocate(ulong oldId, ulong newId, uint length)
            {
                if (oldId == newId)
                    nullRelocationsSeen = true;

                if (updateRoot != null && updateRoot.hiAddr == newId)
                    updateRoot.hiAddr = newId + length;
                else
                    updateRoot = new Interval(newId, newId + length, -1, updateRoot);

                for (Interval i = liveRoot; i != null; i = i.next)
                {
                    if (i.loAddr <= oldId && oldId < i.hiAddr)
                        i.hadRelocations = true;
                }
                Interval bestInterval = null;
                for (Interval i = liveRoot; i != null; i = i.next)
                {
                    if (i.loAddr <= newId + length && newId <= i.hiAddr + allowableGap)
                    {
                        if (bestInterval == null || bestInterval.loAddr < i.loAddr)
                            bestInterval = i;
                    }
                }
                if (bestInterval != null)
                {
                    if (bestInterval.hiAddr < newId + length)
                        bestInterval.hiAddr = newId + length;
                    if (bestInterval.loAddr > newId)
                        bestInterval.loAddr = newId;
                    if (OverlappingInterval(bestInterval) != null)
                        MergeInterval(bestInterval);
                }
                else
                {
                    liveRoot = new Interval(newId, newId + length, -1, liveRoot);
                    Debug.Assert(OverlappingInterval(liveRoot) == null);
                }
            }

            private Interval SortIntervals(Interval root)
            {
                // using insertion sort for now...
                Interval next;
                Interval newRoot = null;
                for (Interval i = root; i != null; i = next)
                {
                    next = i.next;
                    Interval prev = null;
                    Interval ii;
                    for (ii = newRoot; ii != null; ii = ii.next)
                    {
                        if (i.loAddr < ii.loAddr)
                            break;
                        prev = ii;
                    }
                    if (prev == null)
                    {
                        i.next = newRoot;
                        newRoot = i;
                    }
                    else
                    {
                        i.next = ii;
                        prev.next = i;
                    }
                }
                return newRoot;
            }

            private void RemoveRange(ulong loAddr, ulong hiAddr, int tickIndex, SampleObjectTable sampleObjectTable)
            {
                Interval next;
                for (Interval i = liveRoot; i != null; i = next)
                {
                    next = i.next;
                    ulong lo = Math.Max(loAddr, i.loAddr);
                    ulong hi = Math.Min(hiAddr, i.hiAddr);
                    if (lo >= hi)
                        continue;
                    liveObjectTable.RemoveObjectRange(lo, hi - lo, tickIndex, sampleObjectTable);
                    if (i.hiAddr == hi)
                    {
                        if (i.loAddr == lo)
                            DeleteInterval(i);
                        else
                            i.hiAddr = lo;
                    }
                }
            }

            internal void RecordGc(int tickIndex, SampleObjectTable sampleObjectTable, bool simpleForm)
            {
                if (simpleForm && nullRelocationsSeen || newLiveRoot != null)
                {
                    // in this case assume anything not reported is dead
                    updateRoot = SortIntervals(updateRoot);
                    ulong prevHiAddr = 0;
                    for (Interval i = updateRoot; i != null; i = i.next)
                    {
                        if (prevHiAddr < i.loAddr)
                        {
                            RemoveRange(prevHiAddr, i.loAddr, tickIndex, sampleObjectTable);
                        }
                        if (prevHiAddr < i.hiAddr)
                            prevHiAddr = i.hiAddr;
                    }
                    RemoveRange(prevHiAddr, ulong.MaxValue, tickIndex, sampleObjectTable);
                    updateRoot = null;
                    if (newLiveRoot != null)
                    {
                        liveRoot = newLiveRoot;
                        newLiveRoot = null;
                    }
                }
                else
                {
                    for (Interval i = liveRoot; i != null; i = i.next)
                        i.justHadGc = true;
                }
                nullRelocationsSeen = false;
            }
        }

        IntervalTable intervalTable;
        internal ReadNewLog readNewLog;
        internal int lastTickIndex;
        private long lastPos;

        const int alignShift = 2;
        const int firstLevelShift = 20;
        const int initialFirstLevelLength = 1 << (31 - alignShift - firstLevelShift);  // covering 2 GB of address space
        const int secondLevelLength = 1<<firstLevelShift;
        const int secondLevelMask = secondLevelLength-1;

        ushort[][] firstLevelTable;

        void GrowFirstLevelTable()
        {
            ushort[][] newFirstLevelTable = new ushort[firstLevelTable.Length*2][];
            for (int i = 0; i < firstLevelTable.Length; i++)
                newFirstLevelTable[i] = firstLevelTable[i];
            firstLevelTable = newFirstLevelTable;
        }

        internal LiveObjectTable(ReadNewLog readNewLog)
        {
            firstLevelTable = new ushort[initialFirstLevelLength][];
            intervalTable = new IntervalTable(this);
            this.readNewLog = readNewLog;
            lastGcGen0Count = 0;
            lastGcGen1Count = 0;
            lastGcGen2Count = 0;
            lastTickIndex = 0;
            lastPos = 0;
        }

        internal ulong FindObjectBackward(ulong id)
        {
            id >>= alignShift;
            uint i = (uint)(id >> firstLevelShift);
            uint j = (uint)(id & secondLevelMask);
            if (i >= firstLevelTable.Length)
            {
                i = (uint)(firstLevelTable.Length - 1);
                j = (uint)(secondLevelLength - 1);
            }
            while (i != uint.MaxValue)
            {
                ushort[] secondLevelTable = firstLevelTable[i];
                if (secondLevelTable != null)
                {
                    while (j != uint.MaxValue)
                    {
                        if ((secondLevelTable[j] & 0x8000) != 0)
                            break;
                        j--;
                    }
                    if (j != uint.MaxValue)
                        break;
                }
                j = secondLevelLength - 1;
                i--;
            }
            if (i == uint.MaxValue)
                return 0;
            else
                return (((ulong)i<<firstLevelShift) + j) << alignShift;
        }

        ulong FindObjectForward(ulong startId, ulong endId)
        {
            startId >>= alignShift;
            endId >>= alignShift;
            uint i = (uint)(startId >> firstLevelShift);
            uint iEnd = (uint)(endId >> firstLevelShift);
            uint j = (uint)(startId & secondLevelMask);
            uint jEnd = (uint)(endId & secondLevelMask);
            if (iEnd >= firstLevelTable.Length)
            {
                iEnd = (uint)(firstLevelTable.Length - 1);
                jEnd = (uint)(secondLevelLength - 1);
            }
            while (i <= iEnd)
            {
                ushort[] secondLevelTable = firstLevelTable[i];
                if (secondLevelTable != null)
                {
                    while (j < secondLevelLength && (j <= jEnd || i < iEnd))
                    {
                        if ((secondLevelTable[j] & 0x8000) != 0)
                            break;
                        j++;
                    }
                    if (j < secondLevelLength)
                        break;
                }
                j = 0;
                i++;
            }
            if (i > iEnd || (i == iEnd && j > jEnd))
                return ulong.MaxValue;
            else
                return (((ulong)i<<firstLevelShift) + j) << alignShift;
        }

        internal void GetNextObject(ulong startId, ulong endId, out LiveObject o)
        {
            ulong id = FindObjectForward(startId, endId);
            o.id = id;
            id >>= alignShift;
            uint i = (uint)(id >> firstLevelShift);
            uint j = (uint)(id & secondLevelMask);
            ushort[] secondLevelTable = null;
            if (i < firstLevelTable.Length)
                secondLevelTable = firstLevelTable[i];
            if (secondLevelTable != null)
            {
                ushort u1 = secondLevelTable[j];
                if ((u1 & 0x8000) != 0)
                {
                    j++;
                    if (j >= secondLevelLength)
                    {
                        j = 0;
                        i++;
                        secondLevelTable = firstLevelTable[i];
                    }
                    ushort u2 = secondLevelTable[j];
                    j++;
                    if (j >= secondLevelLength)
                    {
                        j = 0;
                        i++;
                        secondLevelTable = firstLevelTable[i];
                    }
                    ushort u3 = secondLevelTable[j];

                    o.allocTickIndex = (u2 >> 7) + (u3 << 8);

                    o.typeSizeStacktraceIndex = (u1 & 0x7fff) + ((u2 & 0x7f) << 15);

                    int[] stacktrace = readNewLog.stacktraceTable.IndexToStacktrace(o.typeSizeStacktraceIndex);

                    o.typeIndex = stacktrace[0];
                    o.size = (uint)stacktrace[1];

                    return;
                }
            }
            o.size = 0;
            o.allocTickIndex = o.typeIndex = o.typeSizeStacktraceIndex = 0;
        }

        void Write3WordsAt(ulong id, ushort u1, ushort u2, ushort u3)
        {
            id >>= alignShift;
            uint i = (uint)(id >> firstLevelShift);
            uint j = (uint)(id & secondLevelMask);
            while (firstLevelTable.Length <= i+1)
                GrowFirstLevelTable();
            ushort[] secondLevelTable = firstLevelTable[i];
            if (secondLevelTable == null)
            {
                secondLevelTable = new ushort[secondLevelLength];
                firstLevelTable[i] = secondLevelTable;
            }
            secondLevelTable[j] = u1;
            j++;
            if (j >= secondLevelLength)
            {
                j = 0;
                i++;
                secondLevelTable = firstLevelTable[i];
                if (secondLevelTable == null)
                {
                    secondLevelTable = new ushort[secondLevelLength];
                    firstLevelTable[i] = secondLevelTable;
                }
            }
            secondLevelTable[j] = u2;
            j++;
            if (j >= secondLevelLength)
            {
                j = 0;
                i++;
                secondLevelTable = firstLevelTable[i];
                if (secondLevelTable == null)
                {
                    secondLevelTable = new ushort[secondLevelLength];
                    firstLevelTable[i] = secondLevelTable;
                }
            }
            secondLevelTable[j] = u3;
        }

        internal void Zero(ulong id, uint size)
        {
            uint count = ((size + 3) & (uint.MaxValue - 3))/4;
            id >>= alignShift;
            uint i = (uint)(id >> firstLevelShift);
            uint j = (uint)(id & secondLevelMask);
            ushort[] secondLevelTable = null;
            if (i < firstLevelTable.Length)
                secondLevelTable = firstLevelTable[i];
            while (count > 0)
            {
                // Does the piece to clear fit within the secondLevelTable?
                if (j + count <= secondLevelLength)
                {
                    // yes - if there is no secondLevelTable, there is nothing left to do
                    if (secondLevelTable == null)
                        break;
                    while (count > 0)
                    {
                        secondLevelTable[j] = 0;
                        count--;
                        j++;
                    }
                }
                else
                {
                    // no - if there is no secondLevelTable, skip it
                    if (secondLevelTable == null)
                    {
                        count -= secondLevelLength - j;
                    }
                    else
                    {
                        while (j < secondLevelLength)
                        {
                            secondLevelTable[j] = 0;
                            count--;
                            j++;
                        }
                    }
                    j = 0;
                    i++;
                    secondLevelTable = null;
                    if (i < firstLevelTable.Length)
                        secondLevelTable = firstLevelTable[i];
                }
            }
        }

        internal void Zero(ulong id, ulong size)
        {
            while (size >= uint.MaxValue)
            {
                Zero(id, uint.MaxValue);
                id += uint.MaxValue;
                size -= uint.MaxValue;
            }
            Zero(id, (uint)size);
        }

        internal bool CanReadObjectBackCorrectly(ulong id, uint size, int typeSizeStacktraceIndex, int allocTickIndex)
        {
            LiveObject o;
            GetNextObject(id, id + size, out o);
            return o.id == id && o.typeSizeStacktraceIndex == typeSizeStacktraceIndex && o.allocTickIndex == allocTickIndex;
        }

        internal void InsertObject(ulong id, int typeSizeStacktraceIndex, int allocTickIndex, int nowTickIndex, bool newAlloc, SampleObjectTable sampleObjectTable)
        {
            if (lastPos >= readNewLog.pos && newAlloc)
                return;
            lastPos = readNewLog.pos;

            lastTickIndex = nowTickIndex;
            int[] stacktrace = readNewLog.stacktraceTable.IndexToStacktrace(typeSizeStacktraceIndex);
            int typeIndex = stacktrace[0];
            uint size = (uint)stacktrace[1];
            bool emptySpace = false;
            if (newAlloc)
            {
                emptySpace = intervalTable.AddObject(id, size, allocTickIndex, sampleObjectTable);
            }
            if (!emptySpace)
            {
                ulong prevId = FindObjectBackward(id - 4);
                LiveObject o;
                GetNextObject(prevId, id, out o);
                if (o.id < id && (o.id + o.size > id || o.id + 12 > id))
                {
                    Zero(o.id, id - o.id);
                }
            }
            Debug.Assert(FindObjectBackward(id-4)+12 <= id);
            if (size >= 12)
            {
                ushort u1 = (ushort)(typeSizeStacktraceIndex | 0x8000);
                ushort u2 = (ushort)((typeSizeStacktraceIndex >> 15) | ((allocTickIndex & 0xff) << 7));
                ushort u3 = (ushort)(allocTickIndex >> 8);
                Write3WordsAt(id, u1, u2, u3);
                if (!emptySpace)
                    Zero(id + 12, size - 12);
                Debug.Assert(CanReadObjectBackCorrectly(id, size, typeSizeStacktraceIndex, allocTickIndex));
            }
            if (sampleObjectTable != null)
                sampleObjectTable.Insert(id, id + size, nowTickIndex, allocTickIndex, typeIndex);
        }

        void RemoveObjectRange(ulong firstId, ulong length, int tickIndex, SampleObjectTable sampleObjectTable)
        {
            ulong lastId = firstId + length;

            if (sampleObjectTable != null)
                sampleObjectTable.Delete(firstId, lastId, tickIndex);

            Zero(firstId, length);
        }

        internal void GenerationInterval(ulong rangeStart, ulong rangeLength, int generation, int tickIndex)
        {
            lastPos = readNewLog.pos;

            lastTickIndex = tickIndex;
            intervalTable.GenerationInterval(rangeStart, rangeLength, generation);            
        }

        internal int GenerationOfObject(ref LiveObject o)
        {
            int generation = intervalTable.GenerationOfObject(o.id);
            if (generation < 0)
            {
                generation = 0;
                if (o.allocTickIndex <= gen2LimitTickIndex)
                    generation = 2;
                else if (o.allocTickIndex <= gen1LimitTickIndex)
                    generation = 1;
            }
            return generation;
        }

        internal void Preserve(ulong id, ulong length, int tickIndex)
        {
            if (lastPos >= readNewLog.pos)
                return;
            lastPos = readNewLog.pos;

            lastTickIndex = tickIndex;
            intervalTable.Preserve(id, length);            
        }

        internal void UpdateObjects(Histogram relocatedHistogram, ulong oldId, ulong newId, uint length, int tickIndex, SampleObjectTable sampleObjectTable)
        {
            if (lastPos >= readNewLog.pos)
                return;
            lastPos = readNewLog.pos;

            lastTickIndex = tickIndex;
            intervalTable.Relocate(oldId, newId, length);

            if (oldId == newId)
                return;

            ulong nextId;
            ulong lastId = oldId + length;
            LiveObject o;
            for (GetNextObject(oldId, lastId, out o); o.id < lastId; GetNextObject(nextId, lastId, out o))
            {
                nextId = o.id + o.size;
                ulong offset = o.id - oldId;
                if (sampleObjectTable != null)
                    sampleObjectTable.Delete(o.id, o.id + o.size, tickIndex);
                Zero(o.id, o.size);
                InsertObject(newId + offset, o.typeSizeStacktraceIndex, o.allocTickIndex, tickIndex, false, sampleObjectTable);
                if (relocatedHistogram != null)
                    relocatedHistogram.AddObject(o.typeSizeStacktraceIndex, 1);
            }
        }

        internal int lastGcGen0Count;
        internal int lastGcGen1Count;
        internal int lastGcGen2Count;

        internal int gen1LimitTickIndex;
        internal int gen2LimitTickIndex;

        internal void RecordGc(int tickIndex, int gen, SampleObjectTable sampleObjectTable, bool simpleForm)
        {
            lastTickIndex = tickIndex;

            if (sampleObjectTable != null)
                sampleObjectTable.AddGcTick(tickIndex, gen);
    
            intervalTable.RecordGc(tickIndex, sampleObjectTable, simpleForm);

            if (gen >= 1)
                gen2LimitTickIndex = gen1LimitTickIndex;
            gen1LimitTickIndex = tickIndex;

            lastGcGen0Count++;
            if (gen > 0)
            {
                lastGcGen1Count++;
                if (gen > 1)
                    lastGcGen2Count++;
            }
        }

        internal void RecordGc(int tickIndex, int gcGen0Count, int gcGen1Count, int gcGen2Count, SampleObjectTable sampleObjectTable)
        {
            int gen = 0;
            if (gcGen2Count != lastGcGen2Count)
                gen = 2;
            else if (gcGen1Count != lastGcGen1Count)
                gen = 1;

            RecordGc(tickIndex, gen, sampleObjectTable, false);

            lastGcGen0Count = gcGen0Count;
            lastGcGen1Count = gcGen1Count;
            lastGcGen2Count = gcGen2Count;
        }
    }
    internal class ReadLogResult
    {
        internal Histogram allocatedHistogram;
        internal Histogram relocatedHistogram;
        internal Histogram callstackHistogram;
        internal Histogram finalizerHistogram;
        internal Histogram criticalFinalizerHistogram;
        internal Histogram[] heapDumpHistograms;
        internal Histogram createdHandlesHistogram;
        internal Histogram destroyedHandlesHistogram;
        internal LiveObjectTable liveObjectTable;
        internal SampleObjectTable sampleObjectTable;
        internal ObjectGraph objectGraph;
        internal ObjectGraph requestedObjectGraph; // accomodate more than one objectGraph
        internal FunctionList functionList;
        internal bool hadAllocInfo, hadCallInfo;
        internal Dictionary<ulong, HandleInfo> handleHash;
    }

    public class FilterForm : System.Windows.Forms.Form
    {
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox typeFilterTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox parentsCheckBox;
        private System.Windows.Forms.CheckBox childrenCheckBox;
        private System.Windows.Forms.CheckBox caseInsensitiveCheckBox;
        private System.Windows.Forms.CheckBox onlyFinalizableTypesCheckBox;
        internal System.Windows.Forms.TextBox methodFilterTextBox;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        private string[] typeFilters = new string[0];
        internal string[] methodFilters = new string[0];
        internal string[] signatureFilters = new string[0];
        internal ulong[] addressFilters = new ulong[0];
        private bool showChildren = true;
        private bool showParents = true;
        private bool caseInsensitive = true;
        private bool onlyFinalizableTypes = false;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox signatureFilterTextBox;
        internal int filterVersion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox addressFilterTextBox;
        private static int versionCounter;


        // Given the set of names: [aaa, aab, aac, aba, abb, abc, aca, acb, acc],
        // The filters are applied sequentially and behave in the following manner:
        //
        // "aa"       => 'aa*'                    => [aaa, aab, aac]
        // "~aa"      => not 'aa*'                => [aba, abb, abc, aca, acb, acc]
        // "aa;ab"    => 'aa*' or 'ab*'           => [aaa, aab, aac, aba, abb, abc]
        // "aa;~aab"  => 'aa*' and not 'aab*'     => [aaa, aac]
        // "~aa;aaa"  => not 'aa*' or 'aaa*'      => [aaa, aba, abb, abc, aca, acb, acc]
        // "~aa;~abb" => not 'aa*' and not 'abb*' => [aba, abc, aca, acb, acc]
        //
        internal bool IsInterestingName(string name, string[] typeFilters)
        {
            if (name == "<root>" || typeFilters.Length == 0)
                return true;

            bool? isInteresting = null;
            foreach (string filter in typeFilters)
            {
                bool isInclusiveFilter = true;
                string realFilter = filter.Trim();
                if (realFilter.Length > 0 && (realFilter[0] == '~' || realFilter[0] == '!'))
                {
                    isInclusiveFilter = false;
                    realFilter = realFilter.Substring(1).Trim();
                }

                // Skip empty filter, which handles accidental leading, trailing, or doubled semi-colons in the filter string
                if (realFilter.Length == 0)
                    continue;

                if (isInteresting == null || (isInteresting.Value ^ isInclusiveFilter))
                {
                    bool isPrefixMatch = string.Compare(name, 0, realFilter, 0, realFilter.Length, caseInsensitive, CultureInfo.InvariantCulture) == 0;
                    if (isPrefixMatch)
                        isInteresting = isInclusiveFilter;
                    else if (isInteresting == null)
                        isInteresting = !isInclusiveFilter;
                }
            }
            return isInteresting ?? true;
        }

        internal bool IsInterestingAddress(ulong thisAddress)
        {
            if (thisAddress == 0 || addressFilters.Length == 0)
                return true;
            foreach (ulong address in addressFilters)
            {
                if (address == thisAddress)
                    return true;
            }
            return false;
        }

        private bool IsInterestingSignature(string signature, string[] signatureFilters)
        {
            if (signature == null || signature == "" || signatureFilters.Length == 0)
                return true;
            return IsInterestingName(signature, signatureFilters);
        }

        internal bool IsInterestingTypeName(string typeName, string signature, bool typeIsFinalizable)
        {
            if (onlyFinalizableTypes && !typeIsFinalizable && typeName != "<root>")
                return false;
            return IsInterestingName(typeName, typeFilters) && IsInterestingSignature(signature, signatureFilters);
        }

        internal bool IsInterestingMethodName(string methodName, string signature)
        {
            return IsInterestingName(methodName, methodFilters) && IsInterestingSignature(signature, signatureFilters);
        }

        internal InterestLevel InterestLevelForParentsAndChildren()
        {
            InterestLevel interestLevel = InterestLevel.Ignore;
            if (showParents)
                interestLevel |= InterestLevel.Parents;
            if (showChildren)
                interestLevel |= InterestLevel.Children;
            return interestLevel;
        }

        public FilterForm()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.typeFilterTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.methodFilterTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.parentsCheckBox = new System.Windows.Forms.CheckBox();
            this.childrenCheckBox = new System.Windows.Forms.CheckBox();
            this.caseInsensitiveCheckBox = new System.Windows.Forms.CheckBox();
            this.onlyFinalizableTypesCheckBox = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.signatureFilterTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.addressFilterTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // okButton
            // 
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.okButton.Location = new System.Drawing.Point(488, 24);
            this.okButton.Name = "okButton";
            this.okButton.TabIndex = 0;
            this.okButton.Text = "OK";
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Location = new System.Drawing.Point(488, 64);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.TabIndex = 1;
            this.cancelButton.Text = "Cancel";
            // 
            // typeFilterTextBox
            // 
            this.typeFilterTextBox.Location = new System.Drawing.Point(48, 48);
            this.typeFilterTextBox.Name = "typeFilterTextBox";
            this.typeFilterTextBox.Size = new System.Drawing.Size(392, 20);
            this.typeFilterTextBox.TabIndex = 2;
            this.typeFilterTextBox.Text = "";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(40, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(368, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "Show Types starting with (separate multiple entries with \";\"):";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(40, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(328, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Show Methods starting with (separate multiple entries with \";\"):";
            // 
            // methodFilterTextBox
            // 
            this.methodFilterTextBox.Location = new System.Drawing.Point(48, 120);
            this.methodFilterTextBox.Name = "methodFilterTextBox";
            this.methodFilterTextBox.Size = new System.Drawing.Size(392, 20);
            this.methodFilterTextBox.TabIndex = 5;
            this.methodFilterTextBox.Text = "";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(40, 312);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Options:";
            // 
            // parentsCheckBox
            // 
            this.parentsCheckBox.Checked = true;
            this.parentsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.parentsCheckBox.Location = new System.Drawing.Point(104, 312);
            this.parentsCheckBox.Name = "parentsCheckBox";
            this.parentsCheckBox.Size = new System.Drawing.Size(208, 16);
            this.parentsCheckBox.TabIndex = 7;
            this.parentsCheckBox.Text = "Show Callers/Referencing Objects";
            // 
            // childrenCheckBox
            // 
            this.childrenCheckBox.Checked = true;
            this.childrenCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.childrenCheckBox.Location = new System.Drawing.Point(104, 344);
            this.childrenCheckBox.Name = "childrenCheckBox";
            this.childrenCheckBox.Size = new System.Drawing.Size(216, 24);
            this.childrenCheckBox.TabIndex = 8;
            this.childrenCheckBox.Text = "Show Callees/Referenced Objects";
            // 
            // caseInsensitiveCheckBox
            // 
            this.caseInsensitiveCheckBox.Checked = true;
            this.caseInsensitiveCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.caseInsensitiveCheckBox.Location = new System.Drawing.Point(336, 344);
            this.caseInsensitiveCheckBox.Name = "caseInsensitiveCheckBox";
            this.caseInsensitiveCheckBox.Size = new System.Drawing.Size(168, 24);
            this.caseInsensitiveCheckBox.TabIndex = 9;
            this.caseInsensitiveCheckBox.Text = "Ignore Case";
            // 
            // onlyFinalizableTypesCheckBox
            // 
            this.onlyFinalizableTypesCheckBox.Location = new System.Drawing.Point(336, 312);
            this.onlyFinalizableTypesCheckBox.Name = "onlyFinalizableTypesCheckBox";
            this.onlyFinalizableTypesCheckBox.Size = new System.Drawing.Size(168, 16);
            this.onlyFinalizableTypesCheckBox.TabIndex = 10;
            this.onlyFinalizableTypesCheckBox.Text = "Show only finalizable Types";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(40, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(328, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Signatures (separate multiple entries with \";\"):";
            // 
            // signatureFilterTextBox
            // 
            this.signatureFilterTextBox.Location = new System.Drawing.Point(48, 192);
            this.signatureFilterTextBox.Name = "signatureFilterTextBox";
            this.signatureFilterTextBox.Size = new System.Drawing.Size(392, 20);
            this.signatureFilterTextBox.TabIndex = 12;
            this.signatureFilterTextBox.Text = "";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(40, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(328, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Object addresses (separate multiple entries with \";\"):";
            // 
            // addressFilterTextBox
            // 
            this.addressFilterTextBox.Location = new System.Drawing.Point(48, 264);
            this.addressFilterTextBox.Name = "addressFilterTextBox";
            this.addressFilterTextBox.Size = new System.Drawing.Size(392, 20);
            this.addressFilterTextBox.TabIndex = 14;
            this.addressFilterTextBox.Text = "";
            // 
            // FilterForm
            // 
            this.AcceptButton = this.okButton;
            this.CancelButton = this.cancelButton;
            this.ClientSize = new System.Drawing.Size(584, 390);
            this.Controls.Add(this.addressFilterTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.signatureFilterTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.onlyFinalizableTypesCheckBox);
            this.Controls.Add(this.caseInsensitiveCheckBox);
            this.Controls.Add(this.childrenCheckBox);
            this.Controls.Add(this.parentsCheckBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.methodFilterTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.typeFilterTextBox);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Name = "FilterForm";
            this.Text = "Set Filters for Types and Methods";
            this.ResumeLayout(false);

        }
        #endregion

        internal void SetFilterForm(string typeFilter, string methodFilter, string signatureFilter, string addressFilter,
            bool showAncestors, bool showDescendants, bool caseInsensitive, bool onlyFinalizableTypes)
        {
            typeFilter = typeFilter.Trim();
            if (typeFilter == "")
                typeFilters = new string[0];
            else
                typeFilters = typeFilter.Split(';');

            methodFilter = methodFilter.Trim();
            if (methodFilter == "")
                methodFilters = new string[0];
            else
                methodFilters = methodFilter.Split(';');

            signatureFilter = signatureFilter.Trim();
            if (signatureFilter == "")
                signatureFilters = new string[0];
            else
                signatureFilters = signatureFilter.Split(';');

            addressFilter = addressFilter.Trim();
            if (addressFilter == "")
                addressFilters = new ulong[0];
            else
            {
                string[] addressFilterStrings = addressFilter.Split(';');
                addressFilters = new ulong[addressFilterStrings.Length];
                for (int i = 0; i < addressFilterStrings.Length; i++)
                {
                    string thisAddressFilter = addressFilterStrings[i].Replace(".", "");
                    if (thisAddressFilter != "")
                    {
                        if (thisAddressFilter.StartsWith("0x") || thisAddressFilter.StartsWith("0X"))
                            addressFilters[i] = ulong.Parse(thisAddressFilter.Substring(2), NumberStyles.HexNumber);
                        else
                            addressFilters[i] = ulong.Parse(thisAddressFilter, NumberStyles.HexNumber);
                    }
                }
            }
            this.showParents = showAncestors;
            this.showChildren = showDescendants;
            this.caseInsensitive = caseInsensitive;
            this.onlyFinalizableTypes = onlyFinalizableTypes;

            this.filterVersion = ++versionCounter;

            typeFilterTextBox.Text = typeFilter;
            methodFilterTextBox.Text = methodFilter;
            signatureFilterTextBox.Text = signatureFilter;
            addressFilterTextBox.Text = addressFilter;

            parentsCheckBox.Checked = showParents;
            childrenCheckBox.Checked = showChildren;
            caseInsensitiveCheckBox.Checked = caseInsensitive;
            onlyFinalizableTypesCheckBox.Checked = onlyFinalizableTypes;

        }

        private void okButton_Click(object sender, System.EventArgs e)
        {
            SetFilterForm(typeFilterTextBox.Text, methodFilterTextBox.Text, signatureFilterTextBox.Text, addressFilterTextBox.Text,
                parentsCheckBox.Checked, childrenCheckBox.Checked, caseInsensitiveCheckBox.Checked, onlyFinalizableTypesCheckBox.Checked);
        }
    }
}
