﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace CrossCode.ProfileLauncher
{
    

    [Flags]
    public enum OmvUsage : int
    {
        OmvUsageNone = 0,
        OmvUsageObjects = 1,
        OmvUsageTrace = 2,
        OmvUsageBoth = 3
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct ProfConfig
    {
        public OmvUsage usage;
        public int bOldFormat;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string szPath;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string szFileName;
        public int bDynamic;
        public int bStack;
        public uint dwFramesToPrint;
        public uint dwSkipObjects;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string szClassToMonitor;
        public uint dwInitialSetting;
        public uint dwDefaultTimeoutMs;
    }
    class Program
    {
        [DllImport("profilerOBJ.dll", CharSet = CharSet.Unicode)]
        private static extern uint AttachProfiler(int pid, string targetVersion, string profilerPath, [In] ref ProfConfig profConfig, bool fConsoleMode);

        struct SECURITY_ATTRIBUTES
        {
            public uint nLength;
            public IntPtr lpSecurityDescriptor;
            public int bInheritHandle;
        };

        [DllImport("Kernel32.dll", CharSet = CharSet.Auto)]
        private static extern SafeFileHandle CreateNamedPipe(
            string lpName,         // pointer to pipe name
            uint dwOpenMode,       // pipe open mode
            uint dwPipeMode,       // pipe-specific modes
            uint nMaxInstances,    // maximum number of instances
            uint nOutBufferSize,   // output buffer size, in bytes
            uint nInBufferSize,    // input buffer size, in bytes
            uint nDefaultTimeOut,  // time-out time, in milliseconds
            ref SECURITY_ATTRIBUTES lpSecurityAttributes  // pointer to security attributes
            );

        [DllImport("Kernel32.dll")]
        private static extern IntPtr OpenProcess(
            uint dwDesiredAccess,  // access flag
            bool bInheritHandle,    // handle inheritance option
            int dwProcessId       // process identifier
            );

        [DllImport("Advapi32.dll")]
        private static extern bool OpenProcessToken(
            IntPtr ProcessHandle,
            uint DesiredAccess,
            ref IntPtr TokenHandle
            );

        [DllImport("UserEnv.dll")]
        private static extern bool CreateEnvironmentBlock(
                out IntPtr lpEnvironment,
                IntPtr hToken,
                bool bInherit);

        [DllImport("UserEnv.dll")]
        private static extern bool DestroyEnvironmentBlock(
                IntPtr lpEnvironment);

        [DllImport("Advapi32.dll")]
        private static extern bool ConvertStringSecurityDescriptorToSecurityDescriptor(
            string StringSecurityDescriptor,
            uint StringSDRevision,
            out IntPtr SecurityDescriptor,
            IntPtr SecurityDescriptorSize
            );

        [DllImport("Kernel32.dll")]
        private static extern bool LocalFree(IntPtr ptr);

        [DllImport("Advapi32.dll")]
        private static extern bool ConvertSidToStringSidW(byte[] sid, out IntPtr stringSid);

        [DllImport("Advapi32.dll")]
        private static extern bool LookupAccountName(string machineName, string accountName, byte[] sid,
                                 ref int sidLen, StringBuilder domainName, ref int domainNameLen, out int peUse);

        [DllImport("Kernel32.dll")]
        private static extern bool ConnectNamedPipe(
            SafeFileHandle hNamedPipe,  // handle to named pipe to connect
            IntPtr lpOverlapped         // pointer to overlapped structure
            );

        [DllImport("Kernel32.dll")]
        private static extern bool DisconnectNamedPipe(
            SafeFileHandle hNamedPipe   // handle to named pipe
            );

        [DllImport("Kernel32.dll")]
        private static extern int GetLastError();

        [DllImport("Kernel32.dll")]
        private static extern bool ReadFile(
            IntPtr hFile,                // handle of file to read
            byte[] lpBuffer,             // pointer to buffer that receives data
            uint nNumberOfBytesToRead,  // number of bytes to read
            out uint lpNumberOfBytesRead, // pointer to number of bytes read
            IntPtr lpOverlapped    // pointer to structure for data
            );


        // profiler GUIDasdasd aklsjd ;lkaj;dlkaj ;lkdj a;lskd 
        // al;ksd;lka j;k;ljdka j;ldks aj;lkds ja;lks
        private const string PROFILER_GUID = "{941EC77E-F7C0-42C8-84E1-15FEFA3CE96F}";
        // executable to run
        private const string EXECUTABLE_TO_RUN = @"F:\CrossCode\Project\HTTPSSniffer\ILRewriting_src\Debug\SampleApp1.exe";

        private Process profiledProcess;

        private uint maxWaitingTimeInMiliseconds = 10000;
        private bool profilerConnected = false;
        private SafeFileHandle handshakingPipeHandle;
        private SafeFileHandle loggingPipeHandle;
        private FileStream handshakingPipe;
        private FileStream loggingPipe;
        internal bool noUI = true;
        private string logDirectory;
        private NamedManualResetEvent loggingActiveEvent;
        private NamedManualResetEvent forceGcEvent;
        private NamedManualResetEvent loggingActiveCompletedEvent;
        private NamedManualResetEvent forceGcCompletedEvent;
        private NamedManualResetEvent callGraphActiveEvent;
        private NamedManualResetEvent callGraphActiveCompletedEvent;
        private long logFileStartOffset;
        private long logFileEndOffset;
        private string nameToUse;
        internal ReadNewLog log;



        static void Main(string[] args)
        {
            ProcessStartInfo psi;

            // make sure the executable exists
            if (File.Exists(EXECUTABLE_TO_RUN) == false)
            {
                //MessageBox.Show("The executable '" + EXECUTABLE_TO_RUN + "' does not exist.\nCheck the EXECUTABLE_TO_RUN constant in the program.");
                return;
            }

            // create a process executor
            psi = new ProcessStartInfo(EXECUTABLE_TO_RUN);

            // ----- SET THE CLR ENVIRONMENT VARIABLES -------------------

            // set the Cor_Enable_Profiling env var. This indicates to the CLR whether or
            // not we are using the profiler at all.  1 = yes, 0 = no.
            if (psi.EnvironmentVariables.ContainsKey("COR_ENABLE_PROFILING") == true)
                psi.EnvironmentVariables["COR_ENABLE_PROFILING"] = "1";
            else
                psi.EnvironmentVariables.Add("COR_ENABLE_PROFILING", "1");

            // set the COR_PROFILER env var. This indicates to the CLR which COM object to
            // instantiate for profiling.
            if (psi.EnvironmentVariables.ContainsKey("COR_PROFILER") == true)
                psi.EnvironmentVariables["COR_PROFILER"] = PROFILER_GUID;
            else
                psi.EnvironmentVariables.Add("COR_PROFILER", PROFILER_GUID);

            // ----- SET THE PROFILER ENVIRONMENT VARIABLES -------------------

            // set the LOG_FILENAME env var. This indicates to our profiler where the log 
            // file should be written to.
            if (psi.EnvironmentVariables.ContainsKey("LOG_FILENAME") == true)
                psi.EnvironmentVariables["LOG_FILENAME"] = @"ICorProfilerCallback Log.log";
            else
                psi.EnvironmentVariables.Add("LOG_FILENAME", @"ICorProfilerCallback Log.log");

            // ----- RUN THE PROCESS -------------------

            psi.UseShellExecute = false;

            Process p = Process.Start(psi);


        }

        private bool isProfilerLoaded(int pid)
        {
            NamedManualResetEvent forceGCEvent = new NamedManualResetEvent(string.Format("{0}_{1:x8}", "Global\\OMV_ForceGC", pid), false, false);
            bool result = forceGCEvent.IsValid();
            forceGCEvent.Dispose();
            return result;
        }

        private void ShowErrorMessage(string message)
        {
            //if (!noUI)
            //{
            //    MessageBox.Show(message, "CLRProfiler");
            //}
            //else
            //{
            //    Console.WriteLine(message);
            //}
        }

        private bool attachProfiler(int pid, string fileName)
        {
            if (isProfilerLoaded(pid))
            {
                //ShowErrorMessage("CLRProfiler is already loaded in the target process.");
                return false;
            }

            ProfConfig config = new ProfConfig();
            config.usage = OmvUsage.OmvUsageNone;
            config.bOldFormat = 0;
            config.szFileName = fileName;
            config.bDynamic = 0;
            config.bStack = 0;
            config.dwSkipObjects = 0;
            config.szClassToMonitor = String.Empty;
            config.dwInitialSetting = 0;
            config.dwDefaultTimeoutMs = maxWaitingTimeInMiliseconds;

            uint result = AttachProfiler(pid, "v4.", getProfilerFullPath(), ref config, true);

            profiledProcess = Process.GetProcessById(pid);
            if (WaitForProcessToConnect(GetLogDir(), "Waiting for application to load the CLRProfiler", true, result) > 0)
            {
                return true;
            }
            else
            {
                profiledProcessEnded();
                return false;
            }
        }

        private string GetLogDir()
        {
            if (logDirectory != null)
                return logDirectory;

            string tempDir = null;
            string winDir = Environment.GetEnvironmentVariable("WINDIR");
            if (winDir != null)
            {
                tempDir = winDir + @"\TEMP";
                if (!Directory.Exists(tempDir))
                    tempDir = null;
            }
            if (tempDir == null)
            {
                tempDir = Environment.GetEnvironmentVariable("TEMP");
                if (tempDir == null)
                {
                    tempDir = Environment.GetEnvironmentVariable("TMP");
                    if (tempDir == null)
                        tempDir = @"C:\TEMP";
                }
            }
            return tempDir;
        }


        private void profiledProcessEnded()
        {
            profiledProcess = null;
            profilerConnected = false;
        }

        private string getProfilerFullPath()
        {
            return Path.GetDirectoryName(Environment.CurrentDirectory) + "\\ProfilerOBJ.dll";
        }

        private NamedManualResetEvent CreateEvent(string baseName, int pid)
        {
            string eventName = string.Format("{0}_{1:x8}", baseName, pid);
            return new NamedManualResetEvent(eventName, false, true);
        }

        private string getLogFileName(int pid)
        {
            return (nameToUse == null || nameToUse == "" ? string.Format("pipe_{0}.log", pid) : nameToUse);
        }

        private void CreateEvents(int pid)
        {
            try
            {
                loggingActiveEvent = CreateEvent("Global\\OMV_TriggerObjects", pid);
                loggingActiveCompletedEvent = CreateEvent("Global\\OMV_TriggerObjects_Completed", pid);
                forceGcEvent = CreateEvent("Global\\OMV_ForceGC", pid);
                forceGcCompletedEvent = CreateEvent("Global\\OMV_ForceGC_Completed", pid);
                callGraphActiveEvent = CreateEvent("Global\\OMV_Callgraph", pid);
                callGraphActiveCompletedEvent = CreateEvent("Global\\OMV_Callgraph_Completed", pid);
            }
            catch
            {
                //MessageBox.Show("Could not create events - in case you are profiling a service, " +"start the profiler BEFORE starting the service");
                throw;
            }
        }

        private bool ProfiledProcessHasExited()
        {
            if (profiledProcess == null)
                return true;

            try
            {
                return profiledProcess.HasExited;
            }
            catch
            {
                return Process.GetProcessById(profiledProcess.Id) == null;
            }

        }

        private string logFileName;
        internal ReadLogResult lastLogResult;

        private int WaitForProcessToConnect(string tempDir, string text, bool attachMode = false, uint result = 0)
        {
            bool fProfiledProcessInitialized = profiledProcess != null;

            ConnectNamedPipe(handshakingPipeHandle, IntPtr.Zero);
            ConnectNamedPipe(loggingPipeHandle, IntPtr.Zero);

            int pid = 0;
            byte[] handshakingBuffer = new byte[9];
            int handshakingReadBytes = 0;

            // IMPORTANT: maxloggingBufferSize must match bufferSize defined in ProfilerCallback.cpp.
            const int maxloggingBufferSize = 512;
            byte[] loggingBuffer = new byte[maxloggingBufferSize];
            int loggingReadBytes = 0;
            //WaitingForConnectionForm waitingForConnectionForm = null;
            int beginTickCount = Environment.TickCount;

            //Do not show the text in attachmode 
            if (attachMode == false)
            {
                if (noUI)
                {
                    Console.WriteLine(text);
                }
                else
                {
                    //if (waitingForConnectionForm == null)
                    //    waitingForConnectionForm = new WaitingForConnectionForm();
                    //waitingForConnectionForm.setMessage(text);
                    //waitingForConnectionForm.Visible = true;
                }
            }


            // loop reading two pipes,
            // until   
            //  (1)successfully connected 
            //  (2)User canceled
            //  (3)attach failed
            //  (4)target process exited
            while (true)
            {
                #region handshaking
                //(1)succeeded
                try
                {
                    handshakingReadBytes += handshakingPipe.Read(handshakingBuffer, handshakingReadBytes, 9 - handshakingReadBytes);
                }
                catch (System.IO.IOException)
                {
                }

                //Read 9 bytes from handshaking pipe
                //means the profielr was initialized successfully
                if (handshakingReadBytes == 9)
                    break;

                //Application.DoEvents();
                //  (2)User canceled
                if (!noUI)
                {
                    //if (waitingForConnectionForm != null && waitingForConnectionForm.DialogResult == DialogResult.Cancel)
                    //{
                    //    pid = -1;
                    //    break;
                    //}
                }
                #endregion handshaking
                #region logging
                //  (3)attach failed
                //  (3.1) read logging message
                //  (3.2) break if attach failed.

                //  (3.1) read logging message
                try
                {
                    loggingReadBytes += loggingPipe.Read(loggingBuffer, loggingReadBytes, maxloggingBufferSize - loggingReadBytes);
                }
                catch (System.IO.IOException)
                {
                }

                if (loggingReadBytes == maxloggingBufferSize)
                {
                    char[] charBuffer = new char[loggingReadBytes];
                    for (int i = 0; i < loggingReadBytes; i++)
                        charBuffer[i] = Convert.ToChar(loggingBuffer[i]);

                    string message = new String(charBuffer, 0, loggingReadBytes);

                    if (attachMode == false && noUI == false)
                    {
                        //waitingForConnectionForm.addMessage(message);
                    }
                    else
                    {
                        ShowErrorMessage(message);
                    }

                    loggingReadBytes = 0;

                    while (true)
                    {
                        try
                        {
                            if (loggingPipe.Read(loggingBuffer, 0, 1) == 0)
                            {
                                DisconnectNamedPipe(loggingPipeHandle);
                                ConnectNamedPipe(loggingPipeHandle, IntPtr.Zero);
                                break;
                            }
                        }
                        catch (System.IO.IOException)
                        {
                            DisconnectNamedPipe(loggingPipeHandle);
                            ConnectNamedPipe(loggingPipeHandle, IntPtr.Zero);
                            break;
                        }
                    }
                }
                //  (3.2) break if attach failed.
                if (attachMode == true && result != 0)
                {
                    pid = -1;
                    break;
                }
                #endregion logging
                //  (4)target process exited
                if ((fProfiledProcessInitialized && profiledProcess == null) || (profiledProcess != null && ProfiledProcessHasExited()))
                {
                    pid = -1;
                    break;
                }
                Thread.Sleep(100);
            }

            //if (waitingForConnectionForm != null)
            //    waitingForConnectionForm.Visible = false;

            if (pid == -1)
                return pid;
            if (handshakingReadBytes == 9)
            {
                char[] charBuffer = new char[9];
                for (int i = 0; i < handshakingBuffer.Length; i++)
                    charBuffer[i] = Convert.ToChar(handshakingBuffer[i]);
                pid = Int32.Parse(new String(charBuffer, 0, 8), NumberStyles.HexNumber);

                CreateEvents(pid);

                string fileName = getLogFileName(pid);
                byte[] fileNameBuffer = new Byte[fileName.Length + 1];
                for (int i = 0; i < fileName.Length; i++)
                    fileNameBuffer[i] = (byte)fileName[i];

                fileNameBuffer[fileName.Length] = 0;
                handshakingPipe.Write(fileNameBuffer, 0, fileNameBuffer.Length);
                handshakingPipe.Flush();
                logFileName = tempDir + "\\" + fileName;
                log = new ReadNewLog(logFileName);
                lastLogResult = null;
                ObjectGraph.cachedGraph = null;
                while (true)
                {
                    try
                    {
                        if (handshakingPipe.Read(handshakingBuffer, 0, 1) == 0) // && GetLastError() == 109/*ERROR_BROKEN_PIPE*/)
                        {
                            DisconnectNamedPipe(handshakingPipeHandle);
                            ConnectNamedPipe(handshakingPipeHandle, IntPtr.Zero);
                            break;
                        }
                    }
                    catch (System.IO.IOException)
                    {
                        DisconnectNamedPipe(handshakingPipeHandle);
                        ConnectNamedPipe(handshakingPipeHandle, IntPtr.Zero);
                        break;
                    }
                }
            }
            else
            {
                string error = string.Format("Error {0} occurred", GetLastError());
                ShowErrorMessage(error);
            }

            if (noUI)
            {
                Console.WriteLine("CLRProfiler is loaded in the target process.");
            }
            else
            {
                //EnableDisableViewMenuItems();
                //startApplicationButton.Enabled = startURLButton.Enabled = attachProcessButton.Enabled = detachProcessButton.Enabled = targetCLRVersioncomboBox.Enabled = false;

                //if (!allocationsCheckBox.Checked && callsCheckBox.Checked)
                //    showHeapButton.Enabled = false;
                //else
                //    showHeapButton.Enabled = true;

                //killApplicationButton.Enabled = true;
                //logFileOpenMenuItem.Enabled = profileApplicationMenuItem.Enabled = startURLMenuItem.Enabled = attachProcessMenuItem.Enabled = profileASP_NETmenuItem.Enabled = profileServiceMenuItem.Enabled = setCommandLineMenuItem.Enabled = detachProcessMenuItem.Enabled = false;
            }
            logFileStartOffset = 0;
            logFileEndOffset = long.MaxValue;
            profilerConnected = true;

            return pid;
        }
    }
}
