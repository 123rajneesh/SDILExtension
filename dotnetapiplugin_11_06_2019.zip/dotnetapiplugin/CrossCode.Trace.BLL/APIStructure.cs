﻿//-----------------------------------------------------------------------
// <copyright file="APIStructure.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using System.Collections.Generic;

    public class APIStructure
    {

        public string AssemblyName
        {
            get;
            set;
        }

        public string AssemblyKey
        {
            get;
            set;
        }

        public List<ControllersInfo> ProducerAPI
        {
            get;
            set;
        }

    }
}
