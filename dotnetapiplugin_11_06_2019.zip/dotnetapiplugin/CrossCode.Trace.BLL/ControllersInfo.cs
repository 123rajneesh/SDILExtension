﻿//-----------------------------------------------------------------------
// <copyright file="ControllersInfo.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using System.Collections.Generic;

    public class ControllersInfo
    {
        public string NMSName
        {
            get;
            set;
        }

        public string ControllerName
        {
            get;
            set;
        }

        public string ControllerClassKey
        {
            get;
            set;
        }

        public Dictionary<string,string> ControllerClassAttributes
        {
            get;
            set;
        }
        public string ActionName
        {
            get;
            set;
        }

        public string ActionMethodKey
        {
            get;
            set;
        }

        public Dictionary<string,KeyValuePair<string,string>> ActionMethodAttributes
        {
            get;
            set;
        }
    }
}
