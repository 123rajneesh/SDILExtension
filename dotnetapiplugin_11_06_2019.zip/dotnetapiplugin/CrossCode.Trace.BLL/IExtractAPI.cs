﻿//-----------------------------------------------------------------------
// <copyright file="IExtractAPI.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;

namespace RESTServerProducerAPI
{
    public  interface IExtractAPI
    {
        Dictionary<string,string> GetContollerClass(string filePath);

        string TaskType
        {
            get;
            set;
        }
    }
}
