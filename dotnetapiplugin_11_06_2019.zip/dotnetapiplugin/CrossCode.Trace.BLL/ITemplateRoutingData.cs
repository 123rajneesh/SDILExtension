﻿//-----------------------------------------------------------------------
// <copyright file="ITemplateRoutingData.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;

namespace CrossCode.Trace.BLL
{
    public interface ITemplateRoutingData
    {
        Dictionary<string, string> DefaultValues
        {
            get;
            set;
        }

        string Template
        {
            get;
            set;
        }
    }
}