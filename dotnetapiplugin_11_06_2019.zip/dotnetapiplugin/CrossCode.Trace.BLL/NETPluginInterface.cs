﻿//-----------------------------------------------------------------------
// <copyright file="NETPluginInterface.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.Trace.BLL
{
    using CrossCode.BLL.Dependency;
    using CrossCode.BLL.Domain;
    using CrossCode.BLL.DomainModels;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class NETPluginInterface
    {

        public static Dictionary<string, object> GetAllTheDecomPosition(List<string> decomCollection, List<Dictionary<string, string>> httpClientObj)
        {
            //Need to find the reference of HttpClient.Post or httpClient.Get
            //Call the decomposition module and the get the decomposition

            List<DependencyStructure> lstRawDependency = new List<DependencyStructure>();

            DependencyStructure d = new DependencyStructure();
            Dictionary<string, object> resultData = new Dictionary<string, object>();
            lstRawDependency = DependencyAnalyzer.GetAllDependListInJasonFHttpPlugin(decomCollection.ElementAt(0));

            foreach (var item in decomCollection)
            {
                List<DependencyStructure> lstRawDependencyTemp = new List<DependencyStructure>();

                lstRawDependencyTemp = lstRawDependency.Where(x => x.AssemblyName == Path.GetFileName(item)).ToList();
                var result = UsageStructProcessor.GetAllOverLoadedMethodUsage(lstRawDependencyTemp,
                                                                               httpClientObj.ElementAt(0)["A"],
                                                                               httpClientObj.ElementAt(0)["C"],
                                                                               httpClientObj.ElementAt(0)["N"],
                                                                               httpClientObj.ElementAt(0)["M"]);

                resultData.Add(Path.GetFileName(item), result);
            }

            return resultData;
        }

        public static Dictionary<string, object> GetAllTheHttpCallingDetails(string processNameWithPath, string NameSpaceName, string clsName, string methodNameWithSigntr)
        {
            //Need to find the reference of HttpClient.Post or httpClient.Get
            //Call the decomposition module and the get the decomposition
            List<DependencyStructure> lstRawDependency = new List<DependencyStructure>();
            Dictionary<string, object> resultData = new Dictionary<string, object>();
            lstRawDependency = DependencyAnalyzer.GetAllDependListInJason(processNameWithPath);

            foreach (var item in lstRawDependency)
            {
                foreach (var classDetails in item.ListOfClasses)
                {
                    if (classDetails.NameSpaceName == NameSpaceName && classDetails.ClassName == clsName)
                    {
                        var matchedMembers = classDetails.LstClassStruct.Where(x => x.MemberName == methodNameWithSigntr).FirstOrDefault();

                        if (matchedMembers != null)
                        {

                            //collect the method key here 
                        }
                    }

                }
            }

            return resultData;
        }

        public static List<HttpApiPreDTO> GetAllTheHttpCallingDetails(List<HttpApiPreDTO> httpApiDTOs)
        {
            // Need to find the reference of HttpClient.Post or httpClient.Get Call the decomposition module and the get the decomposition

            List<DependencyStructure> lstRawDependency = new List<DependencyStructure>();
            List<HttpApiPreDTO> resultData = new List<HttpApiPreDTO>();
            lstRawDependency = DependencyAnalyzer.GetAllDependListInJason(httpApiDTOs.ElementAt(0).ProcessNameWithPath);

            foreach (var item in lstRawDependency)
            {
                foreach (var classDetails in item.ListOfClasses)
                {
                    foreach (var dtoObj in httpApiDTOs)
                    {
                        if (classDetails.NameSpaceName == dtoObj.NameSpaceName && classDetails.ClassName == dtoObj.ClassName)
                        {
                            var matchedMembers = classDetails.LstClassStruct.Where(x => x.MemberName == dtoObj.FunctionName).FirstOrDefault();

                            foreach (var cls in classDetails.LstClassStruct)
                            {
                                string methodWithSign = string.Empty;

                                var temp = cls.MemberName.Split(new string[1] { " " }, System.StringSplitOptions.None);

                                if (temp.Length > 1)
                                {
                                    methodWithSign = temp[1];
                                }
                                else
                                {
                                    methodWithSign = temp[0];
                                }

                                if (methodWithSign == dtoObj.FunctionName)
                                {
                                    dtoObj.AssemblyName = item.AssemblyName;
                                    dtoObj.FunctionKey = cls.MemberKey;
                                    resultData.Add(dtoObj);
                                }

                            }

                        }

                    }

                }
            }

            return resultData;
        }

        public static List<WCFServiceConsumerPreDTO> GetAllTheHttpCallingDetails(List<WCFServiceConsumerPreDTO> clientData)
        {
            //Need to find the reference of HttpClient.Post or httpClient.Get
            //Call the decomposition module and the get the decomposition
            List<DependencyStructure> lstRawDependency = new List<DependencyStructure>();

            //Dictionary<string, object> resultData = new Dictionary<string, object>();

            List<WCFServiceConsumerPreDTO> resultData = new List<WCFServiceConsumerPreDTO>();

            lstRawDependency = DependencyAnalyzer.GetAllDependListInJason(clientData.ElementAt(0).ProcessNameWithPath);

            foreach (var item in lstRawDependency)
            {
                foreach (var classDetails in item.ListOfClasses)
                {
                    foreach (var dtoObj in clientData)
                    {
                        if (classDetails.NameSpaceName.ToLower() == dtoObj.NameSpaceName.ToLower() && classDetails.ClassName.ToLower() == dtoObj.ClassName.ToLower())
                        {
                            var matchedMembers = classDetails.LstClassStruct.Where(x => x.MemberName == dtoObj.FunctionName).FirstOrDefault();

                            foreach (var cls in classDetails.LstClassStruct)
                            {
                                string methodWithSign = string.Empty;

                                var temp = cls.MemberName.Split(new string[1] { " " }, System.StringSplitOptions.None);

                                if (temp.Length > 1)
                                {
                                    methodWithSign = temp[1];
                                }
                                else
                                {
                                    methodWithSign = temp[0];
                                }

                                if (methodWithSign == dtoObj.FunctionName)
                                {
                                    dtoObj.AssemblyName = item.AssemblyName;
                                    dtoObj.FunctionKey = cls.MemberKey;
                                    resultData.Add(dtoObj);                                   
                                }

                            }

                        }

                    }

                }
            }

            return resultData;
        }
    }
}
