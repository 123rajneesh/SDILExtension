﻿//-----------------------------------------------------------------------
// <copyright file="TemplateRoutingData.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace CrossCode.Trace.BLL
{
    using System.Collections.Generic;
    public class TemplateRoutingData : ITemplateRoutingData
    {

        public string Template
        {
            get;
            set;
        }

        public Dictionary<string, string> DefaultValues
        {
            get;
            set;
        }
    }
}
