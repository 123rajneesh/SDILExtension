﻿//-----------------------------------------------------------------------
// <copyright file="APIConsumerFunct.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace CrossCode.WCF.Analyzer
{
    using System.Collections.Generic;

    public class APIConsumerFunct
    {
        public static bool GetServiceModuleCalling(string appPath, out Dictionary<string, object> consumers)
        {
            consumers = new Dictionary<string, object>();

            IServiceConsumer IserviceConsumer = new ServiceConsumer();

            bool serviceModuleCallingExist = IserviceConsumer.FindServiceModuleLibrary(appPath, out consumers);

            if (serviceModuleCallingExist)
            {
                //Read the consumers
            }
            return serviceModuleCallingExist;
        }
    }
}
