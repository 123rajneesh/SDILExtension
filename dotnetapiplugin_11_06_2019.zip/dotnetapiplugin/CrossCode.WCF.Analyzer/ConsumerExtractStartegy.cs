﻿using CrossCode.BLL.Domain;
using CrossCode.Integration.Api;
using CrossCode.Trace.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CrossCode.WCF.Analyzer
{
    public class ConsumerExtractStartegy
    {
        public static List<WCFServiceConsumerPreDTO> GetConsumerWCFApiFromStartegy(string proFullPath, string processID, string taskTyp)
        {
            try
            {
                //create the backup of config file
                Context context;

                context = new Context(new StrategyByTracing() { TaskType = taskTyp });
                var urlData = context.ContextInterface(proFullPath, processID);

                //prepare the information  and do the mapping in DTO
                var apiConsumerUsage = PluginAPIDTOMapper.CreateAPIClientData(urlData, proFullPath, "MethodName");

                // Fill and find the function key  
                List<WCFServiceConsumerPreDTO> wcfServiceConsumerPreDTO = NETPluginInterface.GetAllTheHttpCallingDetails(apiConsumerUsage);

                return wcfServiceConsumerPreDTO;

            }
            catch (Exception ex)
            {
                return new List<WCFServiceConsumerPreDTO>();
            }
        }
    }
}
