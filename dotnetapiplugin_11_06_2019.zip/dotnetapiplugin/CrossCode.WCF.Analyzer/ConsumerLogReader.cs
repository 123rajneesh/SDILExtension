﻿//-----------------------------------------------------------------------
// <copyright file="ConsumerLogReader.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace CrossCode.WCF.Analyzer
{
    using CrossCode.WCF.Analyzer.Properties;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Xml;
    public class ConsumerLogReader
    {
        public static List<Trace> GetDataFromTracingTables(string content)
        {
            try
            {
                var dsCollection = ReadTraceContentToDataset(content);

                List<Trace> traceCollection = null;
                if (dsCollection != null)
                {
                    if (dsCollection.Count > 0)
                    {
                        ITracingTables tracingTables = new TracingTables();
                        traceCollection = new List<Trace>();

                        foreach (var ds in dsCollection)
                        {
                            List<Trace> traceDTO = null;
                            //used for http data mapping
                            var dtApplicationData = ds.Tables["ApplicationData"];
                            var dtTraceData = ds.Tables["TraceData"];
                            var dtDataItem = ds.Tables["DataItem"];
                            var dtTraceRecord = ds.Tables["TraceRecord"];
                            var dtExtendedData = ds.Tables["ExtendedData"];
                            var dtMessageProperties = ds.Tables["MessageProperties"];
                            var dtSystemDiagnostics = ds.Tables["System.Diagnostics"];
                            var dtEndpointReference = ds.Tables["EndpointReference"];

                            switch (ds.DataSetName)
                            {
                                case BindingImplementation.HttpBinding:

                                    traceDTO = tracingTables.QueryTraceTable(dtTraceData, dtDataItem, dtTraceRecord, dtExtendedData, dtSystemDiagnostics, dtMessageProperties, "Via").Distinct().ToList();
                                    break;

                                case BindingImplementation.NetTcpBinding:

                                    traceDTO = tracingTables.QueryTraceTable(dtTraceData, dtDataItem, dtTraceRecord, dtExtendedData, dtSystemDiagnostics, dtEndpointReference, "Address").Distinct().ToList();
                                    break;
                                case BindingImplementation.ClientProxy:

                                    traceDTO = tracingTables.QueryTraceTable(dtTraceData, dtDataItem, dtTraceRecord, dtExtendedData, dtSystemDiagnostics).Distinct().ToList();
                                    break;
                            }
                            if (traceDTO != null)
                                traceDTO.AddRange(traceDTO);

                            traceCollection = UpdateForClientProxy(traceDTO);

                        }
                    }
                }
                return traceCollection;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static List<Trace> UpdateForClientProxy(List<Trace> diagnosticsAttribute)
        {
            var isProxyDto = diagnosticsAttribute.Where(x => x.BindingImplementation == BindingImplementation.ClientProxy).ToList();

            var isUnknownDto = diagnosticsAttribute.Where(x => x.BindingImplementation == BindingImplementation.Unkown).ToList();

            List<Trace> filter = new List<Trace>();

            if (isProxyDto.Count > 0)
            {
                foreach (var p in isProxyDto)
                {
                    var temp = isUnknownDto.Where(u => u.Contract.ToLower() == p.Contract.ToLower() && u.Binding.ToLower() == p.Binding.ToLower() && u.Address.ToLower() == p.Address.ToLower()).ToList();

                    foreach (var t in temp)
                    {
                        if (!t.CallStack.Contains(p.ConsumerMethodSig))
                        {
                            filter.Add(t);
                        }
                    }
                    filter.Add(p);
                }
            }
            else
            {
                filter.AddRange(isUnknownDto);
            }
            var minDto = filter.Select(x => new Trace
            {
                Contract = x.Contract.ToLower(),
                Binding = x.Binding.ToLower(),
                Address = x.Address.ToLower(),
                ConsumerMethodSig = x.ConsumerMethodSig.ToLower()
            }).Distinct().ToList();

            List<Trace> distinct =
                                            minDto
                                            .GroupBy(a => new { a.Contract, a.Binding, a.Address })
                                            .Select(g => g.First())
                                            .ToList();
            return distinct;
        }

        private static List<DataSet> ReadTraceContentToDataset(string content)
        {
            try
            {
                List<DataSet> dsCollection = null;

                if (!string.IsNullOrEmpty(content))
                {
                    dsCollection = new List<DataSet>();

                    // http protocol channelfactory used schema
                    var dshttpTrace = ReadLog(content, Resources.DataSet_Http_Schema, BindingImplementation.HttpBinding);

                    // tcp protocol channelfactory used schema
                    var dsnetTcpTrace = ReadLog(content, Resources.DataSet_NetTcp_Schema, BindingImplementation.NetTcpBinding);

                    // client proxy channelfactory used schema
                    var dsProxyTrace = ReadLog(content, Resources.DataSet_Proxy_Schema, BindingImplementation.ClientProxy);

                    dsCollection.Add(dshttpTrace);

                    dsCollection.Add(dsnetTcpTrace);

                    dsCollection.Add(dsProxyTrace);
                }

                return dsCollection;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private static DataSet ReadLog(string logFileContent, string datasetSchema, string binding)
        {
            DataSet ds = new DataSet();

            //Setting to read all root elements
            XmlReaderSettings settings = new XmlReaderSettings();

            settings.ConformanceLevel = ConformanceLevel.Fragment;

            //Invoke the ReadXmlSchema method with the from resourec file object.               
            ds.ReadXmlSchema(new StringReader(datasetSchema));

            XmlReader reader = XmlReader.Create(new StringReader(logFileContent), settings);

            while (reader.Read())
            {
                ds.ReadXml(reader, XmlReadMode.Auto);
            }
            ds.DataSetName = binding;

            return ds;
        }
        /*
        public static List<Trace> GetDataFromTracingTables(string content)
        {
            try
            {
                var dsCollection = ReadTraceContentToDataset(content);

                List<Trace> traceCollection = null;

                if (dsCollection.Count > 0)
                {
                    traceCollection = new List<Trace>();

                    foreach (var ds in dsCollection)
                    {
                        List<Trace> traceDTO = null;
                        //used for http data mapping
                        var dtApplicationData = ds.Tables["ApplicationData"];
                        var dtTraceData = ds.Tables["TraceData"];
                        var dtDataItem = ds.Tables["DataItem"];
                        var dtTraceRecord = ds.Tables["TraceRecord"];
                        var dtExtendedData = ds.Tables["ExtendedData"];
                        var dtMessageProperties = ds.Tables["MessageProperties"];
                        var dtSystemDiagnostics = ds.Tables["System.Diagnostics"];
                        var dtEndpointReference = ds.Tables["EndpointReference"];

                        switch (ds.DataSetName)
                        {
                            
                            case BindingImplementation.HttpBinding:

                                traceDTO = QueryHttpData(dtTraceData, dtDataItem, dtTraceRecord, dtExtendedData, dtSystemDiagnostics, dtMessageProperties).Distinct().ToList();
                                break;


                            case BindingImplementation.NetTcpBinding:

                                traceDTO = QueryNeTcpData(dtTraceData, dtDataItem, dtTraceRecord, dtExtendedData, dtSystemDiagnostics, dtEndpointReference).Distinct().ToList();

                                break;
                            case BindingImplementation.ClientProxy:

                                traceDTO = QueryClientProxyData(dtTraceData, dtDataItem, dtTraceRecord, dtExtendedData, dtSystemDiagnostics).Distinct().ToList();
                                break;
                        }
                        if (traceDTO != null)
                            traceDTO.AddRange(traceDTO);

                        traceCollection = UpdateForClientProxy(traceDTO);

                    }
                }
                return traceCollection;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static IEnumerable<Trace> QueryClientProxyData(DataTable dtTraceData, DataTable dtDataItem, DataTable dtTraceRecord, DataTable dtExtendedData, DataTable dtSystemDiagnostics)
        {
            return from dsd in dtSystemDiagnostics.AsEnumerable()
                   join dtd in dtTraceData.AsEnumerable() on dsd.Field<int>("ApplicationData_Id") equals dtd.Field<int>("ApplicationData_Id")
                   join ddi in dtDataItem.AsEnumerable() on dtd.Field<int>("TraceData_Id") equals ddi.Field<int>("TraceData_Id")
                   join dtr in dtTraceRecord.AsEnumerable() on ddi.Field<int>("DataItem_Id") equals dtr.Field<int>("DataItem_Id")
                   join ded in dtExtendedData.AsEnumerable() on dtr.Field<int>("TraceRecord_Id") equals ded.Field<int>("TraceRecord_Id")
                   where ded.Field<string>("RemoteEndpointUri") != null
                   select new Trace
                   {
                       ApplicationDataId = dsd.Field<int>("ApplicationData_Id"),
                       CallStack = dsd.Field<string>("CallStack"),
                       ConsumerMethodSig = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ConsumerMethodInfo),
                       Address = ded.Field<string>("RemoteEndpointUri"),
                       Contract = ReadCallStack(ded.Field<string>("ContractName"), ServiceInfoType.ContractInfo),
                       Binding = ded.Field<string>("Binding"),
                       BindingImplementation = BindingImplementation.ClientProxy
                   };
        }

        private static IEnumerable<Trace> QueryHttpData(DataTable dtTraceData, DataTable dtDataItem, DataTable dtTraceRecord, DataTable dtExtendedData, DataTable dtSystemDiagnostics, DataTable dtMessageProperties)
        {
            return from dsd in dtSystemDiagnostics.AsEnumerable()
                   join dtd in dtTraceData.AsEnumerable() on dsd.Field<int>("ApplicationData_Id") equals dtd.Field<int>("ApplicationData_Id")
                   join ddi in dtDataItem.AsEnumerable() on dtd.Field<int>("TraceData_Id") equals ddi.Field<int>("TraceData_Id")
                   join dtr in dtTraceRecord.AsEnumerable() on ddi.Field<int>("DataItem_Id") equals dtr.Field<int>("DataItem_Id")
                   join ded in dtExtendedData.AsEnumerable() on dtr.Field<int>("TraceRecord_Id") equals ded.Field<int>("TraceRecord_Id")
                   join dmp in dtMessageProperties.AsEnumerable() on ded.Field<int>("ExtendedData_Id") equals dmp.Field<int>("ExtendedData_Id")
                   where dmp.Field<string>("Via") != null
                   select new Trace
                   {
                       ApplicationDataId = dsd.Field<int>("ApplicationData_Id"),
                       CallStack = dsd.Field<string>("CallStack"),
                       ConsumerMethodSig = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ConsumerMethodInfo),
                       Address = dmp.Field<string>("Via"),
                       Contract = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ContractInfo),
                       Binding = GetBinding(dmp.Field<string>("Via")),
                       BindingImplementation = BindingImplementation.Unkown

                   };
        }

        private static IEnumerable<Trace> QueryNeTcpData(DataTable dtTraceData, DataTable dtDataItem, DataTable dtTraceRecord, DataTable dtExtendedData, DataTable dtSystemDiagnostics, DataTable dtEndpointReference)
        {
            return from dsd in dtSystemDiagnostics.AsEnumerable()
                   join dtd in dtTraceData.AsEnumerable() on dsd.Field<int>("ApplicationData_Id") equals dtd.Field<int>("ApplicationData_Id")
                   join ddi in dtDataItem.AsEnumerable() on dtd.Field<int>("TraceData_Id") equals ddi.Field<int>("TraceData_Id")
                   join dtr in dtTraceRecord.AsEnumerable() on ddi.Field<int>("DataItem_Id") equals dtr.Field<int>("DataItem_Id")
                   join ded in dtExtendedData.AsEnumerable() on dtr.Field<int>("TraceRecord_Id") equals ded.Field<int>("TraceRecord_Id")
                   join der in dtEndpointReference.AsEnumerable() on ded.Field<int>("ExtendedData_Id") equals der.Field<int>("ExtendedData_Id")
                   where der.Field<string>("Address") != null
                   select new Trace
                   {
                       ApplicationDataId = dsd.Field<int>("ApplicationData_Id"),
                       CallStack = dsd.Field<string>("CallStack"),
                       ConsumerMethodSig = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ConsumerMethodInfo),
                       Address = der.Field<string>("Address"),
                       Contract = ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ContractInfo),
                       Binding = GetBinding(der.Field<string>("Address")),
                       BindingImplementation = BindingImplementation.Unkown
                   };
        }
        //Read call stack to get properties values
        private static string ReadCallStack(string callStack, ServiceInfoType serviceInfoType)
        {
            try
            {
                string value = string.Empty;
                using (StringReader reader = new StringReader(callStack))
                {
                    while (true)
                    {
                        var line = reader.ReadLine();
                        if (line == null)
                        {
                            break;
                        }
                        //skip systems types calls
                        line = line.TrimStart(' ');

                        var nsline = line.TrimStart(TRIM_KEYWORD_AT.ToCharArray()).TrimStart(' ');

                        if (!nsline.StartsWith(SKIP_KEYWORD))
                        {
                            var indexOfin = nsline.IndexOf(INDEXOF_IN);

                            switch (serviceInfoType)
                            {
                                case ServiceInfoType.ContractInfo:
                                    if (indexOfin == -1)
                                    {
                                        return GetContract(nsline);
                                    }
                                    break;
                                case ServiceInfoType.ServiceMethodInfo:
                                    if (indexOfin == -1)
                                    {
                                        value = nsline.Trim();
                                        return value;
                                    }
                                    break;
                                case ServiceInfoType.ConsumerMethodInfo:
                                    if (indexOfin > -1)
                                    {
                                        value = nsline.Substring(0, indexOfin).Trim();
                                        if (!value.Contains("ctor()"))
                                            return value;
                                    }
                                    break;
                            }
                        }
                    }
                    return value;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static string GetContract(string nsline)
        {
            string contract = string.Empty;
            try
            {
                var line = nsline.Trim();
                var lastIndexOf_Dot = line.LastIndexOf('.');

                if (line.Contains('('))
                {
                    var fullName = line.Substring(0, lastIndexOf_Dot);

                    var fullNameIdx = fullName.LastIndexOf('.') + 1;

                    contract = line.Substring(fullNameIdx, fullName.Length - fullNameIdx);
                }
                else
                {
                    contract = line.Substring(lastIndexOf_Dot, line.Length - lastIndexOf_Dot).Trim('.');
                }
                return contract;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static string GetBinding(string serviceUrl)
        {
            Uri uri = new Uri(serviceUrl);
            //string requested = uri.Scheme + Uri.SchemeDelimiter + uri.Host + ":" + uri.Port;
            string protocol = uri.Scheme;

            string binding = string.Empty;

            foreach (var bb in DefaultBinding.Bindings)
            {
                foreach (var v in bb.Value)
                {
                    if (v == protocol)
                    {
                        binding = bb.Key;
                        return binding;
                    }

                }
            }
            return binding;
        }
        */
    }
}
