﻿//-----------------------------------------------------------------------
// <copyright file="Context.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.WCF.Analyzer
{
    using CrossCode.Trace.BLL;
    using System.Collections.Generic;

    public class Context
    {
        private IStretegyHttpAPIConsumer<List<KeyValuePair<string, string>>> _apiStrategy;


        public Context(IStretegyHttpAPIConsumer<List<KeyValuePair<string, string>>> strategy)
        {
            this._apiStrategy = strategy;
        }

        public List<KeyValuePair<string, string>> ContextInterface(string dirPath, string procID)
        {
            return _apiStrategy.GetHttpConsumptionAlgorithm(dirPath, procID);
        }
      
    }
}
