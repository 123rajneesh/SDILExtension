﻿//-----------------------------------------------------------------------
// <copyright file="IServiceConsumer.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace CrossCode.WCF.Analyzer
{
    using System.Collections.Generic;
    public interface IServiceConsumer
    {       
        bool FindServiceModuleLibrary(string appPath, out Dictionary<string, object> serviceConsumData);
    }
}
