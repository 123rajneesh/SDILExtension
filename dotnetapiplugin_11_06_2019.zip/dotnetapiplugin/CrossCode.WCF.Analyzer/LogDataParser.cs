﻿//-----------------------------------------------------------------------
// <copyright file="LogDataParser.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace CrossCode.WCF.Analyzer
{
    using CrossCode.ByteCode.Helper;
    using System.Collections.Generic;
    using System.IO;
    using System.Xml;
    using System.Linq;
    using CrossCode.Helper;
    using CrossCode.BLL.Domain;

    /// <summary>
    /// for the parsing of log and extracting the required 
    /// </summary>
    public class LogDataParser
    {

        // Parsing  the tracing data and then extarcting information accordingly.
        public static List<KeyValuePair<string, string>> Parse(string logPath)
        {
            
            List<KeyValuePair<string, string>> sniffDataDup = new List<KeyValuePair<string, string>>();

            string svcCallLogFile = File.ReadAllText(logPath).ToString();

            //Added WCF Consumer DTO
            var DTOs = ConsumerLogReader.GetDataFromTracingTables(svcCallLogFile);

            List<WCFConsumerData> wcfConsumerData = DTOs.Select(x => new WCFConsumerData
            {
                Address = x.Address,
                Binding = x.Binding,
                Contract = x.Contract,
                MethodName = x.ConsumerMethodSig,
                MethodIdentifier = AssemblyHashCodeGenerator.GetWCFHashKey(x.Address, x.Binding, x.Contract, x.ConsumerMethodSig)

            }).ToList();

            foreach (var data in wcfConsumerData)
            {
                var pair = GenericPropertyGetter(data);

                sniffDataDup.AddRange(pair);
            }

            return sniffDataDup;
        }


        public static List<WCFServiceConsumerPreDTO> LogParsing(string logPath)
        {
            //List<WCFConsumerData> wCFConsumerDatas = new List<WCFConsumerData>();

            List<KeyValuePair<string, string>> sniffDataDup = new List<KeyValuePair<string, string>>();

            string svcCallLogFile = File.ReadAllText(logPath).ToString();

            //Added WCF Consumer DTO
            var DTOs = ConsumerLogReader.GetDataFromTracingTables(svcCallLogFile);

            List<WCFServiceConsumerPreDTO> wcfConsumerData = DTOs.Select(x => new WCFServiceConsumerPreDTO
            {
                Address = x.Address,
                Binding = x.Binding,
                Contract = x.Contract,
                FunctionName = x.ConsumerMethodSig,
                //MethodIdentifier = AssemblyHashCodeGenerator.GetWCFHashKey(x.Address, x.Binding, x.Contract, x.ConsumerMethodSig)

            }).ToList();
            
            return wcfConsumerData;
        }
        
        private static List<KeyValuePair<string, string>> GenericPropertyGetter<T>(T wCFConsumerData)
        {
            List<KeyValuePair<string, string>> pairs = new List<KeyValuePair<string, string>>();

            var propInfo = wCFConsumerData.GetType().GetProperties();

            foreach (var property in propInfo)
            {
                var propName = property.Name;

                var PropValue = property.GetValue(wCFConsumerData);

                pairs.Add(new KeyValuePair<string, string>(propName, PropValue.ToString()));
            }

            return pairs;
        }
    }
}
