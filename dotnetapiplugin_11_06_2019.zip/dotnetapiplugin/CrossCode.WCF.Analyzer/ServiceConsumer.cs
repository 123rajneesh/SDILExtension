﻿//-----------------------------------------------------------------------
// <copyright file="ServiceConsumer.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace CrossCode.WCF.Analyzer
{
    using CrossCode.ByteCode.Helper;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;

    public class ServiceConsumer : IServiceConsumer
    {
        public bool FindServiceModuleLibrary(string appPath, out Dictionary<string, object> serviceConsumData)
        {
            serviceConsumData = new Dictionary<string, object>();
            return Execute(appPath, out serviceConsumData);
        }

        private bool Execute(string applicatioPath, out Dictionary<string, object> serviceConsumData)
        {
            bool serviceModelLibUsed = false;

            serviceConsumData = new Dictionary<string, object>();

            var clientdll = AppHelper.GetHttpClientConnectedLibraryInAppAll();

            string appDir = Path.GetDirectoryName(applicatioPath);

            List<string> serviceClientRefAssem = new List<string>();

            foreach (string filepath in Directory.GetFiles(appDir))
            {
                try
                {
                    if (filepath.EndsWith(".dll") || filepath.EndsWith(".exe"))
                    {
                        Assembly assem = Assembly.LoadFile(filepath);
                        var refAssembly = assem.GetReferencedAssemblies();

                        bool isServiceModelClientRefExist = refAssembly.Any(x => Path.GetFileNameWithoutExtension(clientdll.ElementAt(0)["L"]) == x.Name);

                        if (isServiceModelClientRefExist)
                        {
                            serviceModelLibUsed = true;
                            serviceClientRefAssem.Add(filepath);
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }
            serviceConsumData = new Dictionary<string, object>();

            return serviceModelLibUsed;
        }
    }
}