﻿//-----------------------------------------------------------------------
// <copyright file="StrategyByTracing.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace CrossCode.WCF.Analyzer
{
    using System.Collections.Generic;
    using System.IO;
    using CrossCode.BLL.Domain;
    using CrossCode.ByteCode.Helper;
    using CrossCode.DeepTrace.Engine;
    using CrossCode.Trace.BLL;
    using RESTAPIConsumerFunct;

    internal class StrategyByTracing : IStretegyHttpAPIConsumer<List<KeyValuePair<string, string>>>
    {
        private const string configFileNameExtension = ".config";
        private const string iisConfigFileName = "Web.config";

        public string TaskType
        {
            get;
            set;
        }

        public string ConfigFileNameExtension
        {
            get
            {
                return configFileNameExtension;
            }
        }
        public StrategyByTracing()
        {
        }

        public List<KeyValuePair<string, string>> GetHttpConsumptionAlgorithm(string configFullPath, string procID)
        {
            string sourceDir = Path.GetDirectoryName(configFullPath);
            string mainModuleName = Path.GetFileName(configFullPath);
            string localLogPath = string.Empty;
            //First we need to check  whether process is consuming the http api or not.
            List<WCFServiceConsumerPreDTO> servcieConsumerData = new List<WCFServiceConsumerPreDTO>();

            List<KeyValuePair<string, string>> pairCollection = new List<KeyValuePair<string, string>>();

            string configFilePath = Path.Combine(sourceDir, mainModuleName + ConfigFileNameExtension);

            if (TaskType == "IIS")
            {
                configFilePath = string.Concat(Path.GetDirectoryName(sourceDir), "\\", iisConfigFileName);
            }

            if (APIConsumerFunct.GetServiceModuleCalling(configFullPath, out Dictionary<string, object> data))
            {
                //return httpConsumerData;
                IWCFConfigInjector wcfconfiginjector = new WCFConfigInjector();
                //Add the trace config in application
                wcfconfiginjector.AddTraceConfigInConsumerApplication(configFilePath);

                //Get the log
                if (TaskType == "IIS")
                {
                    localLogPath = FileHelper.RecollectTheLogInLocal(Path.GetDirectoryName(sourceDir), procID);
                }
                else if (TaskType == string.Empty)
                {
                    localLogPath = FileHelper.RecollectStandAloneLogInLocal(sourceDir, procID);
                }

                // interpretate the log             
                pairCollection = LogDataParser.Parse(localLogPath);

                // Filter duplicate urls in client side              
            }

            return pairCollection;
        }
        private static List<KeyValuePair<string, string>> GenericPropertyGetter<T>(T wCFConsumerData)
        {
            List<KeyValuePair<string, string>> pairs = new List<KeyValuePair<string, string>>();

            var propInfo = wCFConsumerData.GetType().GetProperties();

            foreach (var property in propInfo)
            {
                var propName = property.Name;

                var PropValue = property.GetValue(wCFConsumerData);

                pairs.Add(new KeyValuePair<string, string>(propName, PropValue.ToString()));
            }

            return pairs;
        }
    }
}
