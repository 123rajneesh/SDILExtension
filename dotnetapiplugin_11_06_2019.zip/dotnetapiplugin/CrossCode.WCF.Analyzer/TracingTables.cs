﻿using CrossCode.ByteCode.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrossCode.WCF.Analyzer
{
    public class TracingTables : ITracingTables
    {
        public IEnumerable<Trace> QueryTraceTable(DataTable dtTraceData, DataTable dtDataItem, DataTable dtTraceRecord, DataTable dtExtendedData, DataTable dtSystemDiagnostics)
        {
            return from dsd in dtSystemDiagnostics.AsEnumerable()
                   join dtd in dtTraceData.AsEnumerable() on dsd.Field<int>("ApplicationData_Id") equals dtd.Field<int>("ApplicationData_Id")
                   join ddi in dtDataItem.AsEnumerable() on dtd.Field<int>("TraceData_Id") equals ddi.Field<int>("TraceData_Id")
                   join dtr in dtTraceRecord.AsEnumerable() on ddi.Field<int>("DataItem_Id") equals dtr.Field<int>("DataItem_Id")
                   join ded in dtExtendedData.AsEnumerable() on dtr.Field<int>("TraceRecord_Id") equals ded.Field<int>("TraceRecord_Id")
                   where ded.Field<string>("RemoteEndpointUri") != null
                   select new Trace
                   {
                       ApplicationDataId = dsd.Field<int>("ApplicationData_Id"),
                       CallStack = dsd.Field<string>("CallStack"),
                       ConsumerMethodSig = WCFHelper.ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ConsumerMethodInfo),
                       Address = ded.Field<string>("RemoteEndpointUri"),
                       Contract = WCFHelper.ReadCallStack(ded.Field<string>("ContractName"), ServiceInfoType.ContractInfo),
                       Binding = ded.Field<string>("Binding"),
                       BindingImplementation = BindingImplementation.ClientProxy
                   };
        }


        public IEnumerable<Trace> QueryTraceTable(DataTable dtTraceData, DataTable dtDataItem, DataTable dtTraceRecord, DataTable dtExtendedData, DataTable dtSystemDiagnostics, DataTable dtAddtional, string column)
        {
            return from dsd in dtSystemDiagnostics.AsEnumerable()
                   join dtd in dtTraceData.AsEnumerable() on dsd.Field<int>("ApplicationData_Id") equals dtd.Field<int>("ApplicationData_Id")
                   join ddi in dtDataItem.AsEnumerable() on dtd.Field<int>("TraceData_Id") equals ddi.Field<int>("TraceData_Id")
                   join dtr in dtTraceRecord.AsEnumerable() on ddi.Field<int>("DataItem_Id") equals dtr.Field<int>("DataItem_Id")
                   join ded in dtExtendedData.AsEnumerable() on dtr.Field<int>("TraceRecord_Id") equals ded.Field<int>("TraceRecord_Id")
                   join dmp in dtAddtional.AsEnumerable() on ded.Field<int>("ExtendedData_Id") equals dmp.Field<int>("ExtendedData_Id")
                   where dmp.Field<string>(column) != null
                   select new Trace
                   {
                       ApplicationDataId = dsd.Field<int>("ApplicationData_Id"),
                       CallStack = dsd.Field<string>("CallStack"),
                       ConsumerMethodSig = WCFHelper.ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ConsumerMethodInfo),
                       Address = dmp.Field<string>(column),
                       Contract = WCFHelper.ReadCallStack(dsd.Field<string>("CallStack"), ServiceInfoType.ContractInfo),
                       Binding = WCFHelper.GetBinding(dmp.Field<string>(column)),
                       BindingImplementation = BindingImplementation.Unkown

                   };
        }
    }
}
