﻿using CrossCode.ByteCode.Helper;
using CrossCode.WCF.Analyzer.Properties;
using System;
using System.IO;
using System.Reflection;
using System.Xml;

namespace CrossCode.WCF.Analyzer
{
    public class WCFConfigInjector : IWCFConfigInjector
    {
        private const string XpathConfiguSection = "//configuration//system.diagnostics";
        private AppDomain currentDomain = AppDomain.CurrentDomain;
        public string SourcePath { get; private set; }


        public void AddTraceConfigInConsumerApplication(string configPath)
        {
            SourcePath = Environment.CurrentDirectory;

            this.currentDomain.AssemblyResolve += new ResolveEventHandler(AssemResolveEventHandler);

            XmlDocument doc;
            XmlElement webConfigData;

            XMLNodeBuilder.GetXMLConfigSectionByXpath(configPath, out doc, out webConfigData, XpathConfiguSection);

            if (webConfigData != null)
            {
                XmlNodeList traceAttr = webConfigData.SelectNodes("//trace");
                bool isAnyChangesInConfig = false;

                XMLNodeBuilder.ChekNAddTraceInConfig(doc, webConfigData, traceAttr, Resources.TraceAttr, ref isAnyChangesInConfig);

                XmlNodeList sourceAttr = webConfigData.SelectNodes("//sources");
                XMLNodeBuilder.ChekNAddSourceInConfig(doc, webConfigData, sourceAttr, Resources.Source, ref isAnyChangesInConfig);

                XmlNodeList ListenerAttr = webConfigData.SelectNodes("//listeners");
                XMLNodeBuilder.CheckNAddListeners(doc, webConfigData, ListenerAttr, Resources.Listner, ref isAnyChangesInConfig);

                XmlNodeList switchesNode = webConfigData.SelectNodes("//switches");
                XMLNodeBuilder.CheckNAddSwitchesInConfig(doc, webConfigData, switchesNode, Resources.SwitchNode, ref isAnyChangesInConfig);

                if (isAnyChangesInConfig)
                {
                    doc.Save(configPath);
                }
            }
            else
            {
                XMLNodeBuilder.AddNewSystemDiagnstcs(doc, Resources.ServiceModelTraceConfig);
                doc.Save(configPath);
            }
        }

        /// <summary>
        /// Assembly resolve event handler
        /// </summary>
        /// <param name="sender">sender location</param>
        /// <param name="args">event argument</param>
        /// <returns>return the found assembly</returns>
        private Assembly AssemResolveEventHandler(object sender, ResolveEventArgs args)
        {
            Assembly myAssembly = null;

            string withoutExt = Path.GetDirectoryName(SourcePath);
            string strTempAssmbPath = string.Empty;

            try
            {
                if (args.Name.IndexOf(",") > 0)
                {
                    strTempAssmbPath = Path.Combine(withoutExt, args.Name.Substring(0, args.Name.IndexOf(",")) + ".dll");
                }
                else
                {
                    strTempAssmbPath = args.Name;
                }

                //if (CurrentProcessingItem == strTempAssmbPath)
                //{
                //    return myAssembly;
                //}

                myAssembly = Assembly.Load(File.ReadAllBytes(strTempAssmbPath));
            }
            catch (Exception ex)
            {
                ////not logging because of known error  wrong path args.Name
                //Console.WriteLine(ex.Message);
            }
            ////Load the assembly from the specified path. Return the loaded assembly.
            return myAssembly;
        }
    }
}
