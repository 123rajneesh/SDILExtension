﻿//-----------------------------------------------------------------------
// <copyright file="WCFConsumerData.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace CrossCode.WCF.Analyzer
{
    public struct WCFConsumerData
    {
        public string MethodName { get; set; }
        public string MethodIdentifier { get; set; }
        public string Address { get; set; }
        public string Binding { get; set; }
        public string Contract { get; set; }
    }
}
