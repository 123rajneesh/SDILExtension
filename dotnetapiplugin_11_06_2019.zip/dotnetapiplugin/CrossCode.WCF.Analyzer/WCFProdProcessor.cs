﻿using CrossCode.BLL.Decomposition;
using CrossCode.BLL.Domain;
using CrossCode.BLL.Domain.WCF;

namespace CrossCode.WCF.Analyzer
{
    // Purpose of Analyzer is getting all the core logic of WCF producer and consumer extraction in the case of WCF
    public class WCFProdProcessor
    {

        public static void GetWCFData(string servicePath, ProcessInternetServiceAPIData commServiceData)
        {
            // 1.call the plugin decomposition engine to get the service contract of the wcf processor -- Done
            // 2.Get the servicemodel configuration from web.config/app.config - Done
            // 3.Prepare all the service detailed information
            // 4.Override the url in case of the web application 
            // 5.Map  all the the data in domain structure
            // 6.Return this information to plugin

            commServiceData.WCFData = new ProcessWCFData();
            commServiceData.WCFData.ProducerWCFProducerdata = DecomInitializer.GetWCFProducerAPICollection(servicePath);
        }
        public static void GetWCFConsumerData(string servicePath, string procID, string taskType, ProcessInternetServiceAPIData commServiceData)
        {
            // 1.call the plugin decomposition engine to get the service contract of the wcf processor -- Done
            // 2.Get the servicemodel configuration from web.config/app.config - Done
            // 3.Prepare all the service detailed information
            // 4.Override the url in case of the web application 
            // 5.Map  all the the data in domain structure
            // 6.Return this information to plugin

            commServiceData.WCFData = new ProcessWCFData();
            commServiceData.WCFData.ConsumerWCFConsumerdata = ConsumerExtractStartegy.GetConsumerWCFApiFromStartegy(servicePath, procID, taskType);


        }
    }
}
