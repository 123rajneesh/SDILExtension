#include <windows.h>
#include <cor.h>
#include <corprof.h>
#include "ILRewriteProfilerImpl.h"

extern void WriteLogFile(LPWSTR lpszData);

void CProfilerCallback::WriteMethodInfo(FunctionID functionId, COR_PRF_FUNCTION_ARGUMENT_INFO *pArgInfo)
{
	IMetaDataImport *pMetaDataImport;
	PCCOR_SIGNATURE pSig, p, pParamStart;
	WCHAR           szName[256], szType[256], szValue[256], szBuf[1024];
	ULONG           i;
	CorElementType  type;
	mdMethodDef     methodDef;
	mdTypeDef       typeDef;
	BOOL            bArray, bRef;
	LPVOID          *lplpValue;

	m_pProfilerInfo2->GetTokenAndMetaDataFromFunction(functionId, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport, &methodDef);
	pMetaDataImport->GetMethodProps(methodDef, NULL, szName, 256, NULL, NULL, &pSig, NULL, NULL, NULL);

	p = &pSig[2];
	type = GetElementType(&p, &typeDef, &bRef, &bArray);
	pParamStart = p;
	GetElementTypeName(pMetaDataImport, type, typeDef, bRef, bArray, szType);

	wsprintfW(szBuf, L"%s %s(", szType, szName);

	for (i = 0; i < pArgInfo->numRanges; i++) {
		type = GetElementType(&p, &typeDef, &bRef, &bArray);
		GetElementTypeName(pMetaDataImport, type, typeDef, bRef, bArray, szType);
		lstrcatW(szBuf, szType);
		if (i + 1 != pArgInfo->numRanges)
			lstrcatW(szBuf, L", ");
	}
	lstrcatW(szBuf, L")");
	WriteLogFile(szBuf);

	p = pParamStart;
	for (i = 0; i < pArgInfo->numRanges; i++) {
		lplpValue = (LPVOID *)pArgInfo->ranges[i].startAddress;

		type = GetElementType(&p, &typeDef, &bRef, &bArray);
		GetElementTypeName(pMetaDataImport, type, typeDef, bRef, bArray, szType);

		if (bArray) {
			GetArray(lplpValue, type, szValue);
			wsprintfW(szBuf, L"%s = %s", szType, szValue);
			WriteLogFile(szBuf);
		}
		else if (type == ELEMENT_TYPE_CLASS) {
			ClassID  classId;
			ObjectID oid = *(ObjectID *)(lplpValue);

			m_pProfilerInfo2->GetClassFromObject(oid, &classId);
			GetClass(pMetaDataImport, classId, szType, *lplpValue);
		}
		else if (type == ELEMENT_TYPE_VALUETYPE) {
			ClassID  classId;
			ModuleID moduleId;

			m_pProfilerInfo2->GetFunctionInfo(functionId, 0, &moduleId, 0);
			m_pProfilerInfo2->GetClassFromToken(moduleId, typeDef, &classId);

			GetClass(pMetaDataImport, classId, szType, lplpValue);
		}
		else {
			GetValue(bRef ? *lplpValue : lplpValue, type, szValue);
			wsprintfW(szBuf, L"%s = %s", szType, szValue);
			WriteLogFile(szBuf);
		}
	}

	pMetaDataImport->Release();
}

CorElementType CProfilerCallback::GetElementType(PCCOR_SIGNATURE *ppSig, mdTypeDef *pTypeDef, LPBOOL lpbRef, LPBOOL lpbArray)
{
	CorElementType type = (CorElementType)**ppSig;

	*ppSig += 1;

	if (type == ELEMENT_TYPE_SZARRAY) {
		type = (CorElementType)**ppSig;
		*ppSig += 1;
		*lpbArray = TRUE;
	}
	else
		*lpbArray = FALSE;

	if (type == ELEMENT_TYPE_BYREF) {
		type = (CorElementType)**ppSig;
		*ppSig += 1;
		*lpbRef = TRUE;
	}
	else
		*lpbRef = FALSE;

	if (type == ELEMENT_TYPE_VALUETYPE || type == ELEMENT_TYPE_CLASS)
		*ppSig += CorSigUncompressToken(*ppSig, pTypeDef);
	else
		*pTypeDef = mdTypeDefNil;

	return type;
}

void CProfilerCallback::GetElementTypeName(IMetaDataImport *pMetaDataImport, CorElementType type, mdTypeDef typeDef, BOOL bRef, BOOL bArray, LPWSTR lpszBuf)
{
	WCHAR szType[256];

	if (bArray) {
		GetElementTypeName(pMetaDataImport, type, typeDef, FALSE, FALSE, szType);
		wsprintfW(lpszBuf, L"%s[]", szType);
		return;
	}

	if (type == ELEMENT_TYPE_VALUETYPE || type == ELEMENT_TYPE_CLASS) {
		pMetaDataImport->GetTypeDefProps(typeDef, lpszBuf, 256, NULL, NULL, NULL);
		return;
	}

	if (type == ELEMENT_TYPE_VOID)
		lstrcpyW(szType, L"void");
	else if (type == ELEMENT_TYPE_BOOLEAN)
		lstrcpyW(szType, L"bool");
	else if (type == ELEMENT_TYPE_CHAR)
		lstrcpyW(szType, L"char");
	else if (type == ELEMENT_TYPE_I1)
		lstrcpyW(szType, L"sbyte");
	else if (type == ELEMENT_TYPE_U1)
		lstrcpyW(szType, L"byte");
	else if (type == ELEMENT_TYPE_I2)
		lstrcpyW(szType, L"short");
	else if (type == ELEMENT_TYPE_U2)
		lstrcpyW(szType, L"ushort");
	else if (type == ELEMENT_TYPE_I4)
		lstrcpyW(szType, L"int");
	else if (type == ELEMENT_TYPE_U4)
		lstrcpyW(szType, L"uint");
	else if (type == ELEMENT_TYPE_I8)
		lstrcpyW(szType, L"long");
	else if (type == ELEMENT_TYPE_U8)
		lstrcpyW(szType, L"ulong");
	else if (type == ELEMENT_TYPE_STRING)
		lstrcpyW(szType, L"string");
	else if (type == ELEMENT_TYPE_OBJECT)
		lstrcpyW(szType, L"object");
	else
		wsprintfW(szType, L"unknown-type %x", type);

	if (bRef)
		wsprintfW(lpszBuf, L"ref %s", szType);
	else
		lstrcpyW(lpszBuf, szType);
}

void CProfilerCallback::GetValue(LPVOID lpValue, CorElementType type, LPWSTR lpszBuf)
{
	if (type == ELEMENT_TYPE_VOID)
		lstrcpyW(lpszBuf, L"void");
	else if (type == ELEMENT_TYPE_BOOLEAN) {
		if (*(bool *)lpValue == true)
			lstrcpyW(lpszBuf, L"true");
		else
			lstrcpyW(lpszBuf, L"false");
	}
	else if (type == ELEMENT_TYPE_CHAR)
		wsprintfW(lpszBuf, L"%c", *(char *)lpValue);
	else if (type == ELEMENT_TYPE_I1)
		wsprintfW(lpszBuf, L"%d", *(char *)lpValue);
	else if (type == ELEMENT_TYPE_U1)
		wsprintfW(lpszBuf, L"%u", *(unsigned char *)lpValue);
	else if (type == ELEMENT_TYPE_I2)
		wsprintfW(lpszBuf, L"%d", *(short *)lpValue);
	else if (type == ELEMENT_TYPE_U2)
		wsprintfW(lpszBuf, L"%u", *(unsigned short *)lpValue);
	else if (type == ELEMENT_TYPE_I4)
		wsprintfW(lpszBuf, L"%d", *(int *)lpValue);
	else if (type == ELEMENT_TYPE_U4)
		wsprintfW(lpszBuf, L"%u", *(unsigned int *)lpValue);
	else if (type == ELEMENT_TYPE_I8)
		wsprintfW(lpszBuf, L"%d", *(LONGLONG *)lpValue);
	else if (type == ELEMENT_TYPE_U8)
		wsprintfW(lpszBuf, L"%u", *(ULONGLONG *)lpValue);
	else if (type == ELEMENT_TYPE_STRING)
		lstrcpyW(lpszBuf, GetString(*((LPBYTE *)lpValue)));
	else if (type == ELEMENT_TYPE_CLASS)
		lstrcpyW(lpszBuf, L"---");
	else if (type == ELEMENT_TYPE_VALUETYPE)
		lstrcpyW(lpszBuf, L"---");
	else if (type == ELEMENT_TYPE_OBJECT)
		GetObject(lpValue, type, lpszBuf);
	else
		lstrcpyW(lpszBuf, L"?");
}

LPWSTR CProfilerCallback::GetString(LPBYTE lp)
{
	HRESULT hr;
	LPWSTR  lpString;
	ULONG   uBufferOffset;

	hr = m_pProfilerInfo2->GetStringLayout(NULL, NULL, &uBufferOffset);
	if (FAILED(hr))
		return NULL;

	lpString = (LPWSTR)(lp + uBufferOffset);

	return lpString;
}

void CProfilerCallback::GetArray(LPVOID lpValue, CorElementType type, LPWSTR lpszBuf)
{
	ObjectID oid = *(ObjectID *)(lpValue);
	ULONG32  i, uDimSize;
	int      nDimLowerBound;
	PBYTE    pData;
	WCHAR    szValue[256], szBuf[1024];

	m_pProfilerInfo2->GetArrayObjectInfo(oid, 1, &uDimSize, &nDimLowerBound, &pData);

	lstrcpyW(lpszBuf, L"{");

	for (i = nDimLowerBound; i < uDimSize; i++) {
		GetValue(pData, type, szValue);
		wsprintfW(szBuf, L"%s", szValue);
		if (i + 1 != uDimSize)
			lstrcatW(szBuf, L", ");

		lstrcatW(lpszBuf, szBuf);

		if (type == ELEMENT_TYPE_I4)
			pData += sizeof(int);
		else if (type == ELEMENT_TYPE_CHAR)
			pData += sizeof(char);
		else if (type == ELEMENT_TYPE_I1 || type == ELEMENT_TYPE_U1)
			pData += sizeof(BYTE);
		else if (type == ELEMENT_TYPE_I2 || type == ELEMENT_TYPE_U2)
			pData += sizeof(short);
		else if (type == ELEMENT_TYPE_I4 || type == ELEMENT_TYPE_U4)
			pData += sizeof(int);
		else if (type == ELEMENT_TYPE_I8 || type == ELEMENT_TYPE_U8)
			pData += sizeof(LONGLONG);
		else if (type == ELEMENT_TYPE_BOOLEAN)
			pData += sizeof(bool);
		else if (type == ELEMENT_TYPE_STRING)
			pData += sizeof(ObjectID);
		else if (type == ELEMENT_TYPE_OBJECT)
			pData += sizeof(ObjectID);
		else if (type == ELEMENT_TYPE_CLASS)
			pData += sizeof(ObjectID);
		else
			;
	}

	lstrcatW(lpszBuf, L"}");
}

void CProfilerCallback::GetClass(IMetaDataImport *pMetaDataImport, ClassID classId, LPWSTR lpszClassName, LPVOID lpValue)
{
	WCHAR            szBuf[1024];
	LPBYTE           lpAddress = (LPBYTE)lpValue;
	ULONG            i, uFieldOffsetCount = 0;
	COR_FIELD_OFFSET *pFieldOffset;

	m_pProfilerInfo2->GetClassLayout(classId, NULL, 0, &uFieldOffsetCount, NULL);
	if (uFieldOffsetCount == 0)
		return;

	pFieldOffset = (COR_FIELD_OFFSET *)HeapAlloc(GetProcessHeap(), 0, sizeof(COR_FIELD_OFFSET) * uFieldOffsetCount);
	m_pProfilerInfo2->GetClassLayout(classId, pFieldOffset, uFieldOffsetCount, &uFieldOffsetCount, NULL);

	for (i = 0; i < uFieldOffsetCount; i++) {
		PCCOR_SIGNATURE pSig, p;
		WCHAR           szName[256], szType[256], szValue[256];
		CorElementType  type;
		BOOL            bArray, bRef;
		mdTypeDef       typeDef;

		pMetaDataImport->GetFieldProps(pFieldOffset[i].ridOfField, NULL, szName, 256, NULL, NULL, &pSig, NULL, NULL, NULL, NULL);

		p = &pSig[1];
		type = GetElementType(&p, &typeDef, &bRef, &bArray);
		GetElementTypeName(pMetaDataImport, type, typeDef, bRef, bArray, szType);

		if (bArray)
			GetArray((LPVOID)(lpAddress + pFieldOffset[i].ulOffset), type, szValue);
		else
			GetValue((LPVOID)(lpAddress + pFieldOffset[i].ulOffset), type, szValue);

		wsprintfW(szBuf, L"%s.%s %s = %s", lpszClassName, szType, szName, szValue);
		WriteLogFile(szBuf);
	}

	HeapFree(GetProcessHeap(), 0, pFieldOffset);
}

void CProfilerCallback::GetObject(LPVOID lpValue, CorElementType type, LPWSTR lpszBuf)
{
	HRESULT         hr;
	ClassID         classId;
	ObjectID        oid = *(ObjectID *)(lpValue);
	ModuleID        moduleId;
	mdTypeDef       typeDef;
	ULONG32         uBufferOffset;
	LPVOID          lpAddress;
	WCHAR           szType[256];
	IMetaDataImport *pMetaDataImport;

	m_pProfilerInfo2->GetClassFromObject(oid, &classId);
	hr = m_pProfilerInfo2->GetBoxClassLayout(classId, &uBufferOffset);
	if (SUCCEEDED(hr))
		lpAddress = (LPVOID)(oid + uBufferOffset);
	else
		lpAddress = lpValue;

	m_pProfilerInfo2->GetClassIDInfo(classId, &moduleId, &typeDef);
	m_pProfilerInfo2->GetModuleMetaData(moduleId, ofRead, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport);
	pMetaDataImport->GetTypeDefProps(typeDef, szType, 256, NULL, NULL, NULL);
	pMetaDataImport->Release();

	type = GetElementTypeFromClassName(szType);

	GetValue(lpAddress, type, lpszBuf);
}

CorElementType CProfilerCallback::GetElementTypeFromClassName(LPWSTR lpszClassName)
{
	CorElementType type;

	if (lstrcmpW(lpszClassName, L"System.Boolean") == 0)
		type = ELEMENT_TYPE_BOOLEAN;
	else if (lstrcmpW(lpszClassName, L"System.Char") == 0)
		type = ELEMENT_TYPE_CHAR;
	else if (lstrcmpW(lpszClassName, L"System.SByte") == 0)
		type = ELEMENT_TYPE_I1;
	else if (lstrcmpW(lpszClassName, L"System.Byte") == 0)
		type = ELEMENT_TYPE_U1;
	else if (lstrcmpW(lpszClassName, L"System.Int16") == 0)
		type = ELEMENT_TYPE_I2;
	else if (lstrcmpW(lpszClassName, L"System.UInt16") == 0)
		type = ELEMENT_TYPE_U2;
	else if (lstrcmpW(lpszClassName, L"System.Int32") == 0)
		type = ELEMENT_TYPE_I4;
	else if (lstrcmpW(lpszClassName, L"System.UInt32") == 0)
		type = ELEMENT_TYPE_U4;
	else if (lstrcmpW(lpszClassName, L"System.Int64") == 0)
		type = ELEMENT_TYPE_I8;
	else if (lstrcmpW(lpszClassName, L"System.UInt64") == 0)
		type = ELEMENT_TYPE_U8;
	else if (lstrcmpW(lpszClassName, L"System.String") == 0)
		type = ELEMENT_TYPE_STRING;
	else
		type = ELEMENT_TYPE_END;

	return type;
}

BOOL CProfilerCallback::FilterClass(FunctionID functionId, LPWSTR lpszFilterClassName)
{
	IMetaDataImport *pMetaDataImport;
	mdMethodDef     methodDef;
	mdTypeDef       typeDef;
	WCHAR           szClassName[256];

	m_pProfilerInfo2->GetTokenAndMetaDataFromFunction(functionId, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport, &methodDef);
	pMetaDataImport->GetMethodProps(methodDef, &typeDef, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
	pMetaDataImport->GetTypeDefProps(typeDef, szClassName, 256, NULL, NULL, NULL);
	pMetaDataImport->Release();

	return lstrcmpW(szClassName, lpszFilterClassName) == 0;
}

void CProfilerCallback::GetFullMethodName(FunctionID functionId, LPWSTR lpszFunctionName)
{
	IMetaDataImport *pMetaDataImport;
	mdMethodDef     methodDef;
	mdTypeDef       typeDef;
	WCHAR           szName[256], szClassName[256];

	m_pProfilerInfo2->GetTokenAndMetaDataFromFunction(functionId, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport, &methodDef);
	pMetaDataImport->GetMethodProps(methodDef, &typeDef, szName, 256, NULL, NULL, NULL, NULL, NULL, NULL);
	pMetaDataImport->GetTypeDefProps(typeDef, szClassName, 256, NULL, NULL, NULL);
	pMetaDataImport->Release();

	wsprintfW(lpszFunctionName, L"%s.%s", szClassName, szName);
}