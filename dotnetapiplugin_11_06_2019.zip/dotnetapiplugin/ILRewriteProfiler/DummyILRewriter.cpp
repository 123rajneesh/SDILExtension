// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#include "stdafx.h"
#include "DummyILRewriter.h"
#include "FunctionInfo.h"
#include "ILRewriteHelper.h"


DummyILRewriter::DummyILRewriter()
{

}

DummyILRewriter::DummyILRewriter(ICorProfilerInfo* info, FunctionInfo* functionInfo, LPCBYTE oldMethodBytes, ULONG oldMethodSize)
{
    m_info = info;
	m_functionInfo = functionInfo;
	m_oldMethodBytes = oldMethodBytes;
	m_oldMethodSize = oldMethodSize;
}

DummyILRewriter::~DummyILRewriter()
{

}

bool DummyILRewriter::CanRewrite()
{
   return true;
}

LPCBYTE DummyILRewriter::GetNewILBytes()
{
   ULONG size = this->GetOldMethodSize();
   BYTE* newBytes = reinterpret_cast<BYTE*>(ILRewriteHelper::AllocateNewMethodBody(m_info, m_functionInfo->GetModuleID(), size));
   memcpy(newBytes, this->GetOldMethodBytes(), size);
	return newBytes;
}

ULONG DummyILRewriter::GetNewMethodSize()
{
	return this->GetOldMethodSize();
}

ULONG DummyILRewriter::GetOldMethodSize()
{
	return m_oldMethodSize;
}

LPCBYTE DummyILRewriter::GetOldMethodBytes()
{
	return m_oldMethodBytes;
}
