// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------


#include "stdafx.h"

#include <cor.h>
#include <corprof.h>
#include <string.h>

#include "FunctionInfo.h"

FunctionInfo::FunctionInfo()
{
   functionID = 0;
   classID = 0;
   moduleID = 0;
   token = 0;
   className[0] = L'\0';
   functionName[0] = L'\0';
   assemblyName[0] = L'\0';
}

FunctionInfo::FunctionInfo(FunctionID functionID, ClassID classID, ModuleID moduleID, mdToken token, LPWSTR functionName, LPWSTR className, LPWSTR assemblyName)
{
   this->functionID = functionID;
   this->classID = classID;
   this->moduleID = moduleID;
   this->token = token;
   wcscpy_s(this->functionName, functionName);
   wcscpy_s(this->className, className);
   wcscpy_s(this->assemblyName, assemblyName);
}

FunctionInfo::~FunctionInfo()
{
   functionID = 0;
   classID = 0;
   moduleID = 0;
   token = 0;
   className[0] = L'\0';
   functionName[0] = L'\0';
   assemblyName[0] = L'\0';
}

FunctionInfo* FunctionInfo::GetNullObject()
{
   static FunctionInfo nullObjectFunctionInfo;
   return &nullObjectFunctionInfo;
}