// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#pragma once

#include <cor.h>
#include <corprof.h>
#include <sstream>

class ILRewriter;
struct FunctionInfo;
class PreludeILRewriter;

class ILRewriteHelper
{
public:
   ILRewriteHelper();
   ILRewriteHelper(ICorProfilerInfo* info);
   ~ILRewriteHelper();
   ILRewriter* CreateILRewriter(PreludeILRewriter* preludeILRewriter, FunctionInfo* functionInfo);
   FunctionInfo* CreateFunctionInfo(FunctionID functionID);
   PCCOR_SIGNATURE ILRewriteHelper::ParseSignature( IMetaDataImport *metaDataImport, PCCOR_SIGNATURE signature, std::wstringstream& signatureText);
   void SetCorProfilerInfo(ICorProfilerInfo* info);
   //HRESULT ResolveMethod(ModuleID moduleID, const wchar_t* assemblyName, const BYTE* keyEMCA, const wchar_t* fullyQualifiedClassName, const wchar_t* methodName, mdMemberRef* outMemberRef);
   //ReplaceFunction DeclareMethod(ModuleID moduleID, const wchar_t* assemblyName, const BYTE* keyEMCA, const wchar_t* fullyQualifiedClassName, const wchar_t* methodName, mdTypeRef retType);
   static void* AllocateNewMethodBody(ICorProfilerInfo* info, ModuleID moduleId, ULONG newMethodSize);

private:
   ICorProfilerInfo* m_info;
   bool IsTiny(LPCBYTE methodBytes);
   static void Check(HRESULT hr);
   static bool OptionalCheck(HRESULT hr);

   mdTypeDef m_systemObjectTypeDef;
   mdTypeDef m_systemDateTimeTypeDef;
   mdMethodDef m_replaceFunctionToken;
   ModuleID m_mscorlibModuleID;
};
