// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------


#include "stdafx.h"
#include <string>
#include "ILRewriteProfilerImpl.h"
#include "StringHelper.h"
#include "ProfilerLoggers.h"
#include "ILRewriter.h"
#include "FunctionInfo.h"
#include "OpCodeParser.h"
#include "MetadataHelper.h"
#include "InterceptAPI.h"
#include <shlwapi.h>
#include <shlobj.h>
using namespace std;
//#include "ILRewriteConsoleLogger.h"
//#include "ILRewriteDebugLogger.h"

//#include <wchar.h>
#include <corhlpr.h>
#include <memory>

#pragma comment(lib, "CorGuids.lib")

ILRewriteProfilerImpl *g_pProfilerCallback;
CRITICAL_SECTION g_cs_ilRewite;
CRITICAL_SECTION  g_cs;

void __stdcall MyFunctionEnter2(FunctionID functionID, UINT_PTR clientData, COR_PRF_FRAME_INFO func, COR_PRF_FUNCTION_ARGUMENT_INFO *argumentInfo);

void __stdcall MyFunctionLeave2(FunctionID functionID, UINT_PTR   clientData, COR_PRF_FRAME_INFO  func, COR_PRF_FUNCTION_ARGUMENT_INFO   *argumentInfo);


void WriteLogFile(LPWSTR lpszData);

class FunctionCallInfo
{
public:
	wstring ModuleName;
	wstring ClassName;
	wstring MethodName;
	wstring fullname() const
	{
		return ModuleName + L"!" + ClassName + L"." + MethodName;
	}
	int nEnter;
	int nLeave;
	int TicksAtEntry;
	int TicksTotal;
};

void WriteLogFile(LPWSTR lpszData)
{
	g_debugLogger.WriteLine("WriteLogFile -start");

	TCHAR  szFileName[] = TEXT("\\profile.txt");
	TCHAR  szDesktopPath[MAX_PATH];
	WCHAR  szBuf[1024];
	HANDLE hFile;
	DWORD  dwResult;

	SHGetSpecialFolderPath(NULL, szDesktopPath, CSIDL_DESKTOPDIRECTORY, FALSE);
	lstrcat(szDesktopPath, szFileName);

	g_debugLogger << "Desktop Path" << szDesktopPath;

	g_debugLogger.WriteLine("WriteLogFile -step 1");
	EnterCriticalSection(&g_cs);

	g_debugLogger.WriteLine("WriteLogFile -step 1 - 0");
	hFile = CreateFile(szDesktopPath, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	g_debugLogger.WriteLine("WriteLogFile -step 1 - 1");

	if (hFile == INVALID_HANDLE_VALUE) {
		g_debugLogger.WriteLine("WriteLogFile -step 1 - 2");
		LeaveCriticalSection(&g_cs);
		return;
	}

	g_debugLogger.WriteLine("WriteLogFile -step 2");

	SetFilePointer(hFile, 0, NULL, FILE_END);

	wsprintfW(szBuf, L"%s\r\n", lpszData);

	g_debugLogger << "lpszData" <<lpszData<<std::endl;
	WriteFile(hFile, szBuf, lstrlenW(szBuf) * sizeof(WCHAR), &dwResult, NULL);

	CloseHandle(hFile);

	LeaveCriticalSection(&g_cs);

	g_debugLogger.WriteLine("WriteLogFile -End");

}

_declspec(naked) void __stdcall MyFunctionEnter(FunctionID funcId, UINT_PTR clientData,COR_PRF_FRAME_INFO func,COR_PRF_FUNCTION_ARGUMENT_INFO *argumentInfo)
{
	_asm {
		push ebp
		mov ebp, esp
		pushad
		mov   eax, [ebp + 0x14]   //argumentInfo
		push  eax
		mov   ecx, [ebp + 0x10]   //func
		push  ecx
		mov   edx, [ebp + 0x0C]   //clientData
		push  edx
		mov   eax, [ebp + 0x08]   //funcID
		push  eax
		call MyFunctionEnter2
		popad
		pop ebp
		ret 16
	}
}
void __stdcall MyFunctionEnter2(/*[in]*/FunctionID functionID,/*[in]*/UINT_PTR clientData,/*[in]*/COR_PRF_FRAME_INFO func,
								/*[in]*/COR_PRF_FUNCTION_ARGUMENT_INFO   *argumentInfo)
{
	g_debugLogger.WriteLine("MyFunctionEnter2::MyFunctionEnter2");

	//if (g_pProfilerCallback != NULL) {
	//	WCHAR szName[256];// , szBuf[1024];

	//	g_debugLogger.WriteLine("MyFunctionEnter2::g_pProfilerCallback");

	//	g_pProfilerCallback->GetFullMethodName(functionID, szName);
	//	g_debugLogger << "MyFunctionEnter2 :Full Name of Method = " << szName << std::endl;

	//	if (!lstrcmpW(szName, L"System.Net.Http.HttpRequestMessage.get_RequestUri") == 0)//!g_pProfilerCallback->FilterClass(functionID, L"System.Net.Http:HttpClient"))
	//	{
	//		g_debugLogger << "Not found the class.";
	//		return;
	//	}

	//	g_debugLogger.WriteLine("g_pProfilerCallback->FilterClass- Method found");

	//	//g_pProfilerCallback->GetFullMethodName(functionID, szName);
	//	try
	//	{
	//		/*wsprintfW(szBuf, L"--------Enter %s--------", szName);
	//		g_debugLogger << "wsprintfW(szBuf, L"", szName);.";
	//		WriteLogFile(szBuf);*/

	//		//g_pProfilerCallback->WriteMethodInfo(functionID, argumentInfo);

	//	}
	//	catch (const char* msg)
	//	{
	//	}
	//}
	g_debugLogger.WriteLine("MyFunctionEnter2::Exit");
}



_declspec(naked) void __stdcall MyFunctionLeave(FunctionID funcId,UINT_PTR clientData,COR_PRF_FRAME_INFO func,COR_PRF_FUNCTION_ARGUMENT_RANGE *retvalRange
)
{
	_asm {
		push ebp
		mov ebp, esp
		pushad
		mov   eax, [ebp + 0x14]   //argumentInfo
		push  eax
		mov   ecx, [ebp + 0x10]   //func
		push  ecx
		mov   edx, [ebp + 0x0C]   //clientData
		push  edx
		mov   eax, [ebp + 0x08]   //funcID
		push  eax
		call MyFunctionLeave2
		popad
		pop ebp
		ret 16
	}
}

void __stdcall MyFunctionLeave2(FunctionID functionID,UINT_PTR   clientData,COR_PRF_FRAME_INFO  func,COR_PRF_FUNCTION_ARGUMENT_INFO   *argumentInfo)
{
	IMetaDataImport *pMetaDataImport;
	PCCOR_SIGNATURE pSig, p, pParamStart;
	WCHAR           szName[256], szType[256], szValue[256], szBuf[1024];
	ULONG           i;
	CorElementType  type;
	mdMethodDef     methodDef;
	mdTypeDef       typeDef;
	BOOL            bArray, bRef;
	LPVOID          *lplpValue;


	g_pProfilerCallback->GetFullMethodName(functionID, szName);

	g_debugLogger << "MyFunctionEnter2 :Full Name of Method = " << szName << std::endl;

	if (!lstrcmpW(szName, L"System.Net.Http.HttpRequestMessage.get_RequestUri") == 0)//!g_pProfilerCallback->FilterClass(functionID, L"System.Net.Http:HttpClient"))
	{
		g_debugLogger << "Not found the class." << std::endl;
		return;
	}

	/*m_corProfilerInfo2->GetTokenAndMetaDataFromFunction(functionID, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport, &methodDef);
	pMetaDataImport->GetMethodProps(methodDef, NULL, szName, 256, NULL, NULL, &pSig, NULL, NULL, NULL);

	p = &pSig[2];
	type = GetElementType(&p, &typeDef, &bRef, &bArray);*/

	//throw;

	//g_debugLogger << "MyFunctionLeave2::WriteMethodInfo" << std::endl;

	//lplpValue = (LPVOID *)argumentInfo->ranges[0].startAddress;

	g_pProfilerCallback->WriteMethodInfo(functionID, argumentInfo);
	

	/*FunctionCallInfo *pFunctionCallInfo = nullptr;
	g_csectFunctionMap.Lock();
	auto res = g_MapFunctionCalls.find(functionID);
	if (res != g_MapFunctionCalls.end())
	{
		pFunctionCallInfo = &res->second;
		pFunctionCallInfo->nLeave++;
		pFunctionCallInfo->TicksTotal += GetTickCount() - pFunctionCallInfo->TicksAtEntry;
	}
	else
	{
		auto x = 2;
	}
	g_csectFunctionMap.Unlock();*/
}
void ILRewriteProfilerImpl::Check(HRESULT hr)
{
   if (hr != S_OK)
      throw "HRESULT is != S_OK";
}

void ILRewriteProfilerImpl::WriteMethodInfo(FunctionID functionId, COR_PRF_FUNCTION_ARGUMENT_INFO *pArgInfo)
{
	IMetaDataImport *pMetaDataImport;
	PCCOR_SIGNATURE pSig, p, pParamStart;
	WCHAR           szName[256], szType[256], szValue[256], szBuf[1024];
	ULONG           i,sequence;
	CorElementType  type;
	mdMethodDef     methodDef;
	mdTypeDef       typeDef;
	BOOL            bArray, bRef;
	LPVOID          *lplpValue;
	mdParamDef       paramDef;
	LPWSTR           szParamNAme;

	g_debugLogger << "WriteMethodInfo" << std::endl;

	m_corProfilerInfo2->GetTokenAndMetaDataFromFunction(functionId, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport, &methodDef);
	pMetaDataImport->GetMethodProps(methodDef, NULL, szName, 256, NULL, NULL, &pSig, NULL, NULL, NULL);

	//pMetaDataImport->GetParamForMethodIndex(methodDef, sequence, &paramDef);
	//pMetaDataImport->GetParamProps(paramDef,methodDef)

	p = &pSig[2]; 
	pParamStart = p;
	
	g_debugLogger << "numRanges = " << pArgInfo->numRanges <<"totalArgumentsize " <<pArgInfo->totalArgumentSize << std::endl;

	p = pParamStart;

	for (i = 0; i < pArgInfo->numRanges; i++) {
		lplpValue = (LPVOID *)pArgInfo->ranges[i].startAddress;

		type = GetElementType(&p, &typeDef, &bRef, &bArray);
		GetElementTypeName(pMetaDataImport, type, typeDef, bRef, bArray, szType);
		
		g_debugLogger << "GetElementTypeName called" << std::endl;

		if (bArray) {

			g_debugLogger << "bArray = true " <<  std::endl;
			GetArray(lplpValue, type, szValue);
			wsprintfW(szBuf, L"%s = %s", szType, szValue);
			g_debugLogger << "bArray " << szType <<" "<< szValue << std::endl;
			//WriteLogFile(szBuf);
		}
		else if (type == ELEMENT_TYPE_CLASS) {
			g_debugLogger << "bArray = ELEMENT_TYPE_CLASS " << std::endl;

			ClassID  classId;
			g_debugLogger << "Going to convert in objectID" << std::endl;

			ObjectID oid = *(ObjectID*)(lplpValue);

			g_debugLogger << "ObjectID oid = *(ObjectID *)(lplpValue); " << std::endl;
			m_corProfilerInfo2->GetClassFromObject(oid, &classId);
			g_debugLogger << "_corProfilerInfo2->GetClassFromObject(oid, &classId) " << std::endl;

			GetClass(pMetaDataImport, classId, szType, *lplpValue);

			g_debugLogger << "GetClass finished" << szType << " " << classId << std::endl;

		}
		else if (type == ELEMENT_TYPE_VALUETYPE) {

			g_debugLogger << "bArray = ELEMENT_TYPE_VALUETYPE " << std::endl;
			ClassID  classId;
			ModuleID moduleId;

			m_corProfilerInfo2->GetFunctionInfo(functionId, 0, &moduleId, 0);
			m_corProfilerInfo2->GetClassFromToken(moduleId, typeDef, &classId);

			GetClass(pMetaDataImport, classId, szType, lplpValue);

		}
		else {

			g_debugLogger << "bArray = else  " << std::endl;

			GetValue(bRef ? *lplpValue : lplpValue, type, szValue);

			g_debugLogger << "wsprintfW(szBuf, L, szType, szValue);" << szType<< "  "<<szValue <<std::endl;

			//WriteLogFile(szBuf);
		}
	}

	g_debugLogger << "pMetaDataImport->Release();" << std::endl;

	pMetaDataImport->Release();
}

void ILRewriteProfilerImpl::WriteMethodInfo(FunctionID functionId, COR_PRF_FRAME_INFO func, COR_PRF_FUNCTION_ARGUMENT_INFO * pArgInfo)
{
	IMetaDataImport *pMetaDataImport;
	PCCOR_SIGNATURE pSig, p, pParamStart;
	WCHAR           szName[256], szType[256], szValue[256], szBuf[1024];
	ULONG           i;
	CorElementType  type;
	mdMethodDef     methodDef;
	mdTypeDef       typeDef;
	BOOL            bArray, bRef;
	LPVOID          *lplpValue;


	g_debugLogger << "WriteMethodInfo" << std::endl;

	m_corProfilerInfo2->GetTokenAndMetaDataFromFunction(functionId, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport, &methodDef);
	pMetaDataImport->GetMethodProps(methodDef, NULL, szName, 256, NULL, NULL, &pSig, NULL, NULL, NULL);

	p = &pSig[2];
	pParamStart = p;

	g_debugLogger << "numRanges = " << pArgInfo->numRanges << "totalArgumentsize " << pArgInfo->totalArgumentSize << std::endl;

	p = pParamStart;

	for (i = 0; i < pArgInfo->numRanges; i++) {
		lplpValue = (LPVOID *)pArgInfo->ranges[i].startAddress;

		type = GetElementType(&p, &typeDef, &bRef, &bArray);
		GetElementTypeName(pMetaDataImport, type, typeDef, bRef, bArray, szType);

		g_debugLogger << "GetElementTypeName called" << std::endl;


		if (bArray) {

			g_debugLogger << "bArray = true " << std::endl;
			GetArray(lplpValue, type, szValue);
			wsprintfW(szBuf, L"%s = %s", szType, szValue);
			g_debugLogger << "bArray " << szType << " " << szValue << std::endl;
			//WriteLogFile(szBuf);
		}
		else if (type == ELEMENT_TYPE_CLASS) {
			ClassID  classId;
			ObjectID oid = *(ObjectID *)(lplpValue);

			m_corProfilerInfo2->GetClassFromObject(oid, &classId);
			GetClass(pMetaDataImport, classId, szType, *lplpValue);

		}
		else if (type == ELEMENT_TYPE_VALUETYPE) {

			g_debugLogger << "bArray = ELEMENT_TYPE_VALUETYPE " << std::endl;
			ClassID  classId;
			ModuleID moduleId;

			m_corProfilerInfo2->GetFunctionInfo(functionId, 0, &moduleId, 0);
			m_corProfilerInfo2->GetClassFromToken(moduleId, typeDef, &classId);

			GetClass(pMetaDataImport, classId, szType, lplpValue);

		}
		else {

			g_debugLogger << "bArray = else  " << std::endl;

			GetValue(bRef ? *lplpValue : lplpValue, type, szValue);

			g_debugLogger << "wsprintfW(szBuf, L, szType, szValue);" << szType << "  " << szValue << std::endl;

			//WriteLogFile(szBuf);
		}
	}

	g_debugLogger << "pMetaDataImport->Release();" << std::endl;

}

CorElementType ILRewriteProfilerImpl::GetElementType(PCCOR_SIGNATURE *ppSig, mdTypeDef *pTypeDef, LPBOOL lpbRef, LPBOOL lpbArray)
{
	g_debugLogger << "ILRewriteProfilerImpl::GetElementType -start;" << std::endl;

	CorElementType type = (CorElementType)**ppSig;

	*ppSig += 1;

	if (type == ELEMENT_TYPE_SZARRAY) {
		type = (CorElementType)**ppSig;
		*ppSig += 1;
		*lpbArray = TRUE;
	}
	else
		*lpbArray = FALSE;

	if (type == ELEMENT_TYPE_BYREF) {
		type = (CorElementType)**ppSig;
		*ppSig += 1;
		*lpbRef = TRUE;
	}
	else
		*lpbRef = FALSE;

	if (type == ELEMENT_TYPE_VALUETYPE || type == ELEMENT_TYPE_CLASS)
		*ppSig += CorSigUncompressToken(*ppSig, pTypeDef);
	else
		*pTypeDef = mdTypeDefNil;

	g_debugLogger << "ILRewriteProfilerImpl::GetElementType -End line;" << std::endl;

	return type;
}

void ILRewriteProfilerImpl::GetElementTypeName(IMetaDataImport *pMetaDataImport, CorElementType type, mdTypeDef typeDef, BOOL bRef, BOOL bArray, LPWSTR lpszBuf)
{
	g_debugLogger << "GetElementTypeName -start" << std::endl;

	WCHAR szType[256];

	if (bArray) {

		g_debugLogger << "bArray" << bArray<< std::endl;

		GetElementTypeName(pMetaDataImport, type, typeDef, FALSE, FALSE, szType);
		//wsprintfW(lpszBuf, L"%s[]", szType);
		return;
	}

	if (type == ELEMENT_TYPE_VALUETYPE || type == ELEMENT_TYPE_CLASS) {
		g_debugLogger << "type == ELEMENT_TYPE_VALUETYPE || type == ELEMENT_TYPE_CLASS" << type << std::endl;

		pMetaDataImport->GetTypeDefProps(typeDef, lpszBuf, 256, NULL, NULL, NULL);

		g_debugLogger << "retutn " << std::endl;

		return;
	}

	g_debugLogger << "findTheType "  << std::endl;

	if (type == ELEMENT_TYPE_VOID)
		lstrcpyW(szType, L"void");
	else if (type == ELEMENT_TYPE_BOOLEAN)
		lstrcpyW(szType, L"bool");
	else if (type == ELEMENT_TYPE_CHAR)
		lstrcpyW(szType, L"char");
	else if (type == ELEMENT_TYPE_I1)
		lstrcpyW(szType, L"sbyte");
	else if (type == ELEMENT_TYPE_U1)
		lstrcpyW(szType, L"byte");
	else if (type == ELEMENT_TYPE_I2)
		lstrcpyW(szType, L"short");
	else if (type == ELEMENT_TYPE_U2)
		lstrcpyW(szType, L"ushort");
	else if (type == ELEMENT_TYPE_I4)
		lstrcpyW(szType, L"int");
	else if (type == ELEMENT_TYPE_U4)
		lstrcpyW(szType, L"uint");
	else if (type == ELEMENT_TYPE_I8)
		lstrcpyW(szType, L"long");
	else if (type == ELEMENT_TYPE_U8)
		lstrcpyW(szType, L"ulong");
	else if (type == ELEMENT_TYPE_STRING)
		lstrcpyW(szType, L"string");
	else if (type == ELEMENT_TYPE_OBJECT)
		lstrcpyW(szType, L"object");
	else
		wsprintfW(szType, L"unknown-type %x", type);

	if (bRef)
		wsprintfW(lpszBuf, L"ref %s", szType);
	else
		lstrcpyW(lpszBuf, szType);


	g_debugLogger << "GetElementTypeName -End = " << szType<< std::endl;
}

void ILRewriteProfilerImpl::GetValue(LPVOID lpValue, CorElementType type, LPWSTR lpszBuf)
{
	g_debugLogger << "GetValue - Start - type = " << type << std::endl;

	if (type == ELEMENT_TYPE_VOID)
		lstrcpyW(lpszBuf, L"void");
	else if (type == ELEMENT_TYPE_BOOLEAN) {
		if (*(bool *)lpValue == true)
			lstrcpyW(lpszBuf, L"true");
		else
			lstrcpyW(lpszBuf, L"false");
	}
	else if (type == ELEMENT_TYPE_CHAR)
		wsprintfW(lpszBuf, L"%c", *(char *)lpValue);
	else if (type == ELEMENT_TYPE_I1)
		wsprintfW(lpszBuf, L"%d", *(char *)lpValue);
	else if (type == ELEMENT_TYPE_U1)
		wsprintfW(lpszBuf, L"%u", *(unsigned char *)lpValue);
	else if (type == ELEMENT_TYPE_I2)
		wsprintfW(lpszBuf, L"%d", *(short *)lpValue);
	else if (type == ELEMENT_TYPE_U2)
		wsprintfW(lpszBuf, L"%u", *(unsigned short *)lpValue);
	else if (type == ELEMENT_TYPE_I4)
		wsprintfW(lpszBuf, L"%d", *(int *)lpValue);
	else if (type == ELEMENT_TYPE_U4)
		wsprintfW(lpszBuf, L"%u", *(unsigned int *)lpValue);
	else if (type == ELEMENT_TYPE_I8)
		wsprintfW(lpszBuf, L"%d", *(LONGLONG *)lpValue);
	else if (type == ELEMENT_TYPE_U8)
		wsprintfW(lpszBuf, L"%u", *(ULONGLONG *)lpValue);
	else if (type == ELEMENT_TYPE_STRING)
		lstrcpyW(lpszBuf, GetString(*((LPBYTE *)lpValue)));
	else if (type == ELEMENT_TYPE_CLASS)
		lstrcpyW(lpszBuf, L"---");
	else if (type == ELEMENT_TYPE_VALUETYPE)
		lstrcpyW(lpszBuf, L"---");
	else if (type == ELEMENT_TYPE_OBJECT)
		GetObject(lpValue, type, lpszBuf);
	else
		lstrcpyW(lpszBuf, L"?");


	g_debugLogger << "GetValue - End - type = " << std::endl;
}

LPWSTR ILRewriteProfilerImpl::GetString(LPBYTE lp)
{
	HRESULT hr;
	LPWSTR  lpString;
	ULONG   uBufferOffset;

	hr = m_corProfilerInfo2->GetStringLayout(NULL, NULL, &uBufferOffset);
	if (FAILED(hr))
		return NULL;

	lpString = (LPWSTR)(lp + uBufferOffset);

	return lpString;
}

void ILRewriteProfilerImpl::GetArray(LPVOID lpValue, CorElementType type, LPWSTR lpszBuf)
{
	ObjectID oid = *(ObjectID *)(lpValue);
	ULONG32  i, uDimSize;
	int      nDimLowerBound;
	PBYTE    pData;
	WCHAR    szValue[256], szBuf[1024];

	m_corProfilerInfo2->GetArrayObjectInfo(oid, 1, &uDimSize, &nDimLowerBound, &pData);

	lstrcpyW(lpszBuf, L"{");

	for (i = nDimLowerBound; i < uDimSize; i++) {
		GetValue(pData, type, szValue);
		wsprintfW(szBuf, L"%s", szValue);
		if (i + 1 != uDimSize)
			lstrcatW(szBuf, L", ");

		lstrcatW(lpszBuf, szBuf);

		if (type == ELEMENT_TYPE_I4)
			pData += sizeof(int);
		else if (type == ELEMENT_TYPE_CHAR)
			pData += sizeof(char);
		else if (type == ELEMENT_TYPE_I1 || type == ELEMENT_TYPE_U1)
			pData += sizeof(BYTE);
		else if (type == ELEMENT_TYPE_I2 || type == ELEMENT_TYPE_U2)
			pData += sizeof(short);
		else if (type == ELEMENT_TYPE_I4 || type == ELEMENT_TYPE_U4)
			pData += sizeof(int);
		else if (type == ELEMENT_TYPE_I8 || type == ELEMENT_TYPE_U8)
			pData += sizeof(LONGLONG);
		else if (type == ELEMENT_TYPE_BOOLEAN)
			pData += sizeof(bool);
		else if (type == ELEMENT_TYPE_STRING)
			pData += sizeof(ObjectID);
		else if (type == ELEMENT_TYPE_OBJECT)
			pData += sizeof(ObjectID);
		else if (type == ELEMENT_TYPE_CLASS)
			pData += sizeof(ObjectID);
		else
			;
	}

	lstrcatW(lpszBuf, L"}");
}

void ILRewriteProfilerImpl::GetClass(IMetaDataImport *pMetaDataImport, ClassID classId, LPWSTR lpszClassName, LPVOID lpValue)
{
	g_debugLogger << "GetClass -start = " << std::endl;

	WCHAR            szBuf[1024];
	LPBYTE           lpAddress = (LPBYTE)lpValue;
	ULONG            i, uFieldOffsetCount = 0;
	COR_FIELD_OFFSET *pFieldOffset;

	m_corProfilerInfo2->GetClassLayout(classId, NULL, 0, &uFieldOffsetCount, NULL);
	if (uFieldOffsetCount == 0)
	{
		g_debugLogger << "uFieldOffsetCount == 0" << std::endl;
		return;
	}

	pFieldOffset = (COR_FIELD_OFFSET *)HeapAlloc(GetProcessHeap(), 0, sizeof(COR_FIELD_OFFSET) * uFieldOffsetCount);
	m_corProfilerInfo2->GetClassLayout(classId, pFieldOffset, uFieldOffsetCount, &uFieldOffsetCount, NULL);

	g_debugLogger << "for (i = 0; i < uFieldOffsetCount; i++) {" << std::endl;

	for (i = 0; i < uFieldOffsetCount; i++) {

		g_debugLogger << "Start loop -uFieldOffsetCount" << uFieldOffsetCount<< std::endl;

		PCCOR_SIGNATURE pSig, p;
		WCHAR           szName[256], szType[256], szValue[256];
		CorElementType  type;
		BOOL            bArray, bRef;
		mdTypeDef       typeDef;

		pMetaDataImport->GetFieldProps(pFieldOffset[i].ridOfField, NULL, szName, 256, NULL, NULL, &pSig, NULL, NULL, NULL, NULL);

		p = &pSig[1];
		type = GetElementType(&p, &typeDef, &bRef, &bArray);
		GetElementTypeName(pMetaDataImport, type, typeDef, bRef, bArray, szType);

		if (bArray)
			GetArray((LPVOID)(lpAddress + pFieldOffset[i].ulOffset), type, szValue);
		else
			GetValue((LPVOID)(lpAddress + pFieldOffset[i].ulOffset), type, szValue);

		wsprintfW(szBuf, L"%s.%s %s = %s", lpszClassName, szType, szName, szValue);
		//WriteLogFile(szBuf);

		g_debugLogger << "End loop -szType - szName - szValue " << szType << " "<<szName <<"  "<< szValue <<std::endl;
	}

	HeapFree(GetProcessHeap(), 0, pFieldOffset);

	g_debugLogger << "GetClass -End = " << std::endl;
}

void ILRewriteProfilerImpl::GetObject(LPVOID lpValue, CorElementType type, LPWSTR lpszBuf)
{
	HRESULT         hr;
	ClassID         classId;
	ObjectID        oid = *(ObjectID *)(lpValue);
	ModuleID        moduleId;
	mdTypeDef       typeDef;
	ULONG32         uBufferOffset;
	LPVOID          lpAddress;
	WCHAR           szType[256];
	IMetaDataImport *pMetaDataImport;

	m_corProfilerInfo2->GetClassFromObject(oid, &classId);
	hr = m_corProfilerInfo2->GetBoxClassLayout(classId, &uBufferOffset);
	if (SUCCEEDED(hr))
		lpAddress = (LPVOID)(oid + uBufferOffset);
	else
		lpAddress = lpValue;

	m_corProfilerInfo2->GetClassIDInfo(classId, &moduleId, &typeDef);
	m_corProfilerInfo2->GetModuleMetaData(moduleId, ofRead, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport);
	pMetaDataImport->GetTypeDefProps(typeDef, szType, 256, NULL, NULL, NULL);
	pMetaDataImport->Release();

	type = GetElementTypeFromClassName(szType);

	GetValue(lpAddress, type, lpszBuf);
}

CorElementType ILRewriteProfilerImpl::GetElementTypeFromClassName(LPWSTR lpszClassName)
{
	CorElementType type;

	if (lstrcmpW(lpszClassName, L"System.Boolean") == 0)
		type = ELEMENT_TYPE_BOOLEAN;
	else if (lstrcmpW(lpszClassName, L"System.Char") == 0)
		type = ELEMENT_TYPE_CHAR;
	else if (lstrcmpW(lpszClassName, L"System.SByte") == 0)
		type = ELEMENT_TYPE_I1;
	else if (lstrcmpW(lpszClassName, L"System.Byte") == 0)
		type = ELEMENT_TYPE_U1;
	else if (lstrcmpW(lpszClassName, L"System.Int16") == 0)
		type = ELEMENT_TYPE_I2;
	else if (lstrcmpW(lpszClassName, L"System.UInt16") == 0)
		type = ELEMENT_TYPE_U2;
	else if (lstrcmpW(lpszClassName, L"System.Int32") == 0)
		type = ELEMENT_TYPE_I4;
	else if (lstrcmpW(lpszClassName, L"System.UInt32") == 0)
		type = ELEMENT_TYPE_U4;
	else if (lstrcmpW(lpszClassName, L"System.Int64") == 0)
		type = ELEMENT_TYPE_I8;
	else if (lstrcmpW(lpszClassName, L"System.UInt64") == 0)
		type = ELEMENT_TYPE_U8;
	else if (lstrcmpW(lpszClassName, L"System.String") == 0)
		type = ELEMENT_TYPE_STRING;
	else
		type = ELEMENT_TYPE_END;

	return type;
}

BOOL ILRewriteProfilerImpl::FilterClass(FunctionID functionId, LPWSTR lpszFilterClassName)
{
	IMetaDataImport *pMetaDataImport;
	mdMethodDef     methodDef;
	mdTypeDef       typeDef;
	WCHAR           szClassName[256];

	m_corProfilerInfo2->GetTokenAndMetaDataFromFunction(functionId, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport, &methodDef);
	pMetaDataImport->GetMethodProps(methodDef, &typeDef, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
	pMetaDataImport->GetTypeDefProps(typeDef, szClassName, 256, NULL, NULL, NULL);
	pMetaDataImport->Release();
	g_debugLogger << "MyFunctionEnter2:FilterClass " << static_cast<LPWSTR>(szClassName) << " " << lpszFilterClassName << std::endl;

	return lstrcmpW(szClassName, lpszFilterClassName) == 0;
}

void ILRewriteProfilerImpl::GetFullMethodName(FunctionID functionId, LPWSTR lpszFunctionName)
{
	IMetaDataImport *pMetaDataImport;
	mdMethodDef     methodDef;
	mdTypeDef       typeDef;
	WCHAR           szName[256], szClassName[256];

	m_corProfilerInfo2->GetTokenAndMetaDataFromFunction(functionId, IID_IMetaDataImport, (IUnknown **)&pMetaDataImport, &methodDef);
	pMetaDataImport->GetMethodProps(methodDef, &typeDef, szName, 256, NULL, NULL, NULL, NULL, NULL, NULL);
	pMetaDataImport->GetTypeDefProps(typeDef, szClassName, 256, NULL, NULL, NULL);
	pMetaDataImport->Release();
	
	wsprintfW(lpszFunctionName, L"%s.%s", szClassName, szName);
}

HRESULT ILRewriteProfilerImpl::SetEventMask()
{
   //COR_PRF_MONITOR_NONE	= 0,
   //COR_PRF_MONITOR_FUNCTION_UNLOADS	= 0x1,
   //COR_PRF_MONITOR_CLASS_LOADS	= 0x2,
   //COR_PRF_MONITOR_MODULE_LOADS	= 0x4,
   //COR_PRF_MONITOR_ASSEMBLY_LOADS	= 0x8,
   //COR_PRF_MONITOR_APPDOMAIN_LOADS	= 0x10,
   //COR_PRF_MONITOR_JIT_COMPILATION	= 0x20,
   //COR_PRF_MONITOR_EXCEPTIONS	= 0x40,
   //COR_PRF_MONITOR_GC	= 0x80,
   //COR_PRF_MONITOR_OBJECT_ALLOCATED	= 0x100,
   //COR_PRF_MONITOR_THREADS	= 0x200,
   //COR_PRF_MONITOR_REMOTING	= 0x400,
   //COR_PRF_MONITOR_CODE_TRANSITIONS	= 0x800,
   //COR_PRF_MONITOR_ENTERLEAVE	= 0x1000,
   //COR_PRF_MONITOR_CCW	= 0x2000,
   //COR_PRF_MONITOR_REMOTING_COOKIE	= 0x4000 | COR_PRF_MONITOR_REMOTING,
   //COR_PRF_MONITOR_REMOTING_ASYNC	= 0x8000 | COR_PRF_MONITOR_REMOTING,
   //COR_PRF_MONITOR_SUSPENDS	= 0x10000,
   //COR_PRF_MONITOR_CACHE_SEARCHES	= 0x20000,
   //COR_PRF_MONITOR_CLR_EXCEPTIONS	= 0x1000000,
   //COR_PRF_MONITOR_ALL	= 0x107ffff,
   //COR_PRF_ENABLE_REJIT	= 0x40000,
   //COR_PRF_ENABLE_INPROC_DEBUGGING	= 0x80000,
   //COR_PRF_ENABLE_JIT_MAPS	= 0x100000,
   //COR_PRF_DISABLE_INLINING	= 0x200000,
   //COR_PRF_DISABLE_OPTIMIZATIONS	= 0x400000,
   //COR_PRF_ENABLE_OBJECT_ALLOCATED	= 0x800000,

   // New in VS2005
   //COR_PRF_ENABLE_FUNCTION_ARGS	= 0x2000000,
   //COR_PRF_ENABLE_FUNCTION_RETVAL	= 0x4000000,
   //COR_PRF_ENABLE_FRAME_INFO	= 0x8000000,
   //COR_PRF_ENABLE_STACK_SNAPSHOT	= 0x10000000,
   //COR_PRF_USE_PROFILE_IMAGES	= 0x20000000,
   // End New in VS2005

   //COR_PRF_ALL	= 0x3fffffff,
   //COR_PRF_MONITOR_IMMUTABLE	= COR_PRF_MONITOR_CODE_TRANSITIONS | COR_PRF_MONITOR_REMOTING | COR_PRF_MONITOR_REMOTING_COOKIE | COR_PRF_MONITOR_REMOTING_ASYNC | COR_PRF_MONITOR_GC | COR_PRF_ENABLE_REJIT | COR_PRF_ENABLE_INPROC_DEBUGGING | COR_PRF_ENABLE_JIT_MAPS | COR_PRF_DISABLE_OPTIMIZATIONS | COR_PRF_DISABLE_INLINING | COR_PRF_ENABLE_OBJECT_ALLOCATED | COR_PRF_ENABLE_FUNCTION_ARGS | COR_PRF_ENABLE_FUNCTION_RETVAL | COR_PRF_ENABLE_FRAME_INFO | COR_PRF_ENABLE_STACK_SNAPSHOT | COR_PRF_USE_PROFILE_IMAGES

   // set the event mask 
   //DWORD eventMask = (DWORD)(COR_PRF_MONITOR_ENTERLEAVE);
   DWORD eventMask = COR_PRF_MONITOR_NONE;
   //eventMask |= COR_PRF_MONITOR_THREADS; // create / delete thread
   eventMask |= COR_PRF_ENABLE_FRAME_INFO;
   eventMask |= COR_PRF_MONITOR_ENTERLEAVE;
   eventMask |= COR_PRF_ENABLE_FUNCTION_ARGS;
   eventMask |= COR_PRF_MONITOR_JIT_COMPILATION;
   eventMask |= COR_PRF_ENABLE_FUNCTION_RETVAL;

   //eventMask |= COR_PRF_MONITOR_MODULE_LOADS;
   //
   //eventMask |= COR_PRF_MONITOR_CODE_TRANSITIONS;
   //eventMask |= COR_PRF_MONITOR_SUSPENDS;

   // eventMask |= COR_PRF_ENABLE_STACK_SNAPSHOT;
   // eventMask |= COR_PRF_MONITOR_SUSPENDS;
   eventMask |= COR_PRF_DISABLE_INLINING;
   eventMask |= COR_PRF_DISABLE_OPTIMIZATIONS;
   //	eventMask | = COR_PRF_MONITOR_IMMUTABLE;

   return m_corProfilerInfo->SetEventMask(eventMask);
}


STDMETHODIMP ILRewriteProfilerImpl::QueryInterface(REFIID riid, void **ppObj)
{
   LPOLESTR clsid = nullptr;

   HRESULT hr = StringFromCLSID(riid, &clsid);
   if (SUCCEEDED(hr))
   {
      std::wstring clsidString(clsid);
      g_debugLogger << "ILRewriteProfilerImpl::QueryInterface(" << ConvertStlString(clsidString).c_str() << ")" << std::endl;
      ::CoTaskMemFree(clsid);
   }
   if (riid == IID_IUnknown)
   {
      *ppObj = this; 
      AddRef() ;
      g_debugLogger.WriteLine("QueryInterface -> IUnknown");
      return S_OK;
   }

   if (riid == IID_ILRewriteProfiler)
   {
      *ppObj = static_cast<ILRewriteProfiler*>(this) ;
      AddRef() ;
      g_debugLogger.WriteLine("QueryInterface -> IDiagProfiler");
      return S_OK;
   }

   if (riid == IID_ICorProfilerCallback)
   {
      *ppObj = static_cast<ICorProfilerCallback*>(this) ;
      AddRef() ;
      g_debugLogger.WriteLine("QueryInterface -> ICorProfilerCallback");
      return S_OK;
   }

   if (riid == IID_ICorProfilerCallback2)
   {
      *ppObj = static_cast<ICorProfilerCallback2*>(this) ;
      AddRef();
      g_debugLogger.WriteLine("QueryInterface -> ICorProfilerCallback2");
      return S_OK;
   }

   if (riid == IID_ICorProfilerCallback3)
   {
      *ppObj = dynamic_cast<ICorProfilerCallback3*>(this) ;
      AddRef();
      g_debugLogger.WriteLine("QueryInterface -> ICorProfilerCallback");
      return S_OK;
   }

   if (riid == IID_ICorProfilerInfo)
   {
      g_debugLogger.WriteLine("QueryInterface -> ICorProfilerInfo");
      *ppObj = m_corProfilerInfo;
      return S_OK;
   }

   if (riid == IID_ICorProfilerInfo2)
   {
      g_debugLogger.WriteLine("QueryInterface -> ICorProfilerInfo2");
      *ppObj = m_corProfilerInfo2;
      return S_OK;
   }

   if (riid == IID_ICorProfilerInfo3)
   {
	   g_debugLogger.WriteLine("QueryInterface -> ICorProfilerInfo3");
	   *ppObj = m_corProfilerInfo3;
	   return S_OK;
   }

   *ppObj = NULL ;
   g_debugLogger.WriteLine("QueryInterface -> E_NOINTERFACE");
   return E_NOINTERFACE ;
}

ULONG STDMETHODCALLTYPE ILRewriteProfilerImpl::AddRef()
{
   return InterlockedIncrement(&m_nRefCount) ;
}

ULONG STDMETHODCALLTYPE ILRewriteProfilerImpl::Release()
{     
   long nRefCount=0;
   nRefCount=InterlockedDecrement(&m_nRefCount) ;
   if (nRefCount == 0) 
   {
      g_debugLogger.Close();
   }
   return nRefCount;
}

STDMETHODIMP ILRewriteProfilerImpl::ProfilerAttachComplete(void)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ProfilerDetachSucceeded(void)
{
   return S_OK;
};

STDMETHODIMP ILRewriteProfilerImpl::InitializeForAttach( 
   /* [in] */ IUnknown *pCorProfilerInfoUnk,
   /* [in] */ void *pvClientData,
   /* [in] */ UINT cbClientData)
{
   return S_OK;
}

//
// Called when a profiler is attached using environment variables
//
STDMETHODIMP ILRewriteProfilerImpl::Initialize(IUnknown *pICorProfilerInfoUnk)
{
   g_debugLogger.WriteLine("ILRewriteProfilerImpl::Initialize()");

   // get the ICorProfilerInfo interface
   HRESULT hr = pICorProfilerInfoUnk->QueryInterface(IID_ICorProfilerInfo, (LPVOID*)&m_corProfilerInfo);
   if (FAILED(hr))
   {
      g_debugLogger.WriteLine("Error: Failed to get ICorProfilerInfo");
      return E_FAIL;
   }
   else
   {
      g_debugLogger.WriteLine("Got ICorProfilerInfo");
   }

   hr = pICorProfilerInfoUnk->QueryInterface(IID_ICorProfilerInfo2, (LPVOID*)&m_corProfilerInfo2);
   if (FAILED(hr))
   {
      m_corProfilerInfo2 = nullptr;
      g_debugLogger.WriteLine("Error: Failed to get ICorProfiler2");
   }
   else
   {
	  m_corProfilerInfo2->SetEnterLeaveFunctionHooks2(MyFunctionEnter, MyFunctionLeave, NULL);
      g_debugLogger.WriteLine("Got ICorProfilerInfo2");
   }

   g_pProfilerCallback = this;

   // Tell the profiler API which events we want to listen to
   // Some events fail when we attach afterwards

   hr = SetEventMask();
   if (FAILED(hr))
   {
      g_debugLogger.WriteLine("Error: Failed to set event mask");
   }
   else
   {
      g_debugLogger.WriteLine("SetEventMask()");
   }

   g_debugLogger.WriteLine("Successfully initialized profiling");
   //g_debugLogger.WriteLine("Deactivating echo to OutputDebug");
   // We do not need echo to OutputDebugString
   //g_profilerData.m_debugLogger.Echo2OutputDebug(false);

   m_rewritehelper.SetCorProfilerInfo(m_corProfilerInfo);
   InitializeCriticalSection(&g_cs_ilRewite);
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ThreadAssignedToOSThread(ThreadID managedThreadID, DWORD osThreadID) 
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::Shutdown()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::AppDomainCreationStarted(AppDomainID appDomainID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::AppDomainCreationFinished(AppDomainID appDomainID, HRESULT hrStatus)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::AppDomainShutdownStarted(AppDomainID appDomainID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::AppDomainShutdownFinished(AppDomainID appDomainID, HRESULT hrStatus)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::AssemblyLoadStarted(AssemblyID assemblyID)
{
	g_debugLogger << "ClassLoadStarted" << std::endl;
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::AssemblyLoadFinished(AssemblyID assemblyID, HRESULT hrStatus)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::AssemblyUnloadStarted(AssemblyID assemblyID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::AssemblyUnloadFinished(AssemblyID assemblyID, HRESULT hrStatus)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ModuleLoadStarted(ModuleID moduleID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ModuleLoadFinished(ModuleID moduleID, HRESULT hrStatus)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ModuleUnloadStarted(ModuleID moduleID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ModuleUnloadFinished(ModuleID moduleID, HRESULT hrStatus)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ModuleAttachedToAssembly(ModuleID moduleID, AssemblyID assemblyID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ClassLoadStarted(ClassID classID)
{
	g_debugLogger << "ClassLoadStarted" << std::endl;
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ClassLoadFinished(ClassID classID, HRESULT hrStatus)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ClassUnloadStarted(ClassID classID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ClassUnloadFinished(ClassID classID, HRESULT hrStatus)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::FunctionUnloadStarted(FunctionID functionID)
{
	g_debugLogger << "FunctionUnloadStarted" << std::endl;
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::JITCompilationStarted(FunctionID functionID, BOOL fIsSafeToBlock)
{
   //EnterCriticalSection(&g_cs_ilRewite);

   //std::ostringstream o;
   //o << "ILRewriteProfilerImpl::JITCompilationStarted(";
   //o << functionID;
   //o << ")" << std::endl;
   //std::string msg = o.str();
   //g_debugLogger << msg.c_str();

   //FunctionInfo* functionInfo = m_rewritehelper.CreateFunctionInfo(functionID);
   //if (!functionInfo->IsValid())
   //   return S_OK;

   //g_debugLogger << "Assembly name : " << functionInfo->GetAssembly() << std::endl;
   //g_debugLogger << "Type  name : " << functionInfo->GetClassNameW() << std::endl;;
   //g_debugLogger << "Function name : "<< functionInfo->GetFunctionName() << std::endl;;

   ////ILRewriteDebugLogger ilDebugLogger = ILRewriteDebugLogger(m_corProfilerInfo, functionInfo);

   //std::auto_ptr<ILRewriter> rewriter(m_rewritehelper.CreateILRewriter(nullptr /*&ilDebugLogger*/, functionInfo));
   //if (rewriter->CanRewrite())
   //{
   //   // Add Prelude
   //   // g_debugLogger code writes to OutputDebug
   //   // Use DebugView.exe to see the logs

   //   ULONG oldSize = rewriter->GetOldMethodSize();
   //   LPCBYTE oldBytes = rewriter->GetOldMethodBytes();
   //   std::string hexStringOldBytes = PrintHex(oldBytes, oldSize);
   //   g_debugLogger << "Old ILBytes " << hexStringOldBytes << std::endl;
   //   g_debugLogger << "CanRewrite == True" << std::endl;
   //   LPBYTE newBytes = (LPBYTE) rewriter->GetNewILBytes();
   //   ULONG newSize = rewriter->GetNewMethodSize();
   //   std::string hexStringNewBytes = PrintHex(newBytes, newSize);
   //   g_debugLogger << "New ILBytes " << hexStringNewBytes << std::endl;

   //   {
   //      // Replace calls to DateTime.Now
   //      // This is just a reference sample
   //      // It is easy to replace methods with other methods having the exact same signature
   //      // It is just a question of changing the "function pointer", the mdMemberRef token

   //      COR_ILMETHOD_TINY* tiny = reinterpret_cast<COR_ILMETHOD_TINY*>(newBytes);
   //      ULONG codeSize = 0;
   //      BYTE* codeOffset = nullptr;
   //      if (tiny->IsTiny())
   //      {
   //         codeSize = tiny->GetCodeSize();
   //         codeOffset = tiny->GetCode();
   //      }
   //      else
   //      {
   //         COR_ILMETHOD_FAT* fat =  reinterpret_cast<COR_ILMETHOD_FAT*>(newBytes);
   //         codeSize = fat->CodeSize;
   //         codeOffset = fat->GetCode();
   //      }

   //      ULONG replaceCount = InterceptAPI::ReplaceDateTimeNowCalls(m_corProfilerInfo, functionInfo->GetModuleID(), codeOffset, codeSize);
   //      if (replaceCount != 0)
   //      {
   //         g_debugLogger << "Replaced DateTime::Now #" << replaceCount << " times" << std::endl;
   //      }
		 //g_debugLogger << "Replaced DateTime::Now #" << " 0 times" << std::endl;
   //   }
   //      
   //   Check(m_corProfilerInfo->SetILFunctionBody(functionInfo->GetModuleID(), functionInfo->GetToken(), newBytes));
   //}
   //else
   //{
   //   g_debugLogger << "CanRewrite == False" << std::endl;
   //}

   //g_debugLogger << "LeaveCriticalSection(&g_cs_ilRewite) - Before" << std::endl;
   //LeaveCriticalSection(&g_cs_ilRewite);

   //g_debugLogger << "LeaveCriticalSection(&g_cs_ilRewite) - After" << std::endl;
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::JITCompilationFinished(FunctionID functionID, HRESULT hrStatus, BOOL fIsSafeToBlock)
{
   std::ostringstream o;
   o << "ILRewriteProfilerImpl::JITCompilationFinished(";
   o << functionID;
   o << ")" << std::endl << std::endl;
   std::string msg = o.str();
   g_debugLogger << msg.c_str();
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::JITCachedFunctionSearchStarted(FunctionID functionID, BOOL *pbUseCachedFunction)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::JITCachedFunctionSearchFinished(FunctionID functionID, COR_PRF_JIT_CACHE result)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::JITFunctionPitched(FunctionID functionID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::JITInlining(FunctionID callerID, FunctionID calleeID, BOOL *pfShouldInline)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::UnmanagedToManagedTransition(FunctionID functionID, COR_PRF_TRANSITION_REASON reason)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ManagedToUnmanagedTransition(FunctionID functionID, COR_PRF_TRANSITION_REASON reason)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ThreadCreated(ThreadID threadID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ThreadDestroyed(ThreadID threadID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RemotingClientInvocationStarted()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RemotingClientSendingMessage(GUID *pCookie, BOOL fIsAsync)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RemotingClientReceivingReply(GUID *pCookie, BOOL fIsAsync)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RemotingClientInvocationFinished()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RemotingServerReceivingMessage(GUID *pCookie, BOOL fIsAsync)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RemotingServerInvocationStarted()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RemotingServerInvocationReturned()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RemotingServerSendingReply(GUID *pCookie, BOOL fIsAsync)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RuntimeSuspendStarted(COR_PRF_SUSPEND_REASON suspendReason)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RuntimeSuspendFinished()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RuntimeSuspendAborted()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RuntimeResumeStarted()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RuntimeResumeFinished()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RuntimeThreadSuspended(ThreadID threadID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RuntimeThreadResumed(ThreadID threadID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::MovedReferences(ULONG cmovedObjectIDRanges, ObjectID oldObjectIDRangeStart[], ObjectID newObjectIDRangeStart[], ULONG cObjectIDRangeLength[])
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ObjectAllocated(ObjectID objectID, ClassID classID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ObjectsAllocatedByClass(ULONG classCount, ClassID classIDs[], ULONG objects[])
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ObjectReferences(ObjectID objectID, ClassID classID, ULONG objectRefs, ObjectID objectRefIDs[])
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RootReferences(ULONG rootRefs, ObjectID rootRefIDs[])
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionThrown(ObjectID thrownObjectID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionUnwindFunctionEnter(FunctionID functionID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionUnwindFunctionLeave()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionSearchFunctionEnter(FunctionID functionID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionSearchFunctionLeave()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionSearchFilterEnter(FunctionID functionID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionSearchFilterLeave()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionSearchCatcherFound(FunctionID functionID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionCLRCatcherFound()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionCLRCatcherExecute()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionOSHandlerEnter(FunctionID functionID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionOSHandlerLeave(FunctionID functionID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionUnwindFinallyEnter(FunctionID functionID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionUnwindFinallyLeave()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionCatcherEnter(FunctionID functionID,
   ObjectID objectID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ExceptionCatcherLeave()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::COMClassicVTableCreated(ClassID wrappedClassID, REFGUID implementedIID, void *pVTable, ULONG cSlots)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::COMClassicVTableDestroyed(ClassID wrappedClassID, REFGUID implementedIID, void *pVTable)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::ThreadNameChanged(ThreadID threadID, ULONG cchName, WCHAR name[])
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::GarbageCollectionStarted(int cGenerations, BOOL generationCollected[], COR_PRF_GC_REASON reason)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::SurvivingReferences(ULONG cSurvivingObjectIDRanges, ObjectID objectIDRangeStart[], ULONG cObjectIDRangeLength[])
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::GarbageCollectionFinished()
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::FinalizeableObjectQueued(DWORD finalizerFlags, ObjectID objectID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::RootReferences2(ULONG cRootRefs, ObjectID rootRefIDs[], COR_PRF_GC_ROOT_KIND rootKinds[], COR_PRF_GC_ROOT_FLAGS rootFlags[], UINT_PTR rootIDs[])
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::HandleCreated(GCHandleID handleID, ObjectID initialObjectID)
{
   return S_OK;
}

STDMETHODIMP ILRewriteProfilerImpl::HandleDestroyed(GCHandleID handleID)
{
   return S_OK;
}

