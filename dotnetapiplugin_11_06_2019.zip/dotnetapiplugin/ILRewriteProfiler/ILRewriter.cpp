#include "stdafx.h"
#include "ILRewriter.h"

ILRewriter::ILRewriter()
{

}

ILRewriter::~ILRewriter()
{

}

bool ILRewriter::IsNull()
{
   return false; 
}

bool ILRewriter::CanRewrite()
{
   return false;
}
//
//void* ILRewriter::GetNewILBytes()
//{
//   return nullptr;
//}
//
//ULONG ILRewriter::GetNewMethodSize()
//{
//   return 0;
//}
//
//ULONG ILRewriter::GetOldMethodSize()
//{
//   return 0;
//}
//
//LPCBYTE ILRewriter::GetOldMethodBytes()
//{
//   return nullptr;
//}
