// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#pragma once
#include <Cor.h>

#define FAT_HEADER_SIZE (sizeof(WORD) + sizeof(WORD) + sizeof(DWORD) + sizeof(DWORD))
#define SMALL_HEADER_SIZE sizeof(BYTE)
#define MAX_TINY_FORMAT_SIZE 64

class ILRewriter
{
protected:
   ILRewriter();
public:
   ~ILRewriter();
   virtual bool IsNull();
   virtual bool CanRewrite();
   virtual LPCBYTE GetNewILBytes() = 0;
   virtual ULONG GetNewMethodSize() = 0;
   virtual ULONG GetOldMethodSize() = 0;
   virtual LPCBYTE GetOldMethodBytes() = 0;
};
