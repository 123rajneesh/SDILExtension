// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#include "stdafx.h"

#include "InterceptAPI.h"
#include "MetadataHelper.h"
#include "OpCodeParser.h"
#include "ProfilerLoggers.h"

InterceptAPI::InterceptAPI()
{

}

InterceptAPI::~InterceptAPI()
{

}

static const BYTE keyEMCAInterceptLib[] = { 0xca, 0xf2, 0x7b, 0x24, 0xca, 0xa5, 0xa1, 0x88 };

ULONG InterceptAPI::ReplaceDateTimeNowCalls(ICorProfilerInfo* info, ModuleID moduleId, BYTE* ILBytes, ULONG ILBytesSize)
{
   ULONG keyEMCAInterceptLibSize = sizeof(keyEMCAInterceptLib);
   mdTypeRef dateTimeTypeRef = mdTypeRefNil;
   mdMemberRef getNowMemberRef = mdMemberRefNil;

   HRESULT hr = S_OK;
   hr = MetadataHelper::ResolveMethodRef(info, moduleId, L"System.DateTime", L"get_Now", &dateTimeTypeRef, &getNowMemberRef);
   if (hr != S_OK)
   {
	   g_debugLogger << "Could not resolve method";
	   return 0;
   }
    
   
   mdMemberRef newMemberRef = mdMemberRefNil;
   MetadataHelper::DeclareZeroParamsFunctionReturningObject(info,
      moduleId,
      L"InterceptLib", keyEMCAInterceptLib,
      keyEMCAInterceptLibSize,
      L"InterceptLib.DebugLogger",
      L"get_Now",
      dateTimeTypeRef,
      &newMemberRef);

   ULONG count = OpCodeParser::ReplaceFunctionCall(ILBytes, ILBytesSize, getNowMemberRef, newMemberRef);

   g_debugLogger << "ULONG count = OpCodeParser::ReplaceFunctionCall(ILBytes, ILBytesSize, getNowMemberRef, newMemberRef);";
   return count;
}
