// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#include "stdafx.h"
#include "MetadataHelper.h"
#include "ProfilerLoggers.h"


MetadataHelper::MetadataHelper()
{

}

MetadataHelper::~MetadataHelper()
{

}

void MetadataHelper::Check(HRESULT hr)
{
   switch (hr)
   {
   case S_OK:
   case S_FALSE:
   case META_S_DUPLICATE:
      return;
   default:
      __debugbreak();
   }
}

HRESULT MetadataHelper::GetMemberDefs(IMetaDataImport* metadata, mdTypeDef typeDefToken, mdToken** memberDefArray, ULONG* memberDefArraySize)
{
   HCORENUM enumMemberDefs = 0;

   mdToken memberDef = 0;
   ULONG dummyCount = 0;
   ULONG tokenCount = 0;
   ULONG memberDefSize = 0;
   HRESULT hr = S_OK;
   hr = metadata->EnumMembers(&enumMemberDefs, typeDefToken, &memberDef, 1, &dummyCount);
   hr = metadata->CountEnum(enumMemberDefs, &memberDefSize);
   *memberDefArray = new mdMemberRef[memberDefSize];
   metadata->CloseEnum(enumMemberDefs);
   enumMemberDefs = 0;
   hr = metadata->EnumMembers(&enumMemberDefs, typeDefToken, *memberDefArray, memberDefSize, &tokenCount);
   metadata->CloseEnum(enumMemberDefs);
   *memberDefArraySize = tokenCount;
   return tokenCount;
}

HRESULT MetadataHelper::GetMemberRefs(IMetaDataImport* metadata, mdTypeRef typeRefToken, mdMemberRef** memberRefArray, ULONG* memberRefArraySize)
{
   HCORENUM enumMemberRefs = 0;
   mdMemberRef memberRef = 0;
   ULONG dummyCount = 0;
   ULONG tokenCount = 0;
   ULONG memberRefSize = 0;
   HRESULT hr = S_OK;
   hr = metadata->EnumMemberRefs(&enumMemberRefs, typeRefToken, &memberRef, 1, &dummyCount);
   hr = metadata->CountEnum(enumMemberRefs, &memberRefSize);
   *memberRefArray = new mdMemberRef[memberRefSize];
   metadata->CloseEnum(enumMemberRefs);
   enumMemberRefs = 0;
   hr = metadata->EnumMemberRefs(&enumMemberRefs, typeRefToken, *memberRefArray, memberRefSize, &tokenCount);
   metadata->CloseEnum(enumMemberRefs);
   *memberRefArraySize = tokenCount;
   return tokenCount;
}

HRESULT MetadataHelper::GetTypeDefs(IMetaDataImport* metadata, mdTypeDef** typeDefArray, ULONG* typeDefArraySize)
{
   HCORENUM enumTypeDefs = 0;
   ULONG typeDefSize = 0;
   ULONG dummyCount = 0;
   ULONG tokenCount = 0;
   HRESULT hr = S_OK;
   mdTypeDef typeDefToken = 0;
   metadata->EnumTypeDefs(&enumTypeDefs, &typeDefToken, 1, &dummyCount);
   hr = metadata->CountEnum(enumTypeDefs, &typeDefSize);
   *typeDefArray = new mdTypeRef [typeDefSize];
   metadata->CloseEnum(enumTypeDefs);
   enumTypeDefs = 0;
   hr = metadata->EnumTypeDefs(&enumTypeDefs, *typeDefArray, typeDefSize, &tokenCount);
   metadata->CloseEnum(enumTypeDefs);
   *typeDefArraySize = tokenCount;
   return hr;
}

HRESULT MetadataHelper::GetTypeRefs(IMetaDataImport* metadata, mdTypeRef** typeRefArray, ULONG* typeRefArraySize)
{
   HCORENUM enumTypeRefs = 0;
   ULONG typeRefSize = 0;
   ULONG dummyCount = 0;
   ULONG tokenCount = 0;
   HRESULT hr = S_OK;
   mdTypeRef typeRefToken = 0;
   hr = metadata->EnumTypeRefs(&enumTypeRefs, &typeRefToken, 1, &dummyCount);
   hr = metadata->CountEnum(enumTypeRefs, &typeRefSize);
   *typeRefArray = new mdTypeRef [typeRefSize];
   metadata->CloseEnum(enumTypeRefs);
   enumTypeRefs = 0;
   hr = metadata->EnumTypeRefs(&enumTypeRefs, *typeRefArray, typeRefSize, &tokenCount);
   metadata->CloseEnum(enumTypeRefs);
   *typeRefArraySize = tokenCount;
   return hr;
}


HRESULT MetadataHelper::FindMemberRef(IMetaDataImport* metadata, const WCHAR* methodName, mdTypeRef typeRef, mdMemberRef* memberRef)
{
   HRESULT hr = S_OK;
   ULONG memberRefSize = 0;
   mdMemberRef* memberRefArray = nullptr;
   hr = GetMemberRefs(metadata, typeRef, &memberRefArray, &memberRefSize);
   *memberRef = mdTypeRefNil;
   for (ULONG i=0;i<memberRefSize;i++)
   {
      mdToken token = 0;
      WCHAR currentMemberName[1024];
      PCCOR_SIGNATURE sig;
      ULONG len2 = 0;
      ULONG sigSize = 0;
      hr = metadata->GetMemberRefProps(memberRefArray[i], &token, currentMemberName, sizeof(currentMemberName)/sizeof(WCHAR), &len2, &sig, &sigSize);
      if (hr == S_OK)
      {
		  g_debugLogger << "currentMemberName" << currentMemberName;
         if (wcscmp(methodName, currentMemberName) == 0)
         {
            *memberRef = memberRefArray[i];
            break;
         }
      }
   }
   delete [] memberRefArray;
   hr = (*memberRef != mdTypeRefNil ? S_OK : E_FAIL);
   return hr;
}


HRESULT MetadataHelper::FindTypeRef(IMetaDataImport* pMetaDataImport, const WCHAR* typeName, mdTypeRef* typeRef)
{   
   HRESULT hr = S_OK;
   ULONG typeRefSize = 0;
   mdTypeRef* typeRefArray = nullptr;
   hr = GetTypeRefs(pMetaDataImport, &typeRefArray, &typeRefSize);
   if (hr != S_OK)
      return hr;

   *typeRef = mdTypeRefNil;
   for(ULONG i=0;i<typeRefSize;i++)
   {
      WCHAR currentTypeName[1024];
      ULONG len = 0;
      mdToken resolutionScope = 0;
      hr = pMetaDataImport->GetTypeRefProps(typeRefArray[i], &resolutionScope, currentTypeName, sizeof(currentTypeName) / sizeof(WCHAR), &len);
      if (hr == S_OK)
      {
		  /*g_debugLogger << "typeName  " << typeName;
		  g_debugLogger << "   currentTypeName " << currentTypeName<<std::endl;*/

         if (wcscmp(typeName, currentTypeName) == 0)
         {
            *typeRef = typeRefArray[i];
            break;
         }
      }
   }
   delete [] typeRefArray;
   hr = (*typeRef != mdTypeRefNil ? S_OK : E_FAIL);
   return hr;
}

HRESULT MetadataHelper::ResolveMethodRef(ICorProfilerInfo* info, ModuleID moduleID, const WCHAR* typeName, const WCHAR* methodName, mdTypeRef* outTypeRef, mdMemberRef* outMemberRef)
{
   HRESULT hr = S_OK;
   IMetaDataImport* pMetaDataImport = NULL;

   *outTypeRef = mdTypeRefNil;
   *outMemberRef = mdMemberRefNil;

   hr = info->GetModuleMetaData(moduleID, ofRead, IID_IMetaDataImport, (IUnknown** )&pMetaDataImport);
   if (FAILED(hr))
   {
	   g_debugLogger << "Could not find Module Meta data" << std::endl;
      return hr;
   }

   mdTypeRef typeRef = mdTypeRefNil;
   hr = FindTypeRef(pMetaDataImport, typeName, &typeRef);
   if (hr != S_OK)
   {
	   g_debugLogger << "FindTypeRef" << std::endl;
	   goto cleanup;
   }
     
   mdMemberRef methodRef = mdMemberRefNil;
   hr = FindMemberRef(pMetaDataImport, methodName, typeRef, &methodRef);
   if (hr != S_OK)
   {
	   g_debugLogger << "FindMemberRef - Not found" << std::endl;
	   goto cleanup;
   }
   
   *outTypeRef = typeRef;
   *outMemberRef = methodRef;

cleanup:
   pMetaDataImport->Release();
   return hr;
}

void MetadataHelper::DeclareZeroParamsFunctionReturningObject(ICorProfilerInfo* info, ModuleID moduleID, const wchar_t* assemblyName, const BYTE* keyEMCA, ULONG keyEMCASize, const wchar_t* fullyQualifiedClassName, const wchar_t* methodName, mdTypeRef retType, mdMemberRef* outMemberRef)
{
	g_debugLogger << "DeclareZeroParamsFunctionReturningObject" << std::endl;

	*outMemberRef = mdMemberRefNil;

	IMetaDataEmit* metaDataEmit = NULL;
	Check(info->GetModuleMetaData(moduleID, ofRead | ofWrite, IID_IMetaDataEmit, (IUnknown**)&metaDataEmit));

	ASSEMBLYMETADATA assemblyMetaData = { 0 };
	assemblyMetaData.usMajorVersion = 1;

	IMetaDataAssemblyEmit* metaDataAssemblyEmit = NULL;

	Check(metaDataEmit->QueryInterface(IID_IMetaDataAssemblyEmit, (void**)&metaDataAssemblyEmit));
	mdAssemblyRef assemblyRef = mdAssemblyRefNil;
	Check(metaDataAssemblyEmit->DefineAssemblyRef(keyEMCA, keyEMCASize, assemblyName, &assemblyMetaData, NULL, 0, 0, &assemblyRef));

	mdTypeRef typeRef = mdTypeRefNil;
	Check(metaDataEmit->DefineTypeRefByName(assemblyRef, fullyQualifiedClassName, &typeRef));

	BYTE rSig[] = { IMAGE_CEE_CS_CALLCONV_DEFAULT, 0, ELEMENT_TYPE_VALUETYPE, 0, 0, 0, 0, 0 };
	ULONG ulTokenLength;
	ULONG ulSigLength;
	ulTokenLength = CorSigCompressToken(retType, &rSig[3]);
	ulSigLength = 3 + ulTokenLength;
	mdMemberRef memberRef = mdMemberRefNil;
	Check(metaDataEmit->DefineMemberRef(typeRef, methodName, rSig, ulSigLength, &memberRef));
	metaDataAssemblyEmit->Release();
	metaDataEmit->Release();

	*outMemberRef = memberRef;

	g_debugLogger << "DeclareZeroParamsFunctionReturningObject - End" << std::endl;
}
