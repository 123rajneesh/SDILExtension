// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#pragma once

#include <cor.h>
#include <corprof.h>

class MetadataHelper
{
public:
   static HRESULT ResolveMethodRef(ICorProfilerInfo* info, ModuleID moduleID, const WCHAR* typeName, const WCHAR* methodName, mdTypeRef* outTypeRef, mdMemberRef* outMemberRef);
   static void DeclareZeroParamsFunctionReturningObject(ICorProfilerInfo* info, ModuleID moduleID, const wchar_t* assemblyName, const BYTE* keyEMCA, ULONG keyEMCASize, const wchar_t* fullyQualifiedClassName, const wchar_t* methodName, mdTypeRef retType, mdMemberRef* outMemberRef);

private:
   MetadataHelper();
   ~MetadataHelper();
private:
   static void MetadataHelper::Check(HRESULT hr);
private:
   static HRESULT FindTypeRef(IMetaDataImport* pMetaDataImport, const WCHAR* typeName, mdTypeRef* typeRef);
   static HRESULT GetTypeDefs(IMetaDataImport* metadata, mdTypeDef** typeDefArray, ULONG* typeDefArraySize);
   static HRESULT GetTypeRefs(IMetaDataImport* metadata, mdTypeRef** typeRefArray, ULONG* typeRefArraySize);
   static HRESULT FindMemberRef(IMetaDataImport* metadata, const WCHAR* methodName, mdTypeRef typeRef, mdMemberRef* memberRef);
   static HRESULT GetMemberRefs(IMetaDataImport* metadata, mdTypeRef typeRefToken, mdMemberRef** memberRefArray, ULONG* memberRefArraySize);
   static HRESULT GetMemberDefs(IMetaDataImport* metadata, mdTypeDef typeDefToken, mdToken** memberDefArray, ULONG* memberDefArraySize);
};