// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#include "stdafx.h"

#include "ProfilerData.h"
#include "ProfilerLoggers.h"
#include "PerformanceCounter.h"
#include "SystemHelper.h"

using namespace std;

ProfilerData::ProfilerData()
{
   InitializeCriticalSection(&m_cs_debug);
   InitializeCriticalSection(&m_cs_output);

   m_debugLogger.SetPrefix("[ILRewriteProfiler] ");
   m_debugLogger.Echo2OutputDebug(true);

   // g_debugLogger works even if the file is not open
   // It can signal errors when the file cannot be opened
   g_debugLogger.WriteLine("ILRewriteProfilerFactory::ILRewriteProfilerFactory()");

   std::string envFilename = std::string("ILREWRITE_PROFILER_DEBUG");
   std::string debugFilename = GetEnvVar(envFilename);
   if (debugFilename.size() != 0)
   {
      m_debugLogger.Open(debugFilename.c_str());
      if (!m_debugLogger.IsOpen())
      {
         g_debugLogger << "DebugLogger - Failed to open file: " << debugFilename.c_str() << endl;
      }
   }

   std::string envStacktrace = std::string("ILREWRITE_PROFILER_OUTPUT");
   std::string stackFilename = GetEnvVar(envStacktrace);
   if (stackFilename.size() != 0)
   {
      g_outputLogger.Open(stackFilename.c_str());
      if (!m_outputLogger.IsOpen())
      {
         g_debugLogger << "OutputLogger - Failed to open file: " << debugFilename.c_str() << endl;
      }
   }
   else
   {
      g_debugLogger.WriteLine("OutputLogger - A file must be specified");
      g_debugLogger.WriteLine("SET ILREWRITE_PROFILER_OUTPUT=<file>");
   }

   g_debugLogger.WriteLine("ILRewriteProfilerFactory::ILRewriteProfilerFactory()");

   PerformanceCounter perfCounter;
   g_debugLogger << "PERF - TicksPerSecond = " << dec << perfCounter.GetTicksPerSecond() << endl;
}

ProfilerData::~ProfilerData()
{
   //g_debugLogger << std::endl;
   //g_outputLogger << std::endl;
   DeleteCriticalSection(&m_cs_debug);
   DeleteCriticalSection(&m_cs_output);
}
