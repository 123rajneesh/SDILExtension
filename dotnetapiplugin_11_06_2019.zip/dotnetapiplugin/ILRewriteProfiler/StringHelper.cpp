// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#include "stdafx.h"
#include "StringHelper.h"
#include <sstream>
#include <string>

std::string ConvertStlString(std::wstring& text)
{    
   const std::string narrow(text.begin(), text.end());
   return narrow;
}

std::wstring ConvertStlString(std::string& text)
{
   const std::wstring wide(text.begin(), text.end());
   return wide;
}

std::string PrintHex(LPCBYTE bytes, ULONG count)
{
   std::stringstream s;
   s << "[";
   for (ULONG i=0; i < count; i++)
   {
      char buffer[10];
      unsigned int hexval = bytes[i];
      sprintf_s(buffer, "%02X", hexval);
      s << buffer;
   }
   s << "]=";
   s << count;
   return s.str();
}