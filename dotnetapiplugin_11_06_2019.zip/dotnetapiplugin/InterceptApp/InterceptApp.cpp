// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#include "stdafx.h"
#include <array>
#include <windows.h>
#include <objbase.h>
#include <vcclr.h>
#include <string>
#include <iostream>
#include "ProfileClrApp.h"

using namespace std;
using namespace System;
using namespace System::Diagnostics;


static std::string ConvertStlString(std::wstring& text)
{
	const std::string narrow(text.begin(), text.end());
	return narrow;
}

static std::wstring ConvertStlString(std::string& text)
{
	const std::wstring wide(text.begin(), text.end());
	return wide;
}

static std::wstring StringToWString(String^ clrString)
{
	pin_ptr<const wchar_t> wch = PtrToStringChars(clrString);
	return std::wstring(wch);
}

static std::string GetCurrentDirectoryAsStlString()
{
	CHAR buffer[500];
	DWORD bufferSize = sizeof(buffer) * sizeof(WCHAR);
	DWORD len = GetCurrentDirectoryA(bufferSize, buffer);
	if ((len > bufferSize) || (len == 0))
		return std::string("");
	return std::string(buffer);
}

int main(cli::array<System::String ^> ^args)
{
	if (args->Length != 1)
	{
		cout << "Usage: InterceptApp <ManagedApp.exe>" << endl;
		return -1;
	}

	String^ filenamePath = args[0];
	String^ filename = System::IO::Path::GetFileName(filenamePath);
	String^ filenameWithoutExtension = System::IO::Path::GetFileNameWithoutExtension(filename);
	String^ directoryName = System::IO::Path::GetDirectoryName(filenamePath);

	if (directoryName->Length == 0)
	{
		std::string currentDir = GetCurrentDirectoryAsStlString();
		directoryName = gcnew String(currentDir.c_str());
	}

	System::Diagnostics::Process^ proc = gcnew   System::Diagnostics::Process();

	/*IntPtr handle =  proc->GetProcessesByName("SampleApp1")[0]->Handle;
	DWORD procID = proc->GetProcessesByName(L"SampleApp1")[0]->Id;*/

	String^ exePath = System::IO::Path::Combine(directoryName, filenameWithoutExtension);
	String^ stackPath = System::IO::Path::Combine(directoryName, filenameWithoutExtension) + gcnew String("_output.txt");
	String^ debugPath = System::IO::Path::Combine(directoryName, filenameWithoutExtension) + gcnew String("_debug.txt");

	ProfileClrApp^ profiler = gcnew ProfileClrApp();
	System::Console::WriteLine("Trying to start: {0}", filename);

	if (!profiler->StartProcess(exePath, stackPath, debugPath))// , handle, procID))
	{
		cout << "Failed to start process" << endl;
		return -1;
	}

	/*if (!profiler->StartProcess(exePath, stackPath, debugPath))
	{
	   cout << "Failed to start process" << endl;
	   return -1;
	}*/

	cout << flush;
	system("pause");

	return 0;
}
