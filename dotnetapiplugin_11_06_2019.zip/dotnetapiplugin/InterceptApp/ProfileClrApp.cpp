// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#include "Stdafx.h"

#include "ProfileClrApp.h"
#include "ProfilerStarter.h"
#include "ClrHelper.h"

#include <vcclr.h>
#include <iostream>
#include <sstream>

using namespace std;

static std::string ConvertStlString(std::wstring& text)
{    
   const std::string narrow(text.begin(), text.end());
   return narrow;
}

ProfileClrApp::ProfileClrApp()
{
   m_pId = 0;
   m_profilerStarter = new ProfilerStarter();
}

ProfileClrApp::~ProfileClrApp()
{
   if (m_profilerStarter)
   {
      delete m_profilerStarter;
      m_profilerStarter = nullptr;
   }
}

std::wstring StringToWString(String^ clrString)
{
   pin_ptr<const wchar_t> wch = PtrToStringChars(clrString);
   return std::wstring(wch);
}

bool ProfileClrApp::ClrRuntimeIsV4(String^ exePath)
{
   std::wstring pathToExe = StringToWString(exePath);
   std::wstring clrVersion = ClrHelper::GetClrVersion(pathToExe.c_str());
   return ClrHelper::ParseClrVersion(clrVersion.c_str()) == V4;
}

bool ProfileClrApp::StartProcess(String^ exePath, String^ dataOutputPath, IntPtr handle)
{
   return this->StartProcess(exePath, dataOutputPath, String::Empty, handle ,0);
}

bool ProfileClrApp::StartProcess(String^ exePath, String^ dataOutputPath, String^ debugOutputPath , IntPtr handle, DWORD procID)
{
   if (m_pId != 0)
      return false;


   m_symbolPath = System::IO::Path::GetDirectoryName(exePath);
   String^ assemblyDir = System::IO::Path::GetDirectoryName(System::Reflection::Assembly::GetExecutingAssembly()->GetName()->CodeBase);
   String^ profilerDir = assemblyDir;
   String^ prefix = "file:\\";
   if (assemblyDir->StartsWith(prefix))
      profilerDir = assemblyDir->Substring(prefix->Length);

   m_profilerPath = System::IO::Path::Combine(profilerDir,  "ILRewriteProfiler.dll");
   m_exePath = exePath;
   std::wstring pathToExe = StringToWString(exePath);
   m_stackOutputPath = dataOutputPath;
   std::wstring pathToDataOutput = StringToWString(dataOutputPath);
   m_debugOutputPath = debugOutputPath;
   std::wstring pathToDebugOutput = StringToWString(debugOutputPath);
   std::wstring pathToProfiler = StringToWString(m_profilerPath);
   std::wstring pathToSymbolDir = StringToWString(m_symbolPath);

   std::list<std::wstring> environment;

   std::wstring stacktrace = std::wstring(L"ILREWRITE_PROFILER_OUTPUT=") + pathToDataOutput;
   environment.push_back(stacktrace);
   std::wstring debugtrace = std::wstring(L"ILREWRITE_PROFILER_DEBUG=") + pathToDebugOutput;
   environment.push_back(debugtrace);

   environment.push_back(std::wstring(L"COR_ENABLE_PROFILING=1"));
   environment.push_back(std::wstring(L"COR_PROFILER={941EC77E-F7C0-42C8-84E1-15FEFA3CE96F}"));
   std::wstring cor_profiler_path = std::wstring(L"COR_PROFILER_PATH=") + pathToProfiler;
   environment.push_back(cor_profiler_path);

   std::wstring clr4Version;
   if (!ClrHelper::GetV4RunTime(clr4Version))
   {
      cout << "Cannot find clr v4 installed" << endl;
      return false;
   }
   std::wstring forceVersion = std::wstring(L"COMPLUS_Version=") + clr4Version;
   environment.push_back(forceVersion);

   environment.push_back(std::wstring(L"SystemRoot=C:\\Windows"));
   //environment.push_back(std::wstring(L"COMPLUS_Version=v4.0.30319"));	
   //environment.push_back(std::wstring(L"COMPLUS_Version=v2.0.50727"));

   /*const char str[] = "941EC77E-F7C0-42C8-84E1-15FEFA3CE96F";
  
   HRESULT result = m_profilerStarter->CallAttachProfiler(m_pId, 100000, pathToProfiler.c_str(), environment, &handle);*/

   BOOL created = m_profilerStarter->StartProcess(pathToExe.c_str(), environment);
   if (!created)
   {
      cout << "Failed to create process" << endl;
      return false;
   }
   cout << "Process created" << endl;
   cout << "Forcing version " << ConvertStlString(forceVersion).c_str() << endl;
   m_pId = m_profilerStarter->GetProcessId();
  
   return true;
}

bool ProfileClrApp::StartProcess(String^ exePath, String^ dataOutputPath, String^ debugOutputPath)
{
	if (m_pId != 0)
		return false;


	m_symbolPath = System::IO::Path::GetDirectoryName(exePath);
	String^ assemblyDir = System::IO::Path::GetDirectoryName(System::Reflection::Assembly::GetExecutingAssembly()->GetName()->CodeBase);
	String^ profilerDir = assemblyDir;
	String^ prefix = "file:\\";
	if (assemblyDir->StartsWith(prefix))
		profilerDir = assemblyDir->Substring(prefix->Length);

	m_profilerPath = System::IO::Path::Combine(profilerDir, "ILRewriteProfiler.dll");
	m_exePath = exePath;
	std::wstring pathToExe = StringToWString(exePath);
	m_stackOutputPath = dataOutputPath;
	std::wstring pathToDataOutput = StringToWString(dataOutputPath);
	m_debugOutputPath = debugOutputPath;
	std::wstring pathToDebugOutput = StringToWString(debugOutputPath);
	std::wstring pathToProfiler = StringToWString(m_profilerPath);
	std::wstring pathToSymbolDir = StringToWString(m_symbolPath);

	std::list<std::wstring> environment;

	std::wstring stacktrace = std::wstring(L"ILREWRITE_PROFILER_OUTPUT=") + pathToDataOutput;
	environment.push_back(stacktrace);
	std::wstring debugtrace = std::wstring(L"ILREWRITE_PROFILER_DEBUG=") + pathToDebugOutput;
	environment.push_back(debugtrace);

	environment.push_back(std::wstring(L"COR_ENABLE_PROFILING=1"));
	environment.push_back(std::wstring(L"COR_PROFILER={941EC77E-F7C0-42C8-84E1-15FEFA3CE96F}"));
	std::wstring cor_profiler_path = std::wstring(L"COR_PROFILER_PATH=") + pathToProfiler;
	environment.push_back(cor_profiler_path);

	std::wstring clr4Version;
	if (!ClrHelper::GetV4RunTime(clr4Version))
	{
		cout << "Cannot find clr v4 installed" << endl;
		return false;
	}
	std::wstring forceVersion = std::wstring(L"COMPLUS_Version=") + clr4Version;
	environment.push_back(forceVersion);

	environment.push_back(std::wstring(L"SystemRoot=C:\\Windows"));
	//environment.push_back(std::wstring(L"COMPLUS_Version=v4.0.30319"));	
	//environment.push_back(std::wstring(L"COMPLUS_Version=v2.0.50727"));

	/*const char str[] = "941EC77E-F7C0-42C8-84E1-15FEFA3CE96F";

	HRESULT result = m_profilerStarter->CallAttachProfiler(m_pId, 100000, pathToProfiler.c_str(), environment, &handle);*/

	BOOL created = m_profilerStarter->StartProcess(pathToExe.c_str(), environment);
	if (!created)
	{
		cout << "Failed to create process" << endl;
		return false;
	}
	cout << "Process created" << endl;
	cout << "Forcing version " << ConvertStlString(forceVersion).c_str() << endl;
	m_pId = m_profilerStarter->GetProcessId();

	return true;
}

int ProfileClrApp::PId()
{
   return m_pId;
}
