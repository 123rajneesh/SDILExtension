﻿// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias Högström.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

using System;
using System.IO;
using System.Net.Http;

namespace InterceptLib
{
   public static class DebugLogger
   {
      public static void Log(string method)
      {
         System.Diagnostics.Debug.WriteLine(method);
      }

      public static DateTime Now//string path, HttpContent content
      {
         get {
                File.AppendAllText(Path.Combine(Environment.CurrentDirectory, "InjectedText.txt"), "\r\n Hey I am injected and This is my first Instrumentation.1");
                return new DateTime(2000, 7, 23, 18,15,0);
            }
      }

      public static DateTime StartTime()
      {
            //File.AppendAllText(Path.Combine(Environment.CurrentDirectory, "Hey I am injected and This is my first Instrumentation."));
            File.AppendAllText(Path.Combine(Environment.CurrentDirectory,"InjectedText.txt"), "\r\n Hey I am injected and This is my first Instrumentation.2");
            return new DateTime(2000, 7, 23, 15,15,0); 
      }
   }
}
