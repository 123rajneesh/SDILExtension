﻿//-----------------------------------------------------------------------
// <copyright file="HttpConsumers.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTAPIConsumerFunct
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using CrossCode.ByteCode.Helper;
    class HttpConsumers : IHttpConsumers
    {

        public bool FindHttpCallers(string appPath, out Dictionary<string, object> httpConsumData)
        {
            httpConsumData = new Dictionary<string, object>();
            bool IsHtttpCallingUsed = Execute(appPath, out httpConsumData);

            return IsHtttpCallingUsed;
        }


        public static bool Execute(string applicatioPath, out Dictionary<string, object> funcHttpConsumers)
        {
            bool httpAPIIsBeingUsed = false;
            funcHttpConsumers = new Dictionary<string, object>();

            var clientdll = AppHelper.GetHttpClientConnectedLibraryInAppAll();
            string appDir = Path.GetDirectoryName(applicatioPath);

            List<string> HttpClientRefAssem = new List<string>();

            foreach (string filepath in Directory.GetFiles(appDir))
            {
                try
                {
                    if (filepath.EndsWith(".dll") || filepath.EndsWith(".exe"))
                    {
                        Assembly assem = Assembly.LoadFile(filepath);
                        var refAssembly = assem.GetReferencedAssemblies();

                        bool ishttpClientRefExist = refAssembly.Any(x => Path.GetFileNameWithoutExtension(clientdll.ElementAt(0)["A"]) == x.Name);

                        if (ishttpClientRefExist)
                        {
                            httpAPIIsBeingUsed = true;
                            HttpClientRefAssem.Add(filepath);
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }

            ////FilterSystemOrFrameworkAssembly(HttpClientRefAssem);
            ////Change for performance boostup so removing this call since it is not being used further calculation.

            funcHttpConsumers = new Dictionary<string, object>(); //// NETPluginInterface.GetAllTheDecomPosition(HttpClientRefAssem, clientdll);

            return httpAPIIsBeingUsed;
        }

        //private static void FilterSystemOrFrameworkAssembly(List<string> httpClientRefAssem)
        //{
        //    //Currently dont have any filteration logic
        //    //var filterCollectn = AppHelper.GetHttpClientConnectedLibraryInApp();
        //}
    }
}
