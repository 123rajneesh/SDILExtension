﻿//-----------------------------------------------------------------------
// <copyright file="IHttpConsumers.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTAPIConsumerFunct
{
    using System.Collections.Generic;
    interface IHttpConsumers
    {
        bool  FindHttpCallers(string appPath, out Dictionary<string, object> httpConsumData);
    }
}
