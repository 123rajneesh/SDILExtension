﻿//-----------------------------------------------------------------------
// <copyright file="LogDataParser.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.DeepTrace.Engine
{
    using CrossCode.ByteCode.Helper;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Xml;
    public class LogDataParser
    {

        public static List<KeyValuePair<string, string>> ParseHttpSniffingDataFromLog(string httpLogPath)
        {
            List<KeyValuePair<string, string>> sniffDataDup = new List<KeyValuePair<string, string>>();

            string httpCallLogFile = File.ReadAllText(httpLogPath).ToString();

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(string.Concat(ConstantAPIModule.RootNodeStart, httpCallLogFile, ConstantAPIModule.RootNodeEnd));

            foreach (XmlNode xmlN in doc.ChildNodes[0].ChildNodes)
            {
                XmlNodeList xmlnode = xmlN[ConstantAPIModule.ApplicationDatatNode].ChildNodes;

                string url = xmlnode[0].Value;
                string[] x2 = xmlnode[1].ChildNodes[1].ChildNodes[0].Value.Split(new string[1] { "\r\n" }, StringSplitOptions.None);
                string[] codeLines = x2.Where(l => l.Contains(ConstantAPIModule.Seperatorline)).ToArray();

                try
                {
                    string httpUrl = url.Split(new string[2] { ConstantAPIModule.SeperatorCreateCodeStackTrace, ConstantAPIModule.SeperatorWebRequestCodeStackTrace }, StringSplitOptions.None)[1];

                    if (httpUrl.EndsWith(")"))
                    {
                        httpUrl = httpUrl.Remove(httpUrl.Length - 1, 1);
                    }
                    string methodConsumer = codeLines[0].Split(new string[1] { " " }, StringSplitOptions.None)[4];

                    bool isURL = IsStringMatchedToURLPattern(httpUrl);

                    if (isURL)
                    {
                        sniffDataDup.Add(new KeyValuePair<string, string>(httpUrl, methodConsumer));
                    }
                }
                catch (Exception ex)
                {
                }
            }

            return sniffDataDup;
        }

        private static bool IsStringMatchedToURLPattern(string httpUrl)
        {
            Regex reg = new Regex(ConstantAPIModule.UrlRegx, RegexOptions.Compiled | RegexOptions.IgnoreCase);
            bool isURL = reg.IsMatch(httpUrl);
            return isURL;
        }
    }
}
