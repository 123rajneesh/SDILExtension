﻿//-----------------------------------------------------------------------
// <copyright file="HTTPApiFinderMain.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace RESTAPIConsumerFunct
{
    using System.Collections.Generic;
    /// <summary>
    /// Responsibilities  of This HTTP/HTTPS  Finder Module - 
    /// 1. Search all the libraries for http client
    /// 2. Search where  HTTPClient object is invoked 
    /// 3. Find the consumer api of HTTTP
    /// 4. Write the data in a file to pick up by profiler application.
    /// 5. Need to find the best design pattern  which can be fit here
    /// 6. Input - Application assembly{ DLL/EXE}
    /// 7. Output - All the function which is using HttpAPI in Application
    /// Suitable Design Pattern - Visitor/Command or any other GOF pattern ??
    /// </summary>
    public class HTTPApiFinderMain
    {
        public static bool GetHttpCalling(string appPath, out Dictionary<string, object> consumers)
        {
            consumers = new Dictionary<string, object>();

            IHttpConsumers httpCallingUsage = new HttpConsumers();

            bool httpCallingExist = httpCallingUsage.FindHttpCallers(appPath, out consumers);


            if (httpCallingExist)
            {
                //Read the consumers
            }

            return httpCallingExist;
        }
    }
}
