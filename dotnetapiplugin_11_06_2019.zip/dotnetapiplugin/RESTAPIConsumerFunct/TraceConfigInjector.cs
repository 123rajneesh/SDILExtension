﻿//-----------------------------------------------------------------------
// <copyright file="TraceConfigInjector.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace CrossCode.DeepTrace.Engine
{
    using CrossCode.ByteCode.Helper;
    using CrossCode.Helper;
    using RESTAPIConsumerFunct.Properties;
    using System;
    using System.IO;
    using System.Reflection;
    using System.Xml;

    public class TraceConfigInjector : IConfigInjector
    {
        private const string XpathConfiguSection = "//configuration//system.diagnostics";
        private AppDomain currentDomain = AppDomain.CurrentDomain;
        public string SourcePath { get; private set; }

        public void AddTraceConfigInApplication(string appFullPath)
        {
            SourcePath = Environment.CurrentDirectory;

            this.currentDomain.AssemblyResolve += new ResolveEventHandler(AssemResolveEventHandler);

            XmlDocument doc;
            XmlElement webConfigData;

            XMLNodeBuilder.GetXMLConfigSectionByXpath(appFullPath, out doc, out webConfigData, XpathConfiguSection);

            if (webConfigData != null)
            {
                XmlNodeList traceAttr = webConfigData.SelectNodes("//trace");
                bool isAnyChangesInConfig = false;

                XMLNodeBuilder.ChekNAddTraceInConfig(doc, webConfigData, traceAttr, Resources.TraceAttr, ref isAnyChangesInConfig);

                XmlNodeList sourceAttr = webConfigData.SelectNodes("//sources");
                XMLNodeBuilder.ChekNAddSourceInConfig(doc, webConfigData, sourceAttr, Resources.Source, ref isAnyChangesInConfig);

                XmlNodeList sharedListenerAttr = webConfigData.SelectNodes("//sharedListeners");
                XMLNodeBuilder.CheckNAddSharedListeners(doc, webConfigData, sharedListenerAttr, Resources.SharedListner, ref isAnyChangesInConfig);

                XmlNodeList switchesNode = webConfigData.SelectNodes("//switches");
                XMLNodeBuilder.CheckNAddSwitchesInConfig(doc, webConfigData, switchesNode, Resources.SwitchNode, ref isAnyChangesInConfig);

                if (isAnyChangesInConfig)
                {
                    doc.Save(appFullPath);
                }
            }
            else
            {
                XMLNodeBuilder.AddNewSystemDiagnstcs(doc, Resources.TraceXML);
                doc.Save(appFullPath);
            }
        }

        /// <summary>
        /// Assembly resolve event handler
        /// </summary>
        /// <param name="sender">sender location</param>
        /// <param name="args">event argument</param>
        /// <returns>return the found assembly</returns>
        private  Assembly AssemResolveEventHandler(object sender, ResolveEventArgs args)
        {
            Assembly myAssembly = null;

            string withoutExt = Path.GetDirectoryName(SourcePath);
            string strTempAssmbPath = string.Empty;

            try
            {
                if (args.Name.IndexOf(",") > 0)
                {
                    strTempAssmbPath = Path.Combine(withoutExt, args.Name.Substring(0, args.Name.IndexOf(",")) + ".dll");
                }
                else
                {
                    strTempAssmbPath = args.Name;
                }

                //if (CurrentProcessingItem == strTempAssmbPath)
                //{
                //    return myAssembly;
                //}

                myAssembly = Assembly.Load(File.ReadAllBytes(strTempAssmbPath));
            }
            catch (Exception ex)
            {
                ////not logging because of known error  wrong path args.Name
                //Console.WriteLine(ex.Message);
            }
            ////Load the assembly from the specified path. Return the loaded assembly.
            return myAssembly;
        }
    }
}
