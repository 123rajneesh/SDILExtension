﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using System.Collections.Generic;
    public class Program
    {
        /// <summary>
        ///Algo - Collecting all the producer/server api
        ///1.Read all the Contoller 
        ///2.Read all the action method 
        ///3.Read all the attribute and there parameter 
        ///4.Prepare all the API collection and then return
        ///@"C:\Users\ashutosh.singh\source\repos\WebApplication8\WebApplication8\bin\WebApplication8.dll"
        ///var apiConfig = new FetchRoutingDetails().GetRouteConfiguration(applicationPath);
        /// </summary>
        /// <param name="applicationPath"></param>
        /// <returns></returns>
        public static Dictionary<string, string> FetchWeAppServerUrls(string applicationPath = @"", string TaskType="")
        {
            string jsonData = string.Empty;

            IExtractAPI extractAPI = new ExtractAPIDetails();
            extractAPI.TaskType = TaskType;

            var serverURLs = extractAPI.GetContollerClass(applicationPath);

            return serverURLs;
        }
    }
}
