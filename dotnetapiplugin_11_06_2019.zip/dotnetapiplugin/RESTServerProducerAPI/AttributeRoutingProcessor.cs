﻿//-----------------------------------------------------------------------
// <copyright file="AttributeRoutingProcessor.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using CrossCode.BLL.Domain;
    using System.Collections.Generic;
    /// <summary>
    /// Attribute Routing processor
    /// </summary>
    class AttributeRoutingProcessor : IRoutingProcessor
    {
        private const string MethodIdentifierKeyHeder = "MethodKey";
        private const string MethodNameKeyHeder = "MethodName";
        private ClassDetailAPI classAPI = null;

        public AttributeRoutingProcessor(IClassDetails classDetails)
        {
            classAPI = (ClassDetailAPI)classDetails;
        }

        public string AssemAPIPath
        {
            get;
            set;
        }
        public Dictionary<string, List<string>> PrepareAllURLs
        {
            get;
            set;
        }
        public IClassDetails ClassDetails
        {
            set
            {
                classAPI = (ClassDetailAPI)value;
            }
        }

        /// <summary>
        /// Prtepare the URL according to Attribute Routing
        /// </summary>
        /// <param name="taskType">Task type -  Standalone  or IIS</param>
        /// <returns>All Urls with their Mehtod key</returns>
        public Dictionary<string, string> PrepareURL(string taskType)
        {
            Dictionary<string,string> serverUrl = new Dictionary<string, string>();

            foreach (var method in classAPI.MethodLvlAttribute)
            {
                bool isRoutingPrefixExist = false;
                string routePrefixvalue = string.Empty;

                if (classAPI.ClassLvlAttributes != null && classAPI.ClassLvlAttributes.Count > 0)
                {
                    isRoutingPrefixExist = classAPI.ClassLvlAttributes.TryGetValue("RoutePrefix", out routePrefixvalue);
                }

                string routeURL = string.Empty;

                if(taskType =="IIS")
                {
                    routeURL = method.Value.Find(x => x.Key == "methodAPIUrl").Value;
                }
                else
                {
                    routeURL = method.Value.Find(x => x.Key == "HttpRoute").Value;
                }
                
                var methodKey = method.Value.Find(x => x.Key == MethodIdentifierKeyHeder).Value;

                if (isRoutingPrefixExist)
                {
                    string apiUrl = string.Join("/", new object[2] { routePrefixvalue, routeURL });
                    serverUrl.Add(methodKey, apiUrl);
                }
                else
                {
                    serverUrl.Add(methodKey, routeURL);
                }
            }

            return serverUrl;
        }
    }
}
