﻿//-----------------------------------------------------------------------
// <copyright file="CreateURL.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using CrossCode.BLL.Domain;
    using CrossCode.ByteCode.Helper;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    class CreateURL
    {
        private const string SeparatorAttribute = "#@:";
        private const string MethodNameKeyHeader = "MethodName";
        private const string ParamInfoNameKeyHeader = "ParamInfo";
        private const string ControllerToken = "{controller}";
        private const string ActionToken = "{action}";

        public static Dictionary<string, string> PrepareServerUrls(ClassDetailAPI aPIStructures, string urlTemplate, TemplateType tempType)
        {
            Dictionary<string, string> producerAPIs = new Dictionary<string, string>();

            foreach (var url in aPIStructures.MethodLvlAttribute)
            {
                PrepareTemplatesUrls(aPIStructures, urlTemplate, tempType, producerAPIs, url);
            }

            return producerAPIs;
        }

        private static void PrepareTemplatesUrls(ClassDetailAPI aPIStructures, string urlTemplate, TemplateType tempType, Dictionary<string, string> producerAPIs, KeyValuePair<string, List<KeyValuePair<string, string>>> url)
        {
            if (tempType == TemplateType.OnlyController)
            {
                PrepareUrlsTmpltTypOnlyController(aPIStructures, urlTemplate, producerAPIs, url);
            }
            else if (tempType == TemplateType.ControlerWithAction)
            {
                PrepareUrlsTmpltTypControllerWithAction(aPIStructures, urlTemplate, producerAPIs, url);
            }
            else
            {
            }
        }

        private static void PrepareUrlsTmpltTypOnlyController(ClassDetailAPI aPIStructures, string urlTemplate, Dictionary<string, string> producerAPIs, KeyValuePair<string, List<KeyValuePair<string, string>>> url)
        {
            string createdURLs = urlTemplate.Replace(ControllerToken, aPIStructures.ClassName.Replace("Controller", ""));
            var keyData = url.Value.Where(x => x.Key == "MethodKey").FirstOrDefault();

            producerAPIs.Add(keyData.Value, createdURLs);
        }

        private static void PrepareUrlsTmpltTypControllerWithAction(ClassDetailAPI aPIStructures, string urlTemplate, Dictionary<string, string> producerAPIs, KeyValuePair<string, List<KeyValuePair<string, string>>> url)
        {
            string createdURLs = PrepareUrlCntrWthActn(aPIStructures, urlTemplate, url);
            producerAPIs.Add(url.Key, createdURLs);
        }

        private static string PrepareUrlCntrWthActn(ClassDetailAPI aPIStructures, string urlTemplate, KeyValuePair<string, List<KeyValuePair<string, string>>> url)
        {
            string key = url.Key.Split(new string[1] { SeparatorAttribute }, StringSplitOptions.RemoveEmptyEntries)[1];
            var keyData = url.Value.Where(x => x.Key == MethodNameKeyHeader).FirstOrDefault();
            string createdURLs = urlTemplate.Replace(ControllerToken, aPIStructures.ClassName);
            var actionNameByAttribute = url.Value.Where(x => x.Key == "ActionName").FirstOrDefault();

            if (actionNameByAttribute.Equals(default(KeyValuePair<string, string>)))
            {
                createdURLs = createdURLs.Replace(ActionToken, keyData.Value);
            }
            else
            {
                createdURLs = createdURLs.Replace(ActionToken, actionNameByAttribute.Value);
            }

            return createdURLs;
        }
    }
}
