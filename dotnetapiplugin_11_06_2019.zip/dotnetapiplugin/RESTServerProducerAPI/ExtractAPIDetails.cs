﻿//-----------------------------------------------------------------------
// <copyright file="ExtractAPIDetails.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using CrossCode.BLL.Decomposition;
    using CrossCode.BLL.Domain;
    using CrossCode.ByteCode.Helper;
    using CrossCode.Trace.BLL;
    using System.Collections.Generic;

    /// <summary>
    /// Extract Api information class
    /// </summary>
    public class ExtractAPIDetails : IExtractAPI
    {
        private const string METHODAPIURL = "methodAPIUrl";
        private static IRoutingProcessor routeInternal = null;
        /// <summary>
        /// Type of application 
        /// </summary>
        public string TaskType
        {
            get;
            set;
        }

        /// <summary>
        /// Get the controller classes of Web api 
        /// </summary>
        /// <param name="filePath">File path of asembly</param>
        /// <returns>All the urls with Key-Value pair form</returns>
        public Dictionary<string, string> GetContollerClass(string filePath)
        {
            List<APIStructure> serverURLs = new List<APIStructure>();
            Dictionary<string, string> ret = new Dictionary<string, string>();

            var controllerData = DecomInitializer.GetControllersCollection(filePath);

            foreach (var item in controllerData)
            {
                foreach (var nms in item.ListOfNameSpaces)
                {
                    foreach (var cls in nms.ClassDetails)
                    {
                        var apiObj = (ClassDetailAPI)cls;

                        IRoutingProcessor route = GetRoutingProcessor(apiObj, filePath, this.TaskType);
                        route.AssemAPIPath = filePath;
                        var data = route.PrepareURL(this.TaskType);
                        ret.AddRange(data);
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Get the Routing processor according to the attribute data for type of routing
        /// </summary>
        /// <param name="obj">Class API object with data</param>
        /// <param name="filePath">Assembly file path</param>
        /// <param name="taskType">Whether it is standalone or Web Based</param>
        /// <returns>Routing processor</returns>
        private static IRoutingProcessor GetRoutingProcessor(ClassDetailAPI obj, string filePath, string taskType = "")
        {
            if (routeInternal != null)
            {
                routeInternal.ClassDetails = obj;
                return routeInternal;
            }

            bool attrRoutingExist = false;
            RoutingTypes routingTypes = RoutingTypes.None;
            List<TemplateRoutingData> tmpltRoute = null;

            if (taskType != "IIS")
            {
                foreach (var method in obj.MethodLvlAttribute)
                {
                    attrRoutingExist = method.Value.Exists(x => x.Key == METHODAPIURL);
                    routingTypes = RoutingTypes.AttributeRouting;
                    break;
                }
                if (routingTypes == RoutingTypes.None)
                {
                    routingTypes = RoutingTypes.TemplateRouting;
                }
            }
            else
            {
                var rout = new FetchRoutingDetails();
                rout.GetWebAPIRouteConfiguration(filePath);

                routingTypes = rout.RoutingType;

                if (routingTypes == RoutingTypes.None)
                {
                    routingTypes = RoutingTypes.AttributeRouting;
                }
            }

            IRoutingProcessor route = null;

            if (routingTypes == RoutingTypes.AttributeRouting)
            {
                route = new AttributeRoutingProcessor(obj);
            }
            else if (routingTypes == RoutingTypes.TemplateRouting)
            {
                route = new TemplateRoutingProcessor(obj);
            }
            else if (routingTypes == RoutingTypes.MixedRouting)
            {
                route = new MixedModeRoutingProcessor(obj, tmpltRoute);
            }

            routeInternal = route;
            return route;
        }
    }
}
