﻿//-----------------------------------------------------------------------
// <copyright file="FetchRoutingDetails.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using CrossCode.ByteCode.Helper;
    using CrossCode.Trace.BLL;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Web.Routing;

    class FetchRoutingDetails
    {
        const string WEBAPICONFIGCLASSNAME = "WebApiConfig";

        //public static string RouteTemplate
        //{
        //    get;
        //    set;
        //}

        public RoutingTypes RoutingType
        {
            get;
            set;
        }
        public static TemplateType GetTemplateType(string templateValue)
        {
            TemplateType templateType = new TemplateType();

            if (templateValue.ToLower().Contains("{controller}") && templateValue.ToLower().Contains("{action}"))
            {
                templateType = TemplateType.ControlerWithAction;
            }
            else if (templateValue.ToLower().Contains("{controller}") && !templateValue.ToLower().Contains("{action}"))
            {
                templateType = TemplateType.OnlyController;
            }
            else
            {
                templateType = TemplateType.OnlyController;
            }

            return templateType;

        }

        public List<TemplateRoutingData> GetWebAPIRouteConfiguration(string fullpathAPIDLL, string fullNameofRouteClass = "SFP.FoxTrax.API.WebApiConfig")
        {
            List<TemplateRoutingData> templateRoutingCollection = new List<TemplateRoutingData>();

            try
            {
                AppDomain currentDomain = AppDomain.CurrentDomain;
                currentDomain.AssemblyResolve += new ResolveEventHandler(
                                                    new FrameWorkPathOverrider()
                                                    {
                                                        SourcePath = fullpathAPIDLL
                                                    }.AssemResolveEventHandler);
                Type[] types = null;
                Assembly a = null;
                try
                {
                    a = Assembly.Load(fullpathAPIDLL);
                    types = a.GetTypes();
                }
                catch (ReflectionTypeLoadException r)
                {
                    types = r.Types;
                }

                //Get the remote type of webconfig static class
                Type type = types.Where(x => x.Name == WEBAPICONFIGCLASSNAME).FirstOrDefault();

                //Find the Register method which is a invoking point for configuration loading
                var registerRouteMethod = type.GetMethod(ConstantAPIModule.RegisterRouteMethod);

                //Get the the remote httpconfguration objet
                var prm = registerRouteMethod.GetParameters();

                List<object> inputParams = new List<object>();
                PrepareInputParamObjectInstance(prm, inputParams);

                //Invoke the method Register method
                registerRouteMethod.Invoke(null, inputParams.ToArray());

                // Now dyanmically find the Routing information.
                GetWebApiRouteConfig(templateRoutingCollection, inputParams[0]);

                // Check Routing pattern to fetch Routomg processor accordingly
                CheckRoutingPatternExist(inputParams);
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
            }

            return templateRoutingCollection;
        }

        private static RoutingTypes CheckRoutingPatternExist(List<object> inputParams)
        {
            RoutingTypes routingTypes = RoutingTypes.None;

            dynamic config = inputParams[0];
            dynamic f = config.Initializer == null ? null : config.Initializer.Target;
            bool isAttributeRouting = false;
            bool isTemplateRouting = false;

            if (f != null && f.GetType().FullName.Contains("System.Web.Http.Routing.AttributeRoutingMapper"))
            {
                isAttributeRouting = true;
            }

            foreach (dynamic d in config.Routes)
            {
                if (d.GetType().Name == ConstantAPIModule.HttpRouteAttributeName)
                {
                    if (!string.IsNullOrWhiteSpace(d.RouteTemplate))
                    {
                        isTemplateRouting = true;
                    }
                }
            }

            if (isAttributeRouting && isTemplateRouting)
            {
                routingTypes = RoutingTypes.MixedRouting;
            }
            else if (isAttributeRouting)
            {
                routingTypes = RoutingTypes.AttributeRouting;
            }
            else if (isTemplateRouting)
            {
                routingTypes = RoutingTypes.TemplateRouting;
            }
            else
            {
                routingTypes = RoutingTypes.None;
            }

            return routingTypes;
        }
        private static void PrepareInputParamObjectInstance(ParameterInfo[] prm, List<object> inputParams)
        {
            foreach (var pr in prm)
            {
                try
                {
                    if (pr.ParameterType.IsInterface || pr.ParameterType.IsAbstract)
                    {
                        var interfaceType = AsmblyInfoHelper.GetAllEntities(pr.ParameterType);
                        var implInterfaceInstance = Activator.CreateInstance(interfaceType.ElementAt(0), true);
                        inputParams.Add(implInterfaceInstance);

                    }
                    else
                    {
                        inputParams.Add(Activator.CreateInstance(pr.ParameterType));
                    }
                }
                catch (Exception ex)
                {
                }
            }
        }

        public List<TemplateRoutingData> GetRouteConfiguration(string fullpathAPIDLL, string fullNameofRouteClass = "SFP.FoxTrax.API.WebApiConfig")
        {
            List<TemplateRoutingData> templateRoutingCollection = new List<TemplateRoutingData>();

            try
            {
                AppDomain currentDomain = AppDomain.CurrentDomain;
                currentDomain.AssemblyResolve += new ResolveEventHandler(
                                                    new FrameWorkPathOverrider()
                                                    {
                                                        SourcePath = Path.GetDirectoryName(fullpathAPIDLL)
                                                    }.AssemResolveEventHandler);

                //Get the remote type of webconfig stativ class
                Type type = Assembly.Load(fullpathAPIDLL).GetTypes().Where(x => x.Name == "WebApiConfig").FirstOrDefault();

                //Find the Register method which is a invoking point for configuration loading
                var registerRouteMethod = type.GetMethod(ConstantAPIModule.RegisterRouteMethod);

                //load the specific system.web.http.dll  assembly
                var apiConfig = Assembly.Load(Path.Combine(Path.GetDirectoryName(fullpathAPIDLL), "System.Web.Http.dll"));//.GetType("System.Web.Http.HttpConfiguration");

                //Get the remote object of HttpConfiguration 
                var config = apiConfig.GetType("System.Web.Http.HttpConfiguration");

                //Get the the remote httpconfguration objet
                var routeconfig = Activator.CreateInstance(config);

                //Invoke the method Register method
                registerRouteMethod.Invoke(null, new object[1] { routeconfig });

                // Noe dyanmically find the Routing information.
                GetWebApiRouteConfig(templateRoutingCollection, routeconfig);

            }
            catch (Exception ex)
            {
            }

            return templateRoutingCollection;
        }



        private static void GetWebApiRouteConfig(List<TemplateRoutingData> templateRoutingCollection, object routeconfig)
        {
            dynamic v = routeconfig;

            foreach (dynamic d in v.Routes)
            {
                if (d.GetType().Name == ConstantAPIModule.HttpRouteAttributeName)
                {
                    TemplateRoutingData temp = new TemplateRoutingData();
                    temp.Template = d.RouteTemplate;
                    temp.DefaultValues = new Dictionary<string, string>();
                    //RouteTemplate = temp.Template;
                    if (d.Defaults.Count > 0)
                    {
                        foreach (dynamic item in d.Defaults)
                        {
                            string key = item.Key;
                            string Value = item.Value.ToString();

                            temp.DefaultValues.Add(key, Value);

                        }
                    }

                    templateRoutingCollection.Add(temp);
                }
            }
        }

        public List<TemplateRoutingData> GetRouteConfigurationAll(string fullpathAPIDLL, string fullNameofRouteClass = "SFP.FoxTrax.API.WebApiConfig")
        {
            List<TemplateRoutingData> template = new List<TemplateRoutingData>();

            try
            {
                AppDomain currentDomain = AppDomain.CurrentDomain;
                currentDomain.AssemblyResolve += new ResolveEventHandler(
                                                    new FrameWorkPathOverrider()
                                                    {
                                                        SourcePath = Path.GetDirectoryName(fullpathAPIDLL)
                                                    }.AssemResolveEventHandler);

                Type type = Assembly.Load(fullpathAPIDLL).GetType(fullNameofRouteClass);
                var routeconfig = Activator.CreateInstance(type);

                var registerRouteMethod = type.GetMethod(ConstantAPIModule.RegisterRouteMethod);
                RouteCollection routeCollectionAspNet = new RouteCollection();

                registerRouteMethod.Invoke(routeconfig, new object[] { routeCollectionAspNet });

                var routeData = routeCollectionAspNet.Where(x => x.GetType().Name == ConstantAPIModule.RouteAttributeTypeName).ToList();

                //Route route = (Route)routeData;
                //template = route.Url;
                //RouteTemplate = template;
            }
            catch (Exception ex)
            {
            }

            return template;
        }
    }
}
