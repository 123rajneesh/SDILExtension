﻿//-----------------------------------------------------------------------
// <copyright file="IRoutingProcessor.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using CrossCode.BLL.Domain;
    using System.Collections.Generic;

    public interface IRoutingProcessor
    {
        string AssemAPIPath
        {
            get;
            set;
        }
        Dictionary<string, string> PrepareURL(string taskType);

        Dictionary<string, List<string>> PrepareAllURLs
        {
            get;
            set;
        }

        IClassDetails ClassDetails
        {
            set;

        }
    }
}
