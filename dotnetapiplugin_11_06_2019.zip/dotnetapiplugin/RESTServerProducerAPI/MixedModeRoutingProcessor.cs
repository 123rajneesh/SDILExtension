﻿//-----------------------------------------------------------------------
// <copyright file="MixedModeRoutingProcessor.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using CrossCode.BLL.Domain;
    using CrossCode.ByteCode.Helper;
    using CrossCode.Trace.BLL;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    class MixedModeRoutingProcessor : IRoutingProcessor
    {
        private List<TemplateRoutingData> templateRoute;
        private ClassDetailAPI classAPI;

        public MixedModeRoutingProcessor(IClassDetails classDetails, List<TemplateRoutingData> templateRoute)
        {
            this.classAPI = (ClassDetailAPI)classDetails;
            this.templateRoute = templateRoute;
        }
        public string AssemAPIPath
        {
            get;
            set;
        }
        public Dictionary<string, List<string>> PrepareAllURLs
        {
            get;
            set;
        }

        public IClassDetails ClassDetails
        {
            set
            {
                this.classAPI = (ClassDetailAPI)value;
            }
        }

        public Dictionary<string, string> PrepareURL(string taskType)
        {
            Dictionary<string, string> serverUrl = new Dictionary<string, string>();

            foreach (var method in classAPI.MethodLvlAttribute)
            {
                bool isRoutingPrefixExist = false;
                string routePrefixvalue = string.Empty;

                if (classAPI.ClassLvlAttributes != null && classAPI.ClassLvlAttributes.Count > 0)
                {
                    isRoutingPrefixExist = classAPI.ClassLvlAttributes.TryGetValue("RoutePrefix", out routePrefixvalue);
                }

                string routeURL = string.Empty;

                if (taskType == "IIS")
                {
                    routeURL = method.Value.Find(x => x.Key == "methodAPIUrl").Value;
                }
                else
                {
                    routeURL = method.Value.Find(x => x.Key == "HttpRoute").Value;
                }

                var methodKey = method.Value.Find(x => x.Key == ConstantAPIModule.MethodIdentifierKeyHeder).Value;

                if (!string.IsNullOrWhiteSpace(routeURL))
                {
                    PrepareUrlAsAttributeRouting(serverUrl, isRoutingPrefixExist, routePrefixvalue, routeURL, methodKey);
                }
                else
                {
                    PrepareUrlsAsTemplateRouting(method, serverUrl, this.classAPI);
                }
            }

            return serverUrl;
        }

        private void PrepareUrlsAsTemplateRouting(KeyValuePair<string, List<KeyValuePair<string,string>>> method , Dictionary<string, string> serverUrl ,ClassDetailAPI classAPI)
        {
            foreach (var tmpRout in this.templateRoute)
            {
                var tmplt = FetchRoutingDetails.GetTemplateType(tmpRout.Template);

                if (tmplt == TemplateType.OnlyController)
                {
                    string createdURLs = tmpRout.Template.Replace(ConstantAPIModule.ControllerToken, classAPI.ClassName.Replace("Controller", ""));
                    var keyData = method.Value.Where(x => x.Key == "MethodKey").FirstOrDefault();

                    serverUrl.Add(keyData.Value, createdURLs);
                }
                else if (tmplt == TemplateType.ControlerWithAction)
                {
                    string createdURLs = PrepareUrlCntrWthActn(classAPI, tmpRout.Template, method);
                    serverUrl.Add(method.Key, createdURLs);
                }
                else
                {
                }
            }
        }

        private static void PrepareUrlsTmpltTypControllerWithAction(ClassDetailAPI aPIStructures, string urlTemplate, Dictionary<string, string> producerAPIs, KeyValuePair<string, List<KeyValuePair<string, string>>> url)
        {
            string createdURLs = PrepareUrlCntrWthActn(aPIStructures, urlTemplate, url);
            producerAPIs.Add(url.Key, createdURLs);
        }

        private static string PrepareUrlCntrWthActn(ClassDetailAPI aPIStructures, string urlTemplate, KeyValuePair<string, List<KeyValuePair<string, string>>> url)
        {
            string key = url.Key.Split(new string[1] { ConstantAPIModule.SeparatorAttribute }, StringSplitOptions.RemoveEmptyEntries)[1];
            var keyData = url.Value.Where(x => x.Key == ConstantAPIModule.MethodNameKeyHeader).FirstOrDefault();
            string createdURLs = urlTemplate.Replace(ConstantAPIModule.ControllerToken, aPIStructures.ClassName);
            var actionNameByAttribute = url.Value.Where(x => x.Key == "ActionName").FirstOrDefault();

            if (actionNameByAttribute.Equals(default(KeyValuePair<string, string>)))
            {
                createdURLs = createdURLs.Replace(ConstantAPIModule.ActionToken, keyData.Value);
            }
            else
            {
                createdURLs = createdURLs.Replace(ConstantAPIModule.ActionToken, actionNameByAttribute.Value);
            }

            return createdURLs;
        }

        private static void PrepareUrlAsAttributeRouting(Dictionary<string, string> serverUrl, bool isRoutingPrefixExist, string routePrefixvalue, string routeURL, string methodKey)
        {
            if (isRoutingPrefixExist)
            {
                string apiUrl = string.Join("/", new object[2] { routePrefixvalue, routeURL });

                serverUrl.Add(methodKey, apiUrl);
            }
            else
            {
                serverUrl.Add(methodKey, routeURL);
            }
        }
    }
}
