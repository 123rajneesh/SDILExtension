﻿//-----------------------------------------------------------------------
// <copyright file="TemplateRoutingProcessor.cs" company="CrossCode">
//     Copyright (c) CrossCode Inc. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace RESTServerProducerAPI
{
    using CrossCode.BLL.Domain;
    using CrossCode.ByteCode.Helper;
    using System.Collections.Generic;

    class TemplateRoutingProcessor : IRoutingProcessor
    {
        private  ClassDetailAPI classAPI = null;

        public string AssemAPIPath
        {
            get;
            set;
        }
        public Dictionary<string, List<string>> PrepareAllURLs
        {
            get;
            set;
        }

        public TemplateRoutingProcessor(IClassDetails classDetails)
        {
            classAPI = (ClassDetailAPI)classDetails;
        }

        public IClassDetails ClassDetails
        {
            set
            {
                classAPI = (ClassDetailAPI)value;
            }
        }

        public Dictionary<string,string> PrepareURL(string taskType)
        {
            Dictionary<string,string> url = new Dictionary<string, string>();

            var apiConfig = new FetchRoutingDetails().GetRouteConfiguration(AssemAPIPath);

            foreach (var item in apiConfig)
            {
                url.AddRange(CreateURL.PrepareServerUrls(classAPI, item.Template, FetchRoutingDetails.GetTemplateType(item.Template)));
            }

            return url;
        }
    }
}
