

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0622 */
/* at Tue Jan 19 08:44:07 2038
 */
/* Compiler settings for ILRewriteProfiler.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.01.0622 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ILRewriteProfiler_h_h__
#define __ILRewriteProfiler_h_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ILRewriteProfiler_FWD_DEFINED__
#define __ILRewriteProfiler_FWD_DEFINED__
typedef interface ILRewriteProfiler ILRewriteProfiler;

#endif 	/* __ILRewriteProfiler_FWD_DEFINED__ */


#ifndef __ILRewriteProfilerImpl_FWD_DEFINED__
#define __ILRewriteProfilerImpl_FWD_DEFINED__

#ifdef __cplusplus
typedef class ILRewriteProfilerImpl ILRewriteProfilerImpl;
#else
typedef struct ILRewriteProfilerImpl ILRewriteProfilerImpl;
#endif /* __cplusplus */

#endif 	/* __ILRewriteProfilerImpl_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __ILRewriteProfiler_INTERFACE_DEFINED__
#define __ILRewriteProfiler_INTERFACE_DEFINED__

/* interface ILRewriteProfiler */
/* [helpstring][oleautomation][uuid][object] */ 


EXTERN_C const IID IID_ILRewriteProfiler;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C546F9ED-7767-43A3-BCF8-87426C1E1343")
    ILRewriteProfiler : public IUnknown
    {
    public:
    };
    
    
#else 	/* C style interface */

    typedef struct ILRewriteProfilerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ILRewriteProfiler * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ILRewriteProfiler * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ILRewriteProfiler * This);
        
        END_INTERFACE
    } ILRewriteProfilerVtbl;

    interface ILRewriteProfiler
    {
        CONST_VTBL struct ILRewriteProfilerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILRewriteProfiler_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define ILRewriteProfiler_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define ILRewriteProfiler_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ILRewriteProfiler_INTERFACE_DEFINED__ */



#ifndef __ILRewriteProfilerLib_LIBRARY_DEFINED__
#define __ILRewriteProfilerLib_LIBRARY_DEFINED__

/* library ILRewriteProfilerLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ILRewriteProfilerLib;

EXTERN_C const CLSID CLSID_ILRewriteProfilerImpl;

#ifdef __cplusplus

class DECLSPEC_UUID("941EC77E-F7C0-42C8-84E1-15FEFA3CE96F")
ILRewriteProfilerImpl;
#endif
#endif /* __ILRewriteProfilerLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


