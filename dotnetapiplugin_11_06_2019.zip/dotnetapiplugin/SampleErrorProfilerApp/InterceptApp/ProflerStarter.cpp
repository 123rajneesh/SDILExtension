// ----------------------------------------------------------------------------------------------
// Copyright (c) Mattias H�gstr�m.
// ----------------------------------------------------------------------------------------------
// This source code is subject to terms and conditions of the Microsoft Public License. A 
// copy of the license can be found in the License.html file at the root of this distribution. 
// If you cannot locate the Microsoft Public License, please send an email to 
// dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
// by the terms of the Microsoft Public License.
// ----------------------------------------------------------------------------------------------
// You must not remove this notice, or any other, from this software.
// ----------------------------------------------------------------------------------------------

#include "Stdafx.h"

#include "ProfilerStarter.h"
#include <Windows.h>
#include <metahost.h>

#include <cor.h>
#include <corprof.h>

#include <list>
#include <string>
#include <iostream>
#include <string>
#include <sstream>
#include <tchar.h>
#include <strsafe.h>

#include "ClrHelper.h"
#include <atlbase.h>

using namespace std;

#include <metahost.h>
#pragma comment(lib, "mscoree.lib")

static std::string ConvertStlString(std::wstring& text)
{    
   const std::string narrow(text.begin(), text.end());
   return narrow;
}

ProfilerStarter::ProfilerStarter()
{
   ZeroAll();
}

ProfilerStarter::~ProfilerStarter()
{
   ReleaseAll();
}

void ProfilerStarter::ReleaseAll()
{
   if (m_metahost != nullptr)
      m_metahost->Release();	
   if (m_runtimeInfo != nullptr)
      m_runtimeInfo->Release();
   if (m_clrProfiling != nullptr)
      m_clrProfiling->Release();
   ZeroAll();
}

void ProfilerStarter::ZeroAll()
{
   m_metahost = nullptr;
   m_clrProfiling = nullptr;
   m_runtimeInfo = nullptr;
   m_isAttached = false;
   m_processId = 0;
}	

HRESULT ProfilerStarter::Initialize()
{
   std::wstring version;
   if (!ClrHelper::GetV4RunTime(version))
      return E_FAIL;

   HRESULT hr = S_OK;
   do
   {
      hr = CLRCreateInstance(CLSID_CLRMetaHost, IID_ICLRMetaHost, (LPVOID*)&m_metahost);
      if (hr != S_OK) break;
      hr = m_metahost->GetRuntime(version.c_str(), IID_ICLRRuntimeInfo, (LPVOID*)&m_runtimeInfo);
      if (hr != S_OK) break;
      hr = m_runtimeInfo->GetInterface(CLSID_CLRProfiling, IID_ICLRProfiling, (LPVOID *)&m_clrProfiling);
      if (hr != S_OK) break;
      return S_OK;
   } while (false);

   // We end up here only if we have errors
   ReleaseAll();
   return hr;
}	

DWORD ProfilerStarter::GetProcessId()
{
   return m_processId;
}

BOOL ProfilerStarter::StartProcess(const WCHAR* exePath)
{
   return StartProcess(exePath, NULL);
}

BOOL ProfilerStarter::StartProcess(const WCHAR* exePath, std::list<std::wstring>& environmentVars)
{	
   std::wstring envString;
   WCHAR separator[] = L"\0";
   for(std::list<std::wstring>::iterator iter = environmentVars.begin();iter != environmentVars.end();iter++)
   {
      std::wstring envText = *iter;
      envString += envText + std::wstring(separator, 1);
   }
   envString += std::wstring(separator, 1);
   WCHAR* envPtrTemp = const_cast<WCHAR*>(envString.c_str());
   LPVOID envPtr = reinterpret_cast<LPVOID>(envPtrTemp);
   return this->StartProcess(exePath, envPtr);
}

HRESULT ProfilerStarter::CallAttachProfiler(DWORD dwProfileeProcID, DWORD dwMillisecondsTimeout,LPCWSTR wszProfilerPath, 
	std::list<std::wstring>& environmentVars, HANDLE hProcess)
{
	ICLRMetaHost* metaHost = NULL;
	ICLRRuntimeInfo* runtimeInfo = NULL;
	ICLRRuntimeHost* runtimeHost = NULL;

	if (CLRCreateInstance(CLSID_CLRMetaHost, IID_ICLRMetaHost, (LPVOID*)&metaHost) == S_OK)
		if (metaHost->GetRuntime(L"v4.0.30319",
			IID_ICLRRuntimeInfo, (LPVOID*)&runtimeInfo) == S_OK)
			if (runtimeInfo->GetInterface(CLSID_CLRRuntimeHost, IID_ICLRRuntimeHost, (LPVOID*)&runtimeHost) == S_OK)
			{
			}
				//if (runtimeHost->Start() == S_OK)
				//{
				//	/*DWORD pReturnValue;
				//	runtimeHost->ExecuteInDefaultAppDomain(L"C:\\random.dll",
				//		L"dllNamespace.dllClass", L"ShowMsg", L"It works!!", &pReturnValue);

				//	runtimeInfo->Release();
				//	metaHost->Release();
				//	runtimeHost->Release();*/
				//}
	//return 0;



	// This can be a data type of your own choosing for sending configuration data 
	// to your profiler:
	//HANDLE hProcess;
	std::wstring envString;
	WCHAR separator[] = L"\0";
	for (std::list<std::wstring>::iterator iter = environmentVars.begin(); iter != environmentVars.end(); iter++)
	{
		std::wstring envText = *iter;
		envString += envText + std::wstring(separator, 1);
	}
	envString += std::wstring(separator, 1);
	WCHAR* envPtrTemp = const_cast<WCHAR*>(envString.c_str());
	LPVOID envPtr = reinterpret_cast<LPVOID>(envPtrTemp);

	/*MyProfilerConfigData profConfig;
	PopulateMyProfilerConfigData(&profConfig);*/
	
	CLSID clsid;
	CLSIDFromString(CComBSTR("{941EC77E-F7C0-42C8-84E1-15FEFA3CE96F}"), &clsid);
	const CLSID clsid1 = clsid;

	LPVOID pvClientData = envPtr;
	DWORD cbClientData = sizeof(envPtrTemp);

	ICLRMetaHost * pMetaHost = NULL;
	IEnumUnknown * pEnum = NULL;
	IUnknown * pUnk = NULL;
	ICLRRuntimeInfo * pRuntime = runtimeInfo;
	ICLRProfiling * pProfiling = NULL;
	HRESULT hr = E_FAIL;

	/*HMODULE hModule = LoadLibrary(L"MSCOREE.DLL");
	if (hModule == NULL)
	{
		hr = HRESULT_FROM_WIN32(GetLastError());
		goto Cleanup;
	}

	CLRCreateInstanceFnPtr pfnCreateInterface = (CLRCreateInstanceFnPtr)GetProcAddress(hModule, "CLRCreateInterface");
	if (pfnCreateInterface == NULL)
		goto Cleanup;*/
/*
	hr = (*pfnCreateInterface)(CLSID_CLRMetaHost, IID_ICLRMetaHost, (LPVOID *)&pMetaHost);
	if (FAILED(hr))
		goto Cleanup;*/

	/*hr = pMetaHost->EnumerateLoadedRuntimes(hProcess, &pEnum);
	if (FAILED(hr))
		goto Cleanup;*/

	/*while (pEnum->Next(1, &pUnk, NULL) == S_OK)
	{
		hr = pUnk->QueryInterface(IID_ICLRRuntimeInfo, (LPVOID *)&pRuntime);
		if (FAILED(hr))
		{
			pUnk->Release();
			pUnk = NULL;
			continue;
		}

		WCHAR wszVersion[30];
		DWORD cchVersion = sizeof(wszVersion) / sizeof(wszVersion[0]);
		hr = pRuntime->GetVersionString(wszVersion, &cchVersion);
		if (SUCCEEDED(hr) &&
			(cchVersion >= 3) &&
			((wszVersion[0] == L'v') || (wszVersion[0] == L'V')) &&
			((wszVersion[1] >= L'4') || (wszVersion[2] != L'.')))
		{

			hr = pRuntime->GetInterface(CLSID_CLRProfiling, IID_ICLRProfiling, (LPVOID *)&pProfiling);
			if (SUCCEEDED(hr))
			{
				hr = pProfiling->AttachProfiler(dwProfileeProcID, dwMillisecondsTimeout, &clsid1, wszProfilerPath, pvClientData, cbClientData
				);

				pProfiling->Release();
				pProfiling = NULL;
				break;
			}
		}*/

	hr = pRuntime->GetInterface(CLSID_CLRProfiling, IID_ICLRProfiling, (LPVOID *)&pProfiling);
	if (SUCCEEDED(hr))
	{
		hr = pProfiling->AttachProfiler(dwProfileeProcID, dwMillisecondsTimeout, &clsid1, wszProfilerPath, pvClientData, cbClientData
		);

		pProfiling->Release();
		pProfiling = NULL;
		//break;
	}


Cleanup:
	if (pProfiling != NULL)
	{
		pProfiling->Release();
		pProfiling = NULL;
	}
	if (pRuntime != NULL)
	{
		pRuntime->Release();
		pRuntime = NULL;
	}

	if (pUnk != NULL)
	{
		pUnk->Release();
		pUnk = NULL;
	}

	if (pEnum != NULL)
	{
		pEnum->Release();
		pEnum = NULL;
	}

	if (pMetaHost != NULL)
	{
		pMetaHost->Release();
		pMetaHost = NULL;
	}

	/*if (hModule != NULL)
	{
		FreeLibrary(hModule);
		hModule = NULL;
	}*/
	runtimeInfo->Release();
	metaHost->Release();
	runtimeHost->Release();

	return hr;
}

BOOL ProfilerStarter::StartProcess(const WCHAR* exePath, LPVOID environmentVars)
{

   STARTUPINFO si;
   PROCESS_INFORMATION pi;
   ZeroMemory( &si, sizeof(si) );
   si.cb = sizeof(si);
   ZeroMemory( &pi, sizeof(pi) );
   BOOL created = ::CreateProcessW(NULL // Application Name
      , const_cast<LPWSTR>(exePath) // CommandLine
      , NULL // Process Attributes
      , NULL // Thread Attributes
      , FALSE // Inherit Handles
      , CREATE_NEW_CONSOLE | CREATE_UNICODE_ENVIRONMENT // Creation Flags
      , environmentVars // Environment
      , NULL // Current Directory
      , &si // Startup info
      , &pi);

   if (!created)
      return FALSE;
   m_processId = pi.dwProcessId;
   return m_processId != 0;
}